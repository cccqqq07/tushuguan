/* ============================================================
   吉林铁道职业技术大学 · 毕业生读书报告查询网站
   script.js —— 查询、渲染、导出逻辑（原生 JavaScript）
   依赖：data.js（提供全局数组 borrowData）、html2pdf.js（导出 PDF）
   ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
     全局状态与数据安全读取
     使用 typeof 判断，避免 data.js 未加载时抛出 ReferenceError，
     从而保证“数据加载失败”时控制台不报严重错误。
  ---------------------------------------------------------- */
  var DATA = (typeof borrowData !== 'undefined' && Array.isArray(borrowData)) ? borrowData : null;

  // 去重后的姓名列表（仅在数据有效时计算一次）
  var DISTINCT_NAMES = DATA
    ? Array.from(new Set(DATA.map(function (r) { return (r && r.name ? String(r.name).trim() : ''); })
        .filter(function (n) { return n !== ''; })))
    : [];

  // 当前已生成报告的学生姓名（供导出 PDF 使用）
  var currentStudentName = null;

  // 常用 DOM 元素引用（在 initPage 中赋值）
  var els = {};

  /* ----------------------------------------------------------
     1. initPage —— 初始化页面：缓存元素、绑定事件、数据校验
  ---------------------------------------------------------- */
  function initPage() {
    els = {
      nameInput: document.getElementById('nameInput'),
      searchBtn: document.getElementById('searchBtn'),
      resetBtn: document.getElementById('resetBtn'),
      resetBtn2: document.getElementById('resetBtn2'),
      exportBtn: document.getElementById('exportBtn'),
      printBtn: document.getElementById('printBtn'),
      candidateSection: document.getElementById('candidateSection'),
      candidateList: document.getElementById('candidateList'),
      messageBox: document.getElementById('messageBox'),
      reportSection: document.getElementById('reportSection'),
      reportCard: document.getElementById('reportCard')
    };

    // 数据未正确加载时：提示并禁用查询
    if (!DATA) {
      showMessage('数据加载失败，请检查 data.js 文件是否存在。', true);
      if (els.searchBtn) els.searchBtn.disabled = true;
      if (els.nameInput) els.nameInput.disabled = true;
      return;
    }

    // 生成报告
    els.searchBtn.addEventListener('click', handleSearch);

    // 重新查询（查询区与报告区各有一个按钮）
    els.resetBtn.addEventListener('click', resetPage);
    els.resetBtn2.addEventListener('click', resetPage);

    // 导出 PDF / 打印
    els.exportBtn.addEventListener('click', exportPDF);
    els.printBtn.addEventListener('click', function () { window.print(); });

    // 支持回车键查询
    els.nameInput.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        handleSearch();
      }
    });

    // 输入框获得焦点
    els.nameInput.focus();
  }

  /* ----------------------------------------------------------
     2. handleSearch —— 获取输入并执行查询，分流处理结果
  ---------------------------------------------------------- */
  function handleSearch() {
    if (!DATA) {
      showMessage('数据加载失败，请检查 data.js 文件是否存在。', true);
      return;
    }

    var keyword = (els.nameInput.value || '').trim();

    // 输入为空提示
    if (!keyword) {
      hideReport();
      hideCandidates();
      showMessage('请输入姓名后再生成报告。', false);
      els.nameInput.focus();
      return;
    }

    var result = searchStudent(keyword);

    if (result.status === 'none') {
      // 未查询到记录
      hideReport();
      hideCandidates();
      showMessage('未查询到相关借阅记录，请确认姓名是否正确。', false);
    } else if (result.status === 'single') {
      // 唯一匹配，直接生成报告
      hideCandidates();
      hideMessage();
      renderReport(result.name);
    } else if (result.status === 'multiple') {
      // 多个匹配，展示候选姓名
      hideReport();
      hideMessage();
      renderCandidateList(result.names);
    }
  }

  /* ----------------------------------------------------------
     3. searchStudent —— 根据关键字匹配学生（支持模糊查询）
     规则：
       - 完整姓名精确匹配优先；
       - 否则按“包含关键字”进行模糊匹配；
       - 返回 { status: 'single'|'multiple'|'none', name?, names? }
  ---------------------------------------------------------- */
  function searchStudent(keyword) {
    var key = String(keyword).trim();
    if (!key) return { status: 'none' };

    // 1) 完整姓名精确匹配（优先）
    var exact = DISTINCT_NAMES.filter(function (n) { return n === key; });
    if (exact.length === 1) return { status: 'single', name: exact[0] };
    if (exact.length > 1) return { status: 'multiple', names: sortNames(exact) };

    // 2) 模糊匹配（姓名包含关键字）
    var partial = DISTINCT_NAMES.filter(function (n) { return n.indexOf(key) !== -1; });

    if (partial.length === 0) return { status: 'none' };
    if (partial.length === 1) return { status: 'single', name: partial[0] };
    return { status: 'multiple', names: sortNames(partial) };
  }

  // 候选姓名按中文习惯排序
  function sortNames(names) {
    return names.slice().sort(function (a, b) {
      return a.localeCompare(b, 'zh-Hans-CN');
    });
  }

  /* ----------------------------------------------------------
     4. renderCandidateList —— 渲染候选姓名按钮列表
  ---------------------------------------------------------- */
  function renderCandidateList(names) {
    els.candidateList.innerHTML = '';

    names.forEach(function (name) {
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'candidate-btn';
      btn.textContent = name; // 使用 textContent，天然防注入
      btn.setAttribute('data-name', name);
      btn.addEventListener('click', function () {
        // 高亮当前选择
        var actives = els.candidateList.querySelectorAll('.candidate-btn.active');
        actives.forEach(function (el) { el.classList.remove('active'); });
        btn.classList.add('active');
        // 生成该学生报告
        hideMessage();
        renderReport(name);
      });
      els.candidateList.appendChild(btn);
    });

    els.candidateSection.hidden = false;
  }

  /* ----------------------------------------------------------
     5. getStudentRecords —— 获取某学生全部借阅记录并按时间升序
  ---------------------------------------------------------- */
  function getStudentRecords(name) {
    if (!DATA) return [];
    return DATA
      .filter(function (r) { return r && String(r.name).trim() === name; })
      .slice()
      .sort(function (a, b) {
        var ta = a.borrowTime || '';
        var tb = b.borrowTime || '';
        // YYYY-MM-DD 字符串可直接比较；空时间排在最前
        return ta < tb ? -1 : (ta > tb ? 1 : 0);
      });
  }

  /* ----------------------------------------------------------
     6. renderReport —— 生成并渲染读书报告
  ---------------------------------------------------------- */
  function renderReport(name) {
    var records = getStudentRecords(name);

    if (!records.length) {
      hideReport();
      showMessage('未查询到相关借阅记录，请确认姓名是否正确。', false);
      return;
    }

    currentStudentName = name;

    // 拼接借阅记录条目（含空值容错）
    var recordsHtml = records.map(function (r) {
      var time = r.borrowTime ? escapeHtml(r.borrowTime) : '未记录时间';
      var author = (r.author && String(r.author).trim()) ? escapeHtml(r.author) : '佚名';
      var book = (r.bookName && String(r.bookName).trim()) ? escapeHtml(r.bookName) : '未记录书名';
      return '' +
        '<li class="record-item">' +
          '<span class="record-time">' + time + '</span>' +
          '<span class="record-verb">品读</span>' +
          '<span class="record-author">' + author + '</span>' +
          '《<span class="record-book">' + book + '</span>》；' +
        '</li>';
    }).join('');

    var safeName = escapeHtml(name);
    var issueDate = formatChineseDate(new Date());

    // 组装完整报告（信纸 / 纪念卡片）
    var html = '' +
      '<div class="report-head">' +
        '<img class="report-logo" src="assets/logo.jpg" alt="吉林铁道职业技术大学校徽" />' +
        '<p class="report-school">吉林铁道职业技术大学图书馆</p>' +
        '<h2 class="report-title">毕业生读书报告</h2>' +
        '<span class="report-badge">在校阅读印记 · 共 ' + records.length + ' 条借阅记录</span>' +
      '</div>' +
      '<hr class="report-divider" />' +
      '<div class="report-body">' +
        '<p class="report-salutation">亲爱的' + safeName + '同学：</p>' +
        '<p class="report-para">六月汽笛吹响毕业序章，图书馆为你整理完整在校阅读记忆，所有借阅轨迹尽数留存。</p>' +
        '<p class="report-list-title">在校期间你的全部借阅记录：</p>' +
        '<ul class="report-records">' + recordsHtml + '</ul>' +
        '<p class="report-para">一条条时光印记，藏着你伏案耕读的日夜。</p>' +
        '<p class="report-para">墨香为伴，铁轨为途，书本沉淀的学识将伴你奔赴铁路前路。愿你珍藏这份完整阅读清单，永葆求知热忱，携书卷底气驰骋万里钢轨，前程坦荡。</p>' +
        '<div class="report-signature">' +
          '<p class="sig-org">吉林铁道职业技术大学图书馆</p>' +
          '<p class="sig-date">' + issueDate + '</p>' +
        '</div>' +
      '</div>' +
      '<div class="report-seal" aria-hidden="true">毕业<br/>纪念</div>';

    els.reportCard.innerHTML = html;
    els.reportSection.hidden = false;

    // 平滑滚动到报告区域
    els.reportSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  /* ----------------------------------------------------------
     7. exportPDF —— 导出报告卡片为 PDF
     文件名格式：姓名-毕业生读书报告.pdf
     仅导出报告卡片（#reportCard），不含查询框与按钮
  ---------------------------------------------------------- */
  function exportPDF() {
    if (!currentStudentName) {
      showMessage('请先生成报告后再导出 PDF。', false);
      return;
    }

    // html2pdf 未加载（如离线）时的友好提示
    if (typeof html2pdf === 'undefined') {
      showMessage('PDF 组件未能加载，请检查网络后重试，或改用“打印报告”功能。', true);
      return;
    }

    var fileName = currentStudentName + '-毕业生读书报告.pdf';
    var element = els.reportCard;

    var opt = {
      margin: [8, 8, 8, 8],
      filename: fileName,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2, useCORS: true, backgroundColor: '#fbf8f1' },
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
      pagebreak: { mode: ['css', 'legacy'] }
    };

    // 导出期间禁用按钮，给出状态反馈
    var originalText = els.exportBtn.textContent;
    els.exportBtn.disabled = true;
    els.exportBtn.textContent = '正在生成 PDF…';

    html2pdf().set(opt).from(element).save()
      .then(function () {
        els.exportBtn.disabled = false;
        els.exportBtn.textContent = originalText;
      })
      .catch(function () {
        els.exportBtn.disabled = false;
        els.exportBtn.textContent = originalText;
        showMessage('PDF 导出失败，请重试，或改用“打印报告”功能。', true);
      });
  }

  /* ----------------------------------------------------------
     8. resetPage —— 重置页面到初始状态
  ---------------------------------------------------------- */
  function resetPage() {
    currentStudentName = null;
    if (els.nameInput) {
      els.nameInput.value = '';
      els.nameInput.focus();
    }
    // 清空并隐藏候选区
    if (els.candidateList) els.candidateList.innerHTML = '';
    hideCandidates();
    // 隐藏并清空报告区
    if (els.reportCard) els.reportCard.innerHTML = '';
    hideReport();
    // 隐藏提示
    hideMessage();
    // 回到页面顶部
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  /* ----------------------------------------------------------
     9. escapeHtml —— 转义特殊字符，防止 XSS / 渲染异常
  ---------------------------------------------------------- */
  function escapeHtml(text) {
    if (text === null || text === undefined) return '';
    return String(text)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  /* ----------------------------------------------------------
     辅助函数
  ---------------------------------------------------------- */

  // 显示消息（isError=true 时为错误样式）
  function showMessage(text, isError) {
    if (!els.messageBox) return;
    var icon = isError ? '⚠️' : '🔍';
    els.messageBox.className = 'message no-print' + (isError ? ' error' : '');
    els.messageBox.innerHTML = '<span class="message-icon" aria-hidden="true">' + icon + '</span>' + escapeHtml(text);
    els.messageBox.hidden = false;
  }

  function hideMessage() {
    if (els.messageBox) els.messageBox.hidden = true;
  }

  function hideCandidates() {
    if (els.candidateSection) els.candidateSection.hidden = true;
  }

  function hideReport() {
    if (els.reportSection) els.reportSection.hidden = true;
  }

  // 将日期格式化为：YYYY 年 M 月 D 日
  function formatChineseDate(date) {
    var y = date.getFullYear();
    var m = date.getMonth() + 1;
    var d = date.getDate();
    return y + ' 年 ' + m + ' 月 ' + d + ' 日';
  }

  /* ----------------------------------------------------------
     启动：DOM 就绪后初始化
  ---------------------------------------------------------- */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initPage);
  } else {
    initPage();
  }

  // 便于调试：将主要函数挂到 window（不影响正常使用）
  window.ReadingReport = {
    initPage: initPage,
    handleSearch: handleSearch,
    searchStudent: searchStudent,
    renderCandidateList: renderCandidateList,
    getStudentRecords: getStudentRecords,
    renderReport: renderReport,
    exportPDF: exportPDF,
    resetPage: resetPage,
    escapeHtml: escapeHtml
  };
})();
