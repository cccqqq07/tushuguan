/**
 * data.js  —  吉林铁道职业技术大学毕业生借阅数据
 * ---------------------------------------------------------------
 * 本文件由图书馆借阅历史 Excel 表格转换而来，纯静态数据，无需后端。
 * 字段说明：
 *   name       学生姓名
 *   borrowTime 借阅时间（统一为 YYYY-MM-DD 格式）
 *   bookName   书名
 *   author     作者名
 *
 * 共 2310 条借阅记录。
 * 该数组挂载到全局变量 borrowData，供 script.js 直接读取查询。
 */
const borrowData = [
  {
    "name": "丁汇才",
    "borrowTime": "2023-11-02",
    "bookName": "民调局异闻录:终结季.4,困阵之兽",
    "author": "耳东水寿著"
  },
  {
    "name": "丁汇才",
    "borrowTime": "2024-05-15",
    "bookName": "剑来.17,一洲皆起剑",
    "author": "烽火戏诸侯著"
  },
  {
    "name": "丁汇才",
    "borrowTime": "2024-09-04",
    "bookName": "牵牵手就永远.上",
    "author": "红枣著"
  },
  {
    "name": "丁汇才",
    "borrowTime": "2024-09-08",
    "bookName": "牵牵手就永远.下",
    "author": "红枣著"
  },
  {
    "name": "丁汇才",
    "borrowTime": "2024-09-18",
    "bookName": "濒死之眼",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "丁汇才",
    "borrowTime": "2024-09-18",
    "bookName": "白银杰克",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "丁汇才",
    "borrowTime": "2024-09-18",
    "bookName": "假面饭店",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "丁汇才",
    "borrowTime": "2024-09-24",
    "bookName": "恃宠而骄.上",
    "author": "梦魇殿下著"
  },
  {
    "name": "丁汇才",
    "borrowTime": "2024-10-08",
    "bookName": "恃宠而骄.下",
    "author": "梦魇殿下著"
  },
  {
    "name": "丁汇才",
    "borrowTime": "2024-10-15",
    "bookName": "女法医手记之破译密码",
    "author": "刘真著"
  },
  {
    "name": "丁汇才",
    "borrowTime": "2024-10-24",
    "bookName": "诡案组.2.Season two.第2季",
    "author": "求无欲著"
  },
  {
    "name": "丁汇才",
    "borrowTime": "2024-10-31",
    "bookName": "地狱变.新版",
    "author": "蔡骏著"
  },
  {
    "name": "丁汇才",
    "borrowTime": "2024-11-05",
    "bookName": "灵魂追凶",
    "author": "向林著"
  },
  {
    "name": "丁汇才",
    "borrowTime": "2024-11-11",
    "bookName": "怪物同学会",
    "author": "全球华语科幻星云奖组委会编"
  },
  {
    "name": "丁汇才",
    "borrowTime": "2024-11-12",
    "bookName": "法医专家",
    "author": "王文杰著"
  },
  {
    "name": "丁汇才",
    "borrowTime": "2024-11-24",
    "bookName": "田连元评书小八义.下卷",
    "author": "田连元著"
  },
  {
    "name": "丁汇才",
    "borrowTime": "2024-11-24",
    "bookName": "田连元评书小八义.上卷",
    "author": "田连元著"
  },
  {
    "name": "丁汇才",
    "borrowTime": "2024-11-24",
    "bookName": "那片星空, 那片海",
    "author": "桐华作品"
  },
  {
    "name": "丁汇才",
    "borrowTime": "2024-11-24",
    "bookName": "漫画三国演义.1,乱世英雄",
    "author": "(明)罗贯中著"
  },
  {
    "name": "丁汇才",
    "borrowTime": "2024-12-05",
    "bookName": "三体.Ⅱ,黑暗森林",
    "author": "刘慈欣著"
  },
  {
    "name": "丁汇才",
    "borrowTime": "2025-03-06",
    "bookName": "暗恋是场长不大的思念",
    "author": "痴梦人著"
  },
  {
    "name": "丁立伟",
    "borrowTime": "2023-11-14",
    "bookName": "人体解读师",
    "author": "(美) 安娜·弗雷泽著"
  },
  {
    "name": "丁雨晨",
    "borrowTime": "2024-09-08",
    "bookName": "天气",
    "author": "贾平凹著"
  },
  {
    "name": "丁雨晨",
    "borrowTime": "2025-04-11",
    "bookName": "边城.修订版",
    "author": "沈从文著"
  },
  {
    "name": "丁鹏",
    "borrowTime": "2025-04-26",
    "bookName": "连环罪:心理有诡",
    "author": "墨绿青苔著"
  },
  {
    "name": "丛怡博",
    "borrowTime": "2023-09-24",
    "bookName": "怪诞实录.第二季",
    "author": "凤仪著"
  },
  {
    "name": "丛怡博",
    "borrowTime": "2023-09-24",
    "bookName": "罪全书.4",
    "author": "蜘蛛著"
  },
  {
    "name": "丛怡博",
    "borrowTime": "2023-10-19",
    "bookName": "读心诡探",
    "author": "风雨如书著"
  },
  {
    "name": "丛晶玉",
    "borrowTime": "2023-09-22",
    "bookName": "那个不为人知的故事",
    "author": "Twentine作品"
  },
  {
    "name": "丛智程",
    "borrowTime": "2023-09-21",
    "bookName": "扮演者游戏",
    "author": "赵婧怡著"
  },
  {
    "name": "丛智程",
    "borrowTime": "2023-11-04",
    "bookName": "法眼",
    "author": "木森著"
  },
  {
    "name": "严翔宇",
    "borrowTime": "2023-10-20",
    "bookName": "深度撞击",
    "author": "刘慈欣等著"
  },
  {
    "name": "严翔宇",
    "borrowTime": "2023-11-03",
    "bookName": "战争变种",
    "author": "刘慈欣等著"
  },
  {
    "name": "严翔宇",
    "borrowTime": "2023-11-03",
    "bookName": "星际移民",
    "author": "刘慈欣等著"
  },
  {
    "name": "严翔宇",
    "borrowTime": "2023-11-27",
    "bookName": "末世浩劫",
    "author": "刘慈欣等著"
  },
  {
    "name": "乔中奎",
    "borrowTime": "2023-09-19",
    "bookName": "嵬城.1,血路",
    "author": "冷露著"
  },
  {
    "name": "乔中奎",
    "borrowTime": "2023-10-06",
    "bookName": "时间移民",
    "author": "刘慈欣作品"
  },
  {
    "name": "乔志远",
    "borrowTime": "2023-10-07",
    "bookName": "诡案组.2.Season two.第2季",
    "author": "求无欲著"
  },
  {
    "name": "乔艺飞",
    "borrowTime": "2023-09-20",
    "bookName": "28天突破四级英语词汇:真题考查词汇详解+分频巧记.第2版",
    "author": "主编金利"
  },
  {
    "name": "乔艺飞",
    "borrowTime": "2023-11-05",
    "bookName": "28天突破四级英语词汇:真题考查词汇详解+分频巧记.第2版",
    "author": "主编金利"
  },
  {
    "name": "乔艺飞",
    "borrowTime": "2024-05-09",
    "bookName": "运动改变大脑",
    "author": "(英)卡罗琳·威廉姆斯著"
  },
  {
    "name": "于云鹤",
    "borrowTime": "2023-09-12",
    "bookName": "克苏鲁神话合集",
    "author": "(美) 霍华德·菲利普·洛夫克拉夫特著"
  },
  {
    "name": "于云鹤",
    "borrowTime": "2025-03-17",
    "bookName": "风吹哪页读哪页",
    "author": "飞扬文室编著"
  },
  {
    "name": "于云鹤",
    "borrowTime": "2025-03-17",
    "bookName": "别被不会表达拖了后腿",
    "author": "小城青空著"
  },
  {
    "name": "于云鹤",
    "borrowTime": "2025-03-17",
    "bookName": "当时这样说就好了",
    "author": "(日) 伊庭正康著"
  },
  {
    "name": "于佳鑫",
    "borrowTime": "2023-11-12",
    "bookName": "局外人·鼠疫",
    "author": "(法) 阿尔加·加缪著"
  },
  {
    "name": "于佳鑫",
    "borrowTime": "2024-11-12",
    "bookName": "图说资本论",
    "author": "谢洪波编著"
  },
  {
    "name": "于佳鑫",
    "borrowTime": "2024-11-12",
    "bookName": "串珠集:满族民俗史话",
    "author": "董凤芹编著"
  },
  {
    "name": "于兴烨",
    "borrowTime": "2024-05-16",
    "bookName": "克苏鲁神话合集",
    "author": "(美) 霍华德·菲利普·洛夫克拉夫特著"
  },
  {
    "name": "于兴烨",
    "borrowTime": "2024-05-16",
    "bookName": "世上最甜初恋",
    "author": "蝶之灵著"
  },
  {
    "name": "于宏泽",
    "borrowTime": "2023-10-17",
    "bookName": "原罪.3,拔云见日",
    "author": "一曲东风著"
  },
  {
    "name": "于宏泽",
    "borrowTime": "2023-11-12",
    "bookName": "犯罪心理档案.第四季",
    "author": "刚雪印著"
  },
  {
    "name": "于宏泽",
    "borrowTime": "2023-11-12",
    "bookName": "他似晨风起",
    "author": "惜双双著"
  },
  {
    "name": "于宏泽",
    "borrowTime": "2023-11-14",
    "bookName": "黄金瞳.1.1",
    "author": "打眼著"
  },
  {
    "name": "于宏泽",
    "borrowTime": "2023-11-14",
    "bookName": "黄金瞳.2.2",
    "author": "打眼著"
  },
  {
    "name": "于小溪",
    "borrowTime": "2023-09-18",
    "bookName": "白夜行.第2版",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "于小溪",
    "borrowTime": "2024-05-06",
    "bookName": "象棋中局战术大全",
    "author": "李艾东主编"
  },
  {
    "name": "于小溪",
    "borrowTime": "2024-05-06",
    "bookName": "恶意.第2版",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "于庭浩",
    "borrowTime": "2023-11-13",
    "bookName": "中国奇异档案记录.第四季",
    "author": "宋歌编著"
  },
  {
    "name": "于欣洋",
    "borrowTime": "2023-09-19",
    "bookName": "法医专家",
    "author": "王文杰著"
  },
  {
    "name": "于欣洋",
    "borrowTime": "2023-11-03",
    "bookName": "中国奇异档案记录.第四季",
    "author": "宋歌编著"
  },
  {
    "name": "于永旭",
    "borrowTime": "2023-10-21",
    "bookName": "匆匆那年.下",
    "author": "九夜茴著"
  },
  {
    "name": "于永旭",
    "borrowTime": "2023-11-12",
    "bookName": "许我星辰不落泪",
    "author": "许雁作品"
  },
  {
    "name": "于淮旭",
    "borrowTime": "2026-03-03",
    "bookName": "铁路货车段修图册",
    "author": "《铁路货车段修图册》编委会编"
  },
  {
    "name": "于添",
    "borrowTime": "2024-05-25",
    "bookName": "刑警誓言",
    "author": "万安, 陈琳著"
  },
  {
    "name": "于琦",
    "borrowTime": "2023-11-19",
    "bookName": "民国外交官顾维钧传",
    "author": "杨红林著"
  },
  {
    "name": "仁青卓玛",
    "borrowTime": "2024-06-06",
    "bookName": "白银杰克",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "仁青卓玛",
    "borrowTime": "2024-06-06",
    "bookName": "良琛吉日",
    "author": "小满著"
  },
  {
    "name": "仁青卓玛",
    "borrowTime": "2024-06-25",
    "bookName": "长安的荔枝",
    "author": "马伯庸著"
  },
  {
    "name": "仁青卓玛",
    "borrowTime": "2024-09-25",
    "bookName": "人一生要读的60篇演讲词",
    "author": "(美) 林肯等著"
  },
  {
    "name": "仁青卓玛",
    "borrowTime": "2024-09-25",
    "bookName": "现代女性的精神历程:从冰心到张爱玲",
    "author": "韩立群著"
  },
  {
    "name": "仁青卓玛",
    "borrowTime": "2024-10-17",
    "bookName": "青春梦想文摘,暖·温情",
    "author": "智慧主编"
  },
  {
    "name": "付城茹",
    "borrowTime": "2024-07-08",
    "bookName": "八骏图:精装纪念版",
    "author": "沈从文著"
  },
  {
    "name": "付城茹",
    "borrowTime": "2024-12-03",
    "bookName": "八骏图:精装纪念版",
    "author": "沈从文著"
  },
  {
    "name": "付城茹",
    "borrowTime": "2025-06-18",
    "bookName": "恰到好处的安慰",
    "author": "(美) 凯尔西·克罗, 埃米莉·麦克道尔著"
  },
  {
    "name": "付子龙",
    "borrowTime": "2024-05-29",
    "bookName": "天堂旅行团",
    "author": "张嘉佳著"
  },
  {
    "name": "付子龙",
    "borrowTime": "2024-10-28",
    "bookName": "达·芬奇谜题",
    "author": "(英) 理查德·沃尔菲克·加兰著"
  },
  {
    "name": "付子龙",
    "borrowTime": "2025-12-02",
    "bookName": "精神病预后档案:从遗弃中诞生",
    "author": "穆戈著"
  },
  {
    "name": "付恩",
    "borrowTime": "2023-09-18",
    "bookName": "聊斋志异",
    "author": "(清) 蒲松龄著"
  },
  {
    "name": "付恩",
    "borrowTime": "2023-09-26",
    "bookName": "诡案组.2.Season two.第2季",
    "author": "求无欲著"
  },
  {
    "name": "付恩",
    "borrowTime": "2023-11-13",
    "bookName": "羊脂球:莫泊桑短篇小说选",
    "author": "(法)莫泊桑著"
  },
  {
    "name": "付恩",
    "borrowTime": "2025-12-25",
    "bookName": "许三观卖血记.第3版",
    "author": "余华"
  },
  {
    "name": "付恩",
    "borrowTime": "2025-12-25",
    "bookName": "亲密关系:通往灵魂的桥梁",
    "author": "(加) 克里斯多福·孟著"
  },
  {
    "name": "付恩",
    "borrowTime": "2025-12-25",
    "bookName": "假面饭店",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "付茂林",
    "borrowTime": "2023-11-13",
    "bookName": "合租众神",
    "author": "零子还有钞作品"
  },
  {
    "name": "付茂林",
    "borrowTime": "2023-11-13",
    "bookName": "哇呜! 你可以带走我吗",
    "author": "虽虽酱绘著"
  },
  {
    "name": "付茂林",
    "borrowTime": "2023-11-15",
    "bookName": "克苏鲁神话合集",
    "author": "(美) 霍华德·菲利普·洛夫克拉夫特著"
  },
  {
    "name": "付茂林",
    "borrowTime": "2023-11-17",
    "bookName": "龙族.Ⅰ,火之晨曦",
    "author": "江南著"
  },
  {
    "name": "付茂林",
    "borrowTime": "2023-11-20",
    "bookName": "悲鸣之剑",
    "author": "刘靖宇著"
  },
  {
    "name": "付茂林",
    "borrowTime": "2023-11-20",
    "bookName": "超禁忌秘密.2.2",
    "author": "宁航一著"
  },
  {
    "name": "付轩宇",
    "borrowTime": "2023-09-24",
    "bookName": "老酒馆",
    "author": "高满堂, 李洲著"
  },
  {
    "name": "付轩宇",
    "borrowTime": "2023-09-24",
    "bookName": "你是人间的四月天",
    "author": "林徽因著"
  },
  {
    "name": "代佳琪",
    "borrowTime": "2023-09-18",
    "bookName": "自来水之污, 又名, 李泰和方小甜的平行世界",
    "author": "潇潇潇潇如编绘"
  },
  {
    "name": "代佳琪",
    "borrowTime": "2023-09-18",
    "bookName": "自来水之污, 又名, 李泰和方小甜的平行世界",
    "author": "潇潇潇潇如编绘"
  },
  {
    "name": "代国良",
    "borrowTime": "2023-09-24",
    "bookName": "亡者永生",
    "author": "那多著"
  },
  {
    "name": "代国良",
    "borrowTime": "2023-11-02",
    "bookName": "沧元图.1",
    "author": "我吃西红柿著"
  },
  {
    "name": "代国良",
    "borrowTime": "2023-11-17",
    "bookName": "龙族之子.Ⅰ,学院危机",
    "author": "月七公子著"
  },
  {
    "name": "代国良",
    "borrowTime": "2023-11-19",
    "bookName": "沙海.第二卷,沙蟒蛇巢",
    "author": "南派三叔著"
  },
  {
    "name": "代国良",
    "borrowTime": "2023-11-24",
    "bookName": "鬼吹灯",
    "author": "天下霸唱著"
  },
  {
    "name": "代国良",
    "borrowTime": "2023-11-29",
    "bookName": "三体.Ⅱ,黑暗森林",
    "author": "刘慈欣著"
  },
  {
    "name": "代国良",
    "borrowTime": "2024-04-29",
    "bookName": "十宗罪.5",
    "author": "蜘蛛著"
  },
  {
    "name": "代国良",
    "borrowTime": "2024-04-29",
    "bookName": "天之炽.1.1,红龙的归来",
    "author": "江南作品"
  },
  {
    "name": "代国良",
    "borrowTime": "2024-05-12",
    "bookName": "地底世界之幽潜重泉",
    "author": "天下霸唱著"
  },
  {
    "name": "代国良",
    "borrowTime": "2024-05-30",
    "bookName": "鬼吹灯",
    "author": "天下霸唱著"
  },
  {
    "name": "代国良",
    "borrowTime": "2024-06-24",
    "bookName": "镇魂,大结局",
    "author": "Priest作品"
  },
  {
    "name": "代政宝",
    "borrowTime": "2023-10-29",
    "bookName": "一世倾城.1,风云起",
    "author": "苏小暖著"
  },
  {
    "name": "代政宝",
    "borrowTime": "2023-11-08",
    "bookName": "古剑屠魔录",
    "author": "月关著"
  },
  {
    "name": "任保航",
    "borrowTime": "2023-10-17",
    "bookName": "鲜血梅花.第2版",
    "author": "余华"
  },
  {
    "name": "任保航",
    "borrowTime": "2023-10-17",
    "bookName": "战栗.第2版",
    "author": "余华"
  },
  {
    "name": "任保航",
    "borrowTime": "2023-11-08",
    "bookName": "糖衣",
    "author": "饶雪漫作品"
  },
  {
    "name": "任保航",
    "borrowTime": "2023-11-08",
    "bookName": "做局高手:一个商界大佬的巨大阴谋与超级圈套",
    "author": "柯云路著"
  },
  {
    "name": "任保航",
    "borrowTime": "2023-11-08",
    "bookName": "撒野",
    "author": "巫哲著"
  },
  {
    "name": "任保航",
    "borrowTime": "2023-11-22",
    "bookName": "绑嫁",
    "author": "三盅著"
  },
  {
    "name": "任保航",
    "borrowTime": "2023-11-22",
    "bookName": "澳门往事之孤注一掷",
    "author": "左四右五著"
  },
  {
    "name": "任保航",
    "borrowTime": "2023-11-22",
    "bookName": "白鹿原",
    "author": "陈忠实著"
  },
  {
    "name": "任保航",
    "borrowTime": "2023-11-22",
    "bookName": "糟糕, 是心动的感觉",
    "author": "梓榆著"
  },
  {
    "name": "任保航",
    "borrowTime": "2024-05-06",
    "bookName": "绑架游戏",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "任保航",
    "borrowTime": "2024-05-06",
    "bookName": "解忧杂货店",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "任凯龙",
    "borrowTime": "2023-12-18",
    "bookName": "工程制图基础",
    "author": "肖燕玉,樊炳雯编"
  },
  {
    "name": "任国胜",
    "borrowTime": "2023-10-29",
    "bookName": "法医专家",
    "author": "王文杰著"
  },
  {
    "name": "任国胜",
    "borrowTime": "2023-11-15",
    "bookName": "十二个明天",
    "author": "刘慈欣, (美) 刘宇昆, 尼迪·奥科拉弗等著"
  },
  {
    "name": "任国胜",
    "borrowTime": "2023-12-01",
    "bookName": "张作霖全传",
    "author": "李洪文著"
  },
  {
    "name": "任国胜",
    "borrowTime": "2024-05-13",
    "bookName": "半小时漫画唐诗",
    "author": "陈磊·半小时漫画团队著"
  },
  {
    "name": "任国胜",
    "borrowTime": "2024-05-13",
    "bookName": "半小时漫画唐诗",
    "author": "陈磊 半小时漫画团队著"
  },
  {
    "name": "任国胜",
    "borrowTime": "2024-05-14",
    "bookName": "九义十八侠",
    "author": "张个侬著"
  },
  {
    "name": "任国胜",
    "borrowTime": "2024-05-14",
    "bookName": "临界",
    "author": "王晋康著"
  },
  {
    "name": "任国胜",
    "borrowTime": "2024-05-27",
    "bookName": "指弹吉他独奏曲集.2",
    "author": "董宏峰编著"
  },
  {
    "name": "任宏涛",
    "borrowTime": "2023-10-06",
    "bookName": "雨声",
    "author": "许一鸣著"
  },
  {
    "name": "任宏涛",
    "borrowTime": "2023-10-06",
    "bookName": "雨声",
    "author": "许一鸣著"
  },
  {
    "name": "任思宇",
    "borrowTime": "2023-10-11",
    "bookName": "盗墓迷城之皇陵宝藏",
    "author": "迦南行者著"
  },
  {
    "name": "任思宇",
    "borrowTime": "2023-10-12",
    "bookName": "罪全书.5",
    "author": "蜘蛛著"
  },
  {
    "name": "任思宇",
    "borrowTime": "2023-10-16",
    "bookName": "盗墓玄机:长篇盗墓小说",
    "author": "朱晓翔著"
  },
  {
    "name": "任思宇",
    "borrowTime": "2023-10-29",
    "bookName": "鬼吹灯",
    "author": "天下霸唱著"
  },
  {
    "name": "任思源",
    "borrowTime": "2023-09-20",
    "bookName": "天齐大陆",
    "author": "月下泷痕著"
  },
  {
    "name": "任枫焱",
    "borrowTime": "2025-03-05",
    "bookName": "长安的荔枝",
    "author": "马伯庸著"
  },
  {
    "name": "任枫焱",
    "borrowTime": "2025-03-05",
    "bookName": "好吗好的",
    "author": "大冰作品"
  },
  {
    "name": "任枫焱",
    "borrowTime": "2025-08-29",
    "bookName": "长安的荔枝",
    "author": "马伯庸著"
  },
  {
    "name": "任枫焱",
    "borrowTime": "2026-04-11",
    "bookName": "三毛传:活着就是要纵情绽放",
    "author": "沈念著"
  },
  {
    "name": "任枫焱",
    "borrowTime": "2026-04-20",
    "bookName": "一蓑烟雨任平生:苏东坡生平游记",
    "author": "张君民著"
  },
  {
    "name": "任翔睿",
    "borrowTime": "2023-10-18",
    "bookName": "诡计设计师:完美罪恶",
    "author": "张嘉骏作品"
  },
  {
    "name": "任翔睿",
    "borrowTime": "2023-11-03",
    "bookName": "诡计设计师:完美罪恶",
    "author": "张嘉骏作品"
  },
  {
    "name": "任翔睿",
    "borrowTime": "2023-11-03",
    "bookName": "风雪追击",
    "author": "(日)东野圭吾著"
  },
  {
    "name": "任翔睿",
    "borrowTime": "2023-11-12",
    "bookName": "朱威讲诡异案之诡异日记",
    "author": "朱威著"
  },
  {
    "name": "任翔睿",
    "borrowTime": "2023-12-03",
    "bookName": "幸存者",
    "author": "秦明著"
  },
  {
    "name": "任翔睿",
    "borrowTime": "2024-11-17",
    "bookName": "七宗罪:魔鬼的侧影:twenty-five years of FBI war stories.第3版",
    "author": "(美) 詹姆斯·博汀著"
  },
  {
    "name": "任翔睿",
    "borrowTime": "2024-11-17",
    "bookName": "绿房子",
    "author": "(秘鲁) 马里奥·巴尔加斯·略萨著"
  },
  {
    "name": "任翔睿",
    "borrowTime": "2024-11-24",
    "bookName": "十三步",
    "author": "莫言作品"
  },
  {
    "name": "伊思名",
    "borrowTime": "2023-10-21",
    "bookName": "阿Q正传",
    "author": "鲁迅著"
  },
  {
    "name": "伊思名",
    "borrowTime": "2024-07-04",
    "bookName": "如何杀死心中的怪物:摆脱不安和恐惧的心理技巧",
    "author": "(韩) 韩德贤著"
  },
  {
    "name": "伊思名",
    "borrowTime": "2025-11-10",
    "bookName": "皮囊",
    "author": "蔡崇达著"
  },
  {
    "name": "伊思名",
    "borrowTime": "2025-11-10",
    "bookName": "命运",
    "author": "蔡崇达著"
  },
  {
    "name": "伊思名",
    "borrowTime": "2025-11-10",
    "bookName": "黄帝内经",
    "author": "译评于春海, 杨楠, 范敦成"
  },
  {
    "name": "伊翀",
    "borrowTime": "2023-09-19",
    "bookName": "2020中国中篇小说年选",
    "author": "谢有顺编选"
  },
  {
    "name": "伊翀",
    "borrowTime": "2023-10-08",
    "bookName": "小泉八云精怪故事集",
    "author": "(日) 小泉八云著"
  },
  {
    "name": "伊翀",
    "borrowTime": "2026-03-27",
    "bookName": "城市轨道交通概论",
    "author": "刘建国, 张齐坤主编"
  },
  {
    "name": "伊翀",
    "borrowTime": "2026-03-27",
    "bookName": "城市轨道交通车辆技术",
    "author": "上海申通地铁集团有限公司, 轨道交通培训中心编著"
  },
  {
    "name": "何佳一",
    "borrowTime": "2023-11-11",
    "bookName": "星坟:望古神话",
    "author": "天使奥斯卡著"
  },
  {
    "name": "何佳一",
    "borrowTime": "2023-11-12",
    "bookName": "古剑屠魔录",
    "author": "月关著"
  },
  {
    "name": "何平",
    "borrowTime": "2023-11-29",
    "bookName": "富爸爸穷爸爸",
    "author": "(美) 罗伯特·清崎著"
  },
  {
    "name": "何平",
    "borrowTime": "2023-12-15",
    "bookName": "文化苦旅",
    "author": "余秋雨,"
  },
  {
    "name": "何平",
    "borrowTime": "2024-04-26",
    "bookName": "创业伦理",
    "author": "本力，秦弋著"
  },
  {
    "name": "何平",
    "borrowTime": "2024-06-11",
    "bookName": "沧浪之水",
    "author": "阎真著"
  },
  {
    "name": "何高权",
    "borrowTime": "2023-10-31",
    "bookName": "民调局异闻录.1,稚国迷窟",
    "author": "耳东水寿著"
  },
  {
    "name": "何高权",
    "borrowTime": "2023-11-29",
    "bookName": "诡秘之主.1,绯红之月",
    "author": "爱潜水的乌贼著"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-09-02",
    "bookName": "胰脏物语",
    "author": "(日) 住野夜著"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-09-04",
    "bookName": "夏目友人帐",
    "author": "漫画原作绿川幸"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-09-04",
    "bookName": "解忧杂货店",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-09-08",
    "bookName": "龙族.Ⅰ,火之晨曦",
    "author": "江南著"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-09-08",
    "bookName": "龙族.Ⅱ,悼亡者之瞳",
    "author": "江南著"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-09-22",
    "bookName": "一人之下.1",
    "author": "米二编绘"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-09-22",
    "bookName": "一人之下.2",
    "author": "米二编绘"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-09-22",
    "bookName": "龙族.Ⅱ,悼亡者之瞳",
    "author": "江南著"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-09-28",
    "bookName": "伍六七,玄武国篇.01",
    "author": "何小疯著绘"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-09-28",
    "bookName": "伍六七,玄武国篇.04",
    "author": "何小疯著绘"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-09-28",
    "bookName": "伍六七,玄武国篇.03",
    "author": "何小疯著绘"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-10-08",
    "bookName": "灵能百分百.1",
    "author": "(日)ONE绘著"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-10-08",
    "bookName": "灵能百分百.4",
    "author": "(日)ONE绘著"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-10-08",
    "bookName": "灵能百分百.3",
    "author": "(日)ONE绘著"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-10-08",
    "bookName": "灵能百分百.6",
    "author": "(日)ONE绘著"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-10-08",
    "bookName": "灵能百分百.5",
    "author": "(日)ONE绘著"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-10-10",
    "bookName": "灵能百分百.13",
    "author": "(日)ONE绘著"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-10-10",
    "bookName": "灵能百分百.12",
    "author": "(日)ONE绘著"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-10-10",
    "bookName": "灵能百分百.11",
    "author": "(日)ONE绘著"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-10-10",
    "bookName": "灵能百分百.10",
    "author": "(日)ONE绘著"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-10-10",
    "bookName": "灵能百分百.9",
    "author": "(日)ONE绘著"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-10-10",
    "bookName": "灵能百分百.7",
    "author": "(日)ONE绘著"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-10-10",
    "bookName": "灵能百分百.2",
    "author": "(日)ONE绘著"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-10-11",
    "bookName": "灵能百分百.13",
    "author": "(日)ONE绘著"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-10-11",
    "bookName": "灵能百分百.12",
    "author": "(日)ONE绘著"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-10-11",
    "bookName": "灵能百分百.8",
    "author": "(日)ONE绘著"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-10-14",
    "bookName": "灵能百分百.16",
    "author": "(日)ONE绘著"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-10-14",
    "bookName": "灵能百分百.14",
    "author": "(日)ONE绘著"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-10-14",
    "bookName": "灵能百分百.15",
    "author": "(日)ONE绘著"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-10-15",
    "bookName": "藤本树短篇集.22-26",
    "author": "(日)藤本树著"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-10-15",
    "bookName": "文豪野犬官方精选漫画集,晓,Akatsuki",
    "author": "(日)朝雾卡夫卡原作"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-10-15",
    "bookName": "人民的名义.修订版",
    "author": "周梅森著"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-10-15",
    "bookName": "文豪野犬官方精选漫画集,花,Hana",
    "author": "(日)朝雾卡夫卡原作"
  },
  {
    "name": "何高权",
    "borrowTime": "2024-11-20",
    "bookName": "蓝:陪安东尼度过漫长岁月VI:2020-2022:2020-2022",
    "author": "安东尼著"
  },
  {
    "name": "余程阳",
    "borrowTime": "2023-09-20",
    "bookName": "唐太宗",
    "author": "赵扬著"
  },
  {
    "name": "余程阳",
    "borrowTime": "2023-11-29",
    "bookName": "长安骊歌",
    "author": "郁馥著"
  },
  {
    "name": "余程阳",
    "borrowTime": "2023-12-12",
    "bookName": "长安骊歌",
    "author": "郁馥著"
  },
  {
    "name": "余程阳",
    "borrowTime": "2024-09-02",
    "bookName": "十宗罪.5",
    "author": "蜘蛛著"
  },
  {
    "name": "余程阳",
    "borrowTime": "2024-10-09",
    "bookName": "张居正.卷二,水龙吟",
    "author": "熊召政著"
  },
  {
    "name": "侯博帅",
    "borrowTime": "2023-09-25",
    "bookName": "罪全书.1",
    "author": "蜘蛛著"
  },
  {
    "name": "侯广涛",
    "borrowTime": "2023-09-22",
    "bookName": "斗罗大陆.第四部,终极斗罗.12",
    "author": "唐家三少著"
  },
  {
    "name": "侯广涛",
    "borrowTime": "2023-10-19",
    "bookName": "斗罗大陆.第二部,绝世唐门.24",
    "author": "唐家三少著"
  },
  {
    "name": "侯广涛",
    "borrowTime": "2023-10-19",
    "bookName": "斗罗大陆.第二部,绝世唐门.23",
    "author": "唐家三少著"
  },
  {
    "name": "信美伊",
    "borrowTime": "2023-09-20",
    "bookName": "萧红经典全集.第2版",
    "author": "萧红著"
  },
  {
    "name": "信美伊",
    "borrowTime": "2024-04-28",
    "bookName": "戏年",
    "author": "葛亮著"
  },
  {
    "name": "信美伊",
    "borrowTime": "2026-03-30",
    "bookName": "精编美国戏剧史.中文版",
    "author": "郭继德著"
  },
  {
    "name": "信美伊",
    "borrowTime": "2026-03-30",
    "bookName": "是你在歌唱？是我在遐想？:叶赛宁诗选",
    "author": "(俄)叶赛宁著"
  },
  {
    "name": "信美伊",
    "borrowTime": "2026-04-20",
    "bookName": "编剧",
    "author": "(美)威廉·戈德曼(William Goldman)著"
  },
  {
    "name": "信美伊",
    "borrowTime": "2026-04-20",
    "bookName": "卡拉马佐夫兄弟",
    "author": "(俄)陀思妥耶夫斯基著"
  },
  {
    "name": "信美伊",
    "borrowTime": "2026-04-20",
    "bookName": "世界戏剧学",
    "author": "余秋雨著"
  },
  {
    "name": "信美伊",
    "borrowTime": "2026-04-20",
    "bookName": "麦克白",
    "author": "(英) 莎士比亚著"
  },
  {
    "name": "信美伊",
    "borrowTime": "2026-04-22",
    "bookName": "易卜生戏剧诗学研究",
    "author": "汪余礼著"
  },
  {
    "name": "信美伊",
    "borrowTime": "2026-04-22",
    "bookName": "奥瑟罗",
    "author": "William Shakespeare"
  },
  {
    "name": "信美伊",
    "borrowTime": "2026-05-13",
    "bookName": "卡拉马佐夫兄弟",
    "author": "(俄)陀思妥耶夫斯基著"
  },
  {
    "name": "信美伊",
    "borrowTime": "2026-05-13",
    "bookName": "卡拉马佐夫兄弟",
    "author": "(俄)陀思妥耶夫斯基著"
  },
  {
    "name": "信美伊",
    "borrowTime": "2026-05-21",
    "bookName": "柯林斯COBUILD中阶英汉双解学习词典",
    "author": "英国柯林斯出版公司编"
  },
  {
    "name": "信美伊",
    "borrowTime": "2026-05-30",
    "bookName": "风声",
    "author": "麦家"
  },
  {
    "name": "关旭",
    "borrowTime": "2023-09-18",
    "bookName": "惩罚者:大结局,完美谎言",
    "author": "韦一同著"
  },
  {
    "name": "关瑞雪新",
    "borrowTime": "2023-10-10",
    "bookName": "自来水之污, 又名, 李泰和方小甜的平行世界",
    "author": "潇潇潇潇如编绘"
  },
  {
    "name": "关阳",
    "borrowTime": "2024-09-02",
    "bookName": "法律法规全书.第14版",
    "author": "国务院法制办公室编"
  },
  {
    "name": "关阳",
    "borrowTime": "2024-09-02",
    "bookName": "《铁路技术管理规程 (高速铁路部分) 》条文说明.中册",
    "author": "《技规》条文说明编写组"
  },
  {
    "name": "关阳",
    "borrowTime": "2024-09-02",
    "bookName": "中华人民共和国宪法典",
    "author": "法律出版社法规中心编"
  },
  {
    "name": "关阳",
    "borrowTime": "2024-09-02",
    "bookName": "中华人民共和国法律全书.第4版",
    "author": "国务院法制办公室编"
  },
  {
    "name": "关阳",
    "borrowTime": "2024-09-02",
    "bookName": "法律法规全书.第14版",
    "author": "国务院法制办公室编"
  },
  {
    "name": "关雯心",
    "borrowTime": "2023-09-25",
    "bookName": "心理罪.1,第七个读者",
    "author": "雷米著"
  },
  {
    "name": "关雯心",
    "borrowTime": "2023-09-25",
    "bookName": "心理罪.1,第七个读者",
    "author": "雷米著"
  },
  {
    "name": "农金露",
    "borrowTime": "2023-10-29",
    "bookName": "尸案调查科.2,重案捕手",
    "author": "九滴水著"
  },
  {
    "name": "冯家哲",
    "borrowTime": "2023-09-19",
    "bookName": "高手对决:从此, 再无搞不定的对手",
    "author": "何常在著"
  },
  {
    "name": "冯惺睿",
    "borrowTime": "2023-09-20",
    "bookName": "明朝那些事儿.增补版",
    "author": "当年明月著"
  },
  {
    "name": "冯惺睿",
    "borrowTime": "2023-11-23",
    "bookName": "明朝那些事儿.增补版",
    "author": "当年明月著"
  },
  {
    "name": "冯莘然",
    "borrowTime": "2023-11-20",
    "bookName": "女法医手记之破译密码",
    "author": "刘真著"
  },
  {
    "name": "冷雪松",
    "borrowTime": "2023-09-19",
    "bookName": "心理大师",
    "author": "钟宇作品"
  },
  {
    "name": "刘一鸣",
    "borrowTime": "2023-10-11",
    "bookName": "中国怪谈",
    "author": "赵志明著"
  },
  {
    "name": "刘一鸣",
    "borrowTime": "2023-10-11",
    "bookName": "世界经典悬疑故事.超值彩图版",
    "author": "白虹主编"
  },
  {
    "name": "刘一鸣",
    "borrowTime": "2023-10-31",
    "bookName": "怪诞实录",
    "author": "凤仪著"
  },
  {
    "name": "刘一鸣",
    "borrowTime": "2023-11-07",
    "bookName": "朱威讲诡异案之诡异日记",
    "author": "朱威著"
  },
  {
    "name": "刘一鸣",
    "borrowTime": "2023-11-07",
    "bookName": "鬼吹灯",
    "author": "天下霸唱著"
  },
  {
    "name": "刘一鸣",
    "borrowTime": "2023-12-18",
    "bookName": "你看完不敢睡, 看了还想看的悬疑小说.Ⅰ",
    "author": "白虹主编"
  },
  {
    "name": "刘丛睿",
    "borrowTime": "2023-11-08",
    "bookName": "秘密调查师之家族阴谋",
    "author": "永城著"
  },
  {
    "name": "刘丰硕",
    "borrowTime": "2023-09-25",
    "bookName": "诡秘之主.1,绯红之月",
    "author": "爱潜水的乌贼著"
  },
  {
    "name": "刘丰硕",
    "borrowTime": "2023-10-31",
    "bookName": "诡域迷局:神鹰王冠",
    "author": "诸葛宇聪作品"
  },
  {
    "name": "刘丰硕",
    "borrowTime": "2023-10-31",
    "bookName": "诡域迷局:神鹰王冠",
    "author": "诸葛宇聪作品"
  },
  {
    "name": "刘丰硕",
    "borrowTime": "2024-09-21",
    "bookName": "鬼吹灯",
    "author": "天下霸唱著"
  },
  {
    "name": "刘丰硕",
    "borrowTime": "2024-09-21",
    "bookName": "牧野诡事",
    "author": "天下霸唱著"
  },
  {
    "name": "刘丰端",
    "borrowTime": "2023-09-12",
    "bookName": "淘宝笔记",
    "author": "罗晓著"
  },
  {
    "name": "刘佳昊",
    "borrowTime": "2023-09-19",
    "bookName": "九州缥缈录.Ⅱ.Ⅱ,苍云古齿",
    "author": "江南著"
  },
  {
    "name": "刘佳昊",
    "borrowTime": "2023-09-27",
    "bookName": "窥天:香巴拉秘符",
    "author": "隔世醒人著"
  },
  {
    "name": "刘佳毅",
    "borrowTime": "2025-12-02",
    "bookName": "西游疯魔录,心魔祭",
    "author": "沐少尘著"
  },
  {
    "name": "刘冰硕",
    "borrowTime": "2025-06-07",
    "bookName": "电气工程与自动化专业英语.3版",
    "author": "王伟，张殿海，黄少坡主编"
  },
  {
    "name": "刘冰硕",
    "borrowTime": "2025-06-07",
    "bookName": "电气工程与自动化专业英语.3版",
    "author": "王伟，张殿海，黄少坡主编"
  },
  {
    "name": "刘勃希",
    "borrowTime": "2025-03-08",
    "bookName": "HXD3c型电力机车",
    "author": "《和谐型交流传动机车技术丛书》编委会著"
  },
  {
    "name": "刘勃希",
    "borrowTime": "2025-03-08",
    "bookName": "HXD3B型电力机车",
    "author": "《和谐型交流传动机车技术丛书》编委会著"
  },
  {
    "name": "刘勃希",
    "borrowTime": "2025-03-08",
    "bookName": "HXD3D型电力机车",
    "author": "《和谐型交流传动机车技术丛书》编委会著"
  },
  {
    "name": "刘千硕",
    "borrowTime": "2023-09-22",
    "bookName": "金棺陵兽",
    "author": "天下霸唱著"
  },
  {
    "name": "刘千硕",
    "borrowTime": "2023-09-22",
    "bookName": "尸案调查科.2,重案捕手",
    "author": "九滴水著"
  },
  {
    "name": "刘千硕",
    "borrowTime": "2023-09-22",
    "bookName": "尸案调查科.第二季.1,罪恶根源",
    "author": "九滴水著"
  },
  {
    "name": "刘千硕",
    "borrowTime": "2023-10-18",
    "bookName": "尸案调查科.2,重案捕手",
    "author": "九滴水著"
  },
  {
    "name": "刘千硕",
    "borrowTime": "2023-10-18",
    "bookName": "尸案调查科.第二季.1,罪恶根源",
    "author": "九滴水著"
  },
  {
    "name": "刘千硕",
    "borrowTime": "2023-11-16",
    "bookName": "尸案调查科.第二季.1,罪恶根源",
    "author": "九滴水著"
  },
  {
    "name": "刘千硕",
    "borrowTime": "2023-11-16",
    "bookName": "尸案调查科.2,重案捕手",
    "author": "九滴水著"
  },
  {
    "name": "刘圣裔",
    "borrowTime": "2023-11-13",
    "bookName": "中国怪谈",
    "author": "赵志明著"
  },
  {
    "name": "刘圣裔",
    "borrowTime": "2023-11-13",
    "bookName": "心理罪,第七个读者",
    "author": "雷米作品"
  },
  {
    "name": "刘圣裔",
    "borrowTime": "2023-11-22",
    "bookName": "武破苍穹.2",
    "author": "雨辰宇著"
  },
  {
    "name": "刘圣裔",
    "borrowTime": "2023-11-22",
    "bookName": "武破苍穹.3",
    "author": "雨辰宇著"
  },
  {
    "name": "刘圣裔",
    "borrowTime": "2023-11-22",
    "bookName": "武破苍穹.1",
    "author": "雨辰宇著"
  },
  {
    "name": "刘圣裔",
    "borrowTime": "2023-11-28",
    "bookName": "杀手皇妃.上",
    "author": "穆丹枫作品"
  },
  {
    "name": "刘圣裔",
    "borrowTime": "2024-09-05",
    "bookName": "夜幕之下",
    "author": "三九音域著"
  },
  {
    "name": "刘培贺",
    "borrowTime": "2023-09-19",
    "bookName": "隋唐演义:注释本",
    "author": "(清) 褚人获编撰"
  },
  {
    "name": "刘培贺",
    "borrowTime": "2023-09-19",
    "bookName": "希腊神话",
    "author": "(俄) 尼·库恩著"
  },
  {
    "name": "刘培贺",
    "borrowTime": "2023-11-20",
    "bookName": "法医专家",
    "author": "王文杰著"
  },
  {
    "name": "刘培贺",
    "borrowTime": "2024-05-09",
    "bookName": "剑来",
    "author": "烽火戏诸侯著"
  },
  {
    "name": "刘天城",
    "borrowTime": "2023-10-20",
    "bookName": "幸存者",
    "author": "法医秦明著"
  },
  {
    "name": "刘妍宏",
    "borrowTime": "2024-07-10",
    "bookName": "局外人:记忆坊版",
    "author": "(法)阿尔贝·加缪著"
  },
  {
    "name": "刘子硕",
    "borrowTime": "2023-09-14",
    "bookName": "明朝那些事儿.第1部,朱元璋: 从和尚到皇帝.图文精印版",
    "author": "当年明月著"
  },
  {
    "name": "刘子硕",
    "borrowTime": "2024-06-11",
    "bookName": "搜神记.2,龙神太子",
    "author": "树下野狐著"
  },
  {
    "name": "刘子硕",
    "borrowTime": "2024-09-02",
    "bookName": "余罪:我的刑侦笔记.1",
    "author": "常书欣著"
  },
  {
    "name": "刘宇欣",
    "borrowTime": "2023-09-18",
    "bookName": "一路向你",
    "author": "采采卷耳著"
  },
  {
    "name": "刘宇行",
    "borrowTime": "2023-09-25",
    "bookName": "拉普拉斯的魔女",
    "author": "(日)东野圭吾著"
  },
  {
    "name": "刘宏宇",
    "borrowTime": "2023-11-20",
    "bookName": "盗墓笔记.五",
    "author": "南派三叔著"
  },
  {
    "name": "刘宏宇",
    "borrowTime": "2023-11-24",
    "bookName": "盗墓玄机:长篇盗墓小说",
    "author": "朱晓翔著"
  },
  {
    "name": "刘宏宇",
    "borrowTime": "2023-11-24",
    "bookName": "古玉迷踪.2",
    "author": "冬雪晚晴著"
  },
  {
    "name": "刘宏宇",
    "borrowTime": "2024-09-05",
    "bookName": "清异录:饮食部分",
    "author": "(宋)陶谷撰"
  },
  {
    "name": "刘小瑜",
    "borrowTime": "2023-09-18",
    "bookName": "已逝去的年代",
    "author": "季羡林著"
  },
  {
    "name": "刘展志",
    "borrowTime": "2023-11-01",
    "bookName": "搜神记.1,神农使者",
    "author": "树下野狐著"
  },
  {
    "name": "刘展志",
    "borrowTime": "2023-11-08",
    "bookName": "搜神记.3,灵山十巫",
    "author": "树下野狐著"
  },
  {
    "name": "刘德来",
    "borrowTime": "2023-10-07",
    "bookName": "测谎师:首席测谎师的刑侦笔记",
    "author": "刘军著"
  },
  {
    "name": "刘德来",
    "borrowTime": "2023-10-11",
    "bookName": "千与千寻",
    "author": "(日)宫崎骏原作·脚本·导演"
  },
  {
    "name": "刘思良",
    "borrowTime": "2023-09-18",
    "bookName": "明朝那些事儿.增补版",
    "author": "当年明月著"
  },
  {
    "name": "刘思良",
    "borrowTime": "2023-10-28",
    "bookName": "地狱公寓.3",
    "author": "董协著"
  },
  {
    "name": "刘恒旭",
    "borrowTime": "2023-10-08",
    "bookName": "飞鸟集·新月集",
    "author": "(印度) 泰戈尔著"
  },
  {
    "name": "刘恒源",
    "borrowTime": "2025-12-10",
    "bookName": "列车运行监控装置 (LKJ)",
    "author": "中国铁路总公司"
  },
  {
    "name": "刘懿铭",
    "borrowTime": "2023-09-24",
    "bookName": "黄金瞳.1.1",
    "author": "打眼著"
  },
  {
    "name": "刘懿铭",
    "borrowTime": "2023-11-02",
    "bookName": "摸金传人.5,湘西蛊术",
    "author": "罗晓著"
  },
  {
    "name": "刘政佳",
    "borrowTime": "2023-09-26",
    "bookName": "九州缥缈录.Ⅲ.Ⅲ,天下名将",
    "author": "江南著"
  },
  {
    "name": "刘政佳",
    "borrowTime": "2023-10-12",
    "bookName": "大龟甲师.上",
    "author": "唐家三少著"
  },
  {
    "name": "刘政佳",
    "borrowTime": "2023-10-15",
    "bookName": "吞噬星空:典藏版.1",
    "author": "我吃西红柿著"
  },
  {
    "name": "刘政佳",
    "borrowTime": "2023-10-29",
    "bookName": "封魔师.1",
    "author": "陨落星辰著"
  },
  {
    "name": "刘文泽",
    "borrowTime": "2023-09-18",
    "bookName": "三日间的幸福",
    "author": "(日) 三秋缒著"
  },
  {
    "name": "刘文泽",
    "borrowTime": "2023-11-19",
    "bookName": "胰脏物语",
    "author": "(日) 住野夜著"
  },
  {
    "name": "刘文泽",
    "borrowTime": "2023-12-03",
    "bookName": "云之彼端, 约定的地方",
    "author": "(日) 新海诚原作"
  },
  {
    "name": "刘斌",
    "borrowTime": "2023-09-10",
    "bookName": "中国奇异档案记录.第四季",
    "author": "宋歌编著"
  },
  {
    "name": "刘旭",
    "borrowTime": "2023-10-07",
    "bookName": "天谴者",
    "author": "法医秦明著"
  },
  {
    "name": "刘昊霖",
    "borrowTime": "2023-09-23",
    "bookName": "丧钟为谁而鸣",
    "author": "(美) 欧内斯特·海明威著"
  },
  {
    "name": "刘明伟",
    "borrowTime": "2023-09-20",
    "bookName": "89号档案馆",
    "author": "孙铭苑著"
  },
  {
    "name": "刘明杨益",
    "borrowTime": "2023-11-08",
    "bookName": "东北往事.1",
    "author": "孔二狗著"
  },
  {
    "name": "刘明杨益",
    "borrowTime": "2023-11-08",
    "bookName": "黑案私探社",
    "author": "中雨作品"
  },
  {
    "name": "刘昕骏",
    "borrowTime": "2023-11-16",
    "bookName": "楚汉传奇",
    "author": "姚尧著"
  },
  {
    "name": "刘李天琪",
    "borrowTime": "2023-10-31",
    "bookName": "风雪追击",
    "author": "(日)东野圭吾著"
  },
  {
    "name": "刘李天琪",
    "borrowTime": "2024-06-13",
    "bookName": "岸边露伴在卢浮",
    "author": "(日)荒木飞吕彦著"
  },
  {
    "name": "刘李天琪",
    "borrowTime": "2024-06-16",
    "bookName": "脑髓地狱",
    "author": "(日)梦野久作著"
  },
  {
    "name": "刘李天琪",
    "borrowTime": "2024-09-02",
    "bookName": "脑髓地狱",
    "author": "(日)梦野久作著"
  },
  {
    "name": "刘李天琪",
    "borrowTime": "2025-04-22",
    "bookName": "乔乔的奇妙名言集.Part4~8",
    "author": "(日)荒木飞吕彦著"
  },
  {
    "name": "刘柏良",
    "borrowTime": "2023-10-20",
    "bookName": "沧元图.1",
    "author": "我吃西红柿著"
  },
  {
    "name": "刘柏良",
    "borrowTime": "2024-04-28",
    "bookName": "中国奇异档案记录.第四季",
    "author": "宋歌编著"
  },
  {
    "name": "刘树骏",
    "borrowTime": "2023-10-07",
    "bookName": "天道图书馆.2,龙争虎斗",
    "author": "横扫天涯著"
  },
  {
    "name": "刘欣禹",
    "borrowTime": "2023-10-16",
    "bookName": "魔兽战神.3",
    "author": "龙人著"
  },
  {
    "name": "刘欣鑫",
    "borrowTime": "2023-09-19",
    "bookName": "痕迹",
    "author": "毕蔷著"
  },
  {
    "name": "刘泓杰",
    "borrowTime": "2023-09-05",
    "bookName": "罪全书.4",
    "author": "蜘蛛著"
  },
  {
    "name": "刘浩",
    "borrowTime": "2023-11-24",
    "bookName": "细雨湿流光",
    "author": "余思著"
  },
  {
    "name": "刘浩",
    "borrowTime": "2023-11-24",
    "bookName": "良辰多喜欢",
    "author": "原城著"
  },
  {
    "name": "刘浩",
    "borrowTime": "2023-11-24",
    "bookName": "浅情人不知",
    "author": "师小札著"
  },
  {
    "name": "刘浩",
    "borrowTime": "2023-11-27",
    "bookName": "晚风过雾舟",
    "author": "归渔著"
  },
  {
    "name": "刘浩",
    "borrowTime": "2023-12-09",
    "bookName": "甜而不知娇",
    "author": "浅水色著"
  },
  {
    "name": "刘浴鑫",
    "borrowTime": "2023-09-25",
    "bookName": "法眼",
    "author": "木森著"
  },
  {
    "name": "刘浴鑫",
    "borrowTime": "2023-10-10",
    "bookName": "诡案组外传",
    "author": "求无欲著"
  },
  {
    "name": "刘浴鑫",
    "borrowTime": "2023-10-10",
    "bookName": "原罪.1,迷案追踪",
    "author": "一曲东风著"
  },
  {
    "name": "刘浴鑫",
    "borrowTime": "2023-10-12",
    "bookName": "白夜追凶",
    "author": "剧本原著指纹"
  },
  {
    "name": "刘润泽",
    "borrowTime": "2023-10-06",
    "bookName": "明朝那些事儿.增补版",
    "author": "当年明月著"
  },
  {
    "name": "刘润泽",
    "borrowTime": "2023-10-15",
    "bookName": "明朝那些事儿.增补版",
    "author": "当年明月著"
  },
  {
    "name": "刘润泽",
    "borrowTime": "2023-10-24",
    "bookName": "谋杀狄更斯.上",
    "author": "(美) 丹·西蒙斯著"
  },
  {
    "name": "刘润泽",
    "borrowTime": "2023-11-30",
    "bookName": "明朝那些事儿.增补版",
    "author": "当年明月著"
  },
  {
    "name": "刘润泽",
    "borrowTime": "2024-06-04",
    "bookName": "绝对零度.1,飞天",
    "author": "樊落著"
  },
  {
    "name": "刘润泽",
    "borrowTime": "2025-03-20",
    "bookName": "明朝那些事儿.增补版",
    "author": "当年明月著"
  },
  {
    "name": "刘润泽",
    "borrowTime": "2025-04-20",
    "bookName": "英语语法新编",
    "author": "黄红兵，雷鹏飞，许西美主编"
  },
  {
    "name": "刘润泽",
    "borrowTime": "2025-04-20",
    "bookName": "英语语法新编",
    "author": "黄红兵，雷鹏飞，许西美主编"
  },
  {
    "name": "刘炜",
    "borrowTime": "2024-05-24",
    "bookName": "灿烂散文:散文历史与艺术特色",
    "author": "肖东发主编"
  },
  {
    "name": "刘玉乔",
    "borrowTime": "2026-05-27",
    "bookName": "铁路车辆概论",
    "author": "中国国家铁路集团有限公司机辆部主编"
  },
  {
    "name": "刘琦",
    "borrowTime": "2023-09-04",
    "bookName": "女法医手记之破译密码",
    "author": "刘真著"
  },
  {
    "name": "刘瑞涵",
    "borrowTime": "2023-10-08",
    "bookName": "必须犯规的游戏:大结局",
    "author": "宁航一著"
  },
  {
    "name": "刘生鑫",
    "borrowTime": "2023-09-26",
    "bookName": "说话心理学",
    "author": "连山编著"
  },
  {
    "name": "刘畅",
    "borrowTime": "2023-10-10",
    "bookName": "狼王梦",
    "author": "沈石溪著"
  },
  {
    "name": "刘百川",
    "borrowTime": "2023-11-11",
    "bookName": "中文版Photoshop基础培训教程",
    "author": "数字艺术教育研究室编著"
  },
  {
    "name": "刘百川",
    "borrowTime": "2023-11-11",
    "bookName": "中文Photoshop CS5案例教程",
    "author": "张伦, 沈大林主编"
  },
  {
    "name": "刘百川",
    "borrowTime": "2024-11-19",
    "bookName": "夏目友人帐",
    "author": "漫画原作绿川幸"
  },
  {
    "name": "刘百川",
    "borrowTime": "2024-11-19",
    "bookName": "余罪:我的刑侦笔记.3:一个传奇警察和毒贩、悍匪、黑道大佬的交锋实录",
    "author": "常书欣著"
  },
  {
    "name": "刘石",
    "borrowTime": "2023-11-12",
    "bookName": "国家机密,隐藏杀机",
    "author": "李李著"
  },
  {
    "name": "刘磊",
    "borrowTime": "2023-10-20",
    "bookName": "法医档案.03,迟来真相.03,Truth comes late",
    "author": "戴西著"
  },
  {
    "name": "刘磊",
    "borrowTime": "2023-10-20",
    "bookName": "鬼吹灯",
    "author": "天下霸唱著"
  },
  {
    "name": "刘磊",
    "borrowTime": "2023-11-17",
    "bookName": "战火中的将军:抗战中的著名将领",
    "author": "苏易编著"
  },
  {
    "name": "刘磊",
    "borrowTime": "2023-11-26",
    "bookName": "隋唐演义:注释本",
    "author": "(清) 褚人获编撰"
  },
  {
    "name": "刘磊",
    "borrowTime": "2023-12-01",
    "bookName": "梦回大汉",
    "author": "玉清秋著"
  },
  {
    "name": "刘磊",
    "borrowTime": "2023-12-01",
    "bookName": "沧元图.1",
    "author": "我吃西红柿著"
  },
  {
    "name": "刘胤博",
    "borrowTime": "2024-05-16",
    "bookName": "铁路红色故事",
    "author": "中国国家铁路集团有限公司党组宣传部[编著]"
  },
  {
    "name": "刘致麟",
    "borrowTime": "2023-09-19",
    "bookName": "你看完不敢睡, 看了还想看的悬疑小说.Ⅰ",
    "author": "白虹主编"
  },
  {
    "name": "刘葵荣",
    "borrowTime": "2023-09-21",
    "bookName": "三体",
    "author": "刘慈欣著"
  },
  {
    "name": "刘葵荣",
    "borrowTime": "2023-10-06",
    "bookName": "三体.Ⅲ,死神永生.Ⅲ,Dead end",
    "author": "刘慈欣著"
  },
  {
    "name": "刘越鹏",
    "borrowTime": "2023-09-24",
    "bookName": "人世间",
    "author": "梁晓声著"
  },
  {
    "name": "刘连忠",
    "borrowTime": "2023-10-09",
    "bookName": "天才在左 疯子在右",
    "author": "高铭著"
  },
  {
    "name": "刘鑫宇",
    "borrowTime": "2023-11-11",
    "bookName": "阴谋论",
    "author": "(英) 安迪·托马斯著"
  },
  {
    "name": "刘鑫宇",
    "borrowTime": "2023-12-01",
    "bookName": "犯罪心理档案.第三季",
    "author": "刚雪印作品"
  },
  {
    "name": "刘镇玮",
    "borrowTime": "2023-10-08",
    "bookName": "封魔师.1",
    "author": "陨落星辰著"
  },
  {
    "name": "刘镇玮",
    "borrowTime": "2023-10-12",
    "bookName": "封魔师.2",
    "author": "陨落星辰著"
  },
  {
    "name": "刘镇玮",
    "borrowTime": "2023-10-15",
    "bookName": "天道图书馆.2,龙争虎斗",
    "author": "横扫天涯著"
  },
  {
    "name": "刘镇玮",
    "borrowTime": "2023-10-17",
    "bookName": "武破苍穹.1",
    "author": "雨辰宇著"
  },
  {
    "name": "刘镇玮",
    "borrowTime": "2023-10-17",
    "bookName": "武破苍穹.2",
    "author": "雨辰宇著"
  },
  {
    "name": "刘飛",
    "borrowTime": "2023-10-21",
    "bookName": "余罪:我的刑侦笔记.7",
    "author": "常书欣著"
  },
  {
    "name": "刘飛",
    "borrowTime": "2023-10-21",
    "bookName": "余罪:我的刑侦笔记.8",
    "author": "常书欣著"
  },
  {
    "name": "刘飛",
    "borrowTime": "2023-11-08",
    "bookName": "鉴谎",
    "author": "钱来来著"
  },
  {
    "name": "刘飛",
    "borrowTime": "2023-11-08",
    "bookName": "鉴谎",
    "author": "钱来来著"
  },
  {
    "name": "刘鹤彰",
    "borrowTime": "2023-09-19",
    "bookName": "牛天赐传",
    "author": "老舍著"
  },
  {
    "name": "卜铭研",
    "borrowTime": "2023-09-16",
    "bookName": "巴黎圣母院",
    "author": "(法)维克多·雨果著"
  },
  {
    "name": "卜铭研",
    "borrowTime": "2024-05-16",
    "bookName": "马克思家庭思想研究",
    "author": "钟路著"
  },
  {
    "name": "卜铭研",
    "borrowTime": "2024-05-29",
    "bookName": "邓小平在1992",
    "author": "刘金田著"
  },
  {
    "name": "卞浩然",
    "borrowTime": "2023-10-29",
    "bookName": "无证之罪.第2版",
    "author": "紫金陈著"
  },
  {
    "name": "占勇强",
    "borrowTime": "2023-09-12",
    "bookName": "时光不矜持",
    "author": "槭语暄作品"
  },
  {
    "name": "占勇强",
    "borrowTime": "2025-10-26",
    "bookName": "日语会话一本通:日常日语口语3000句",
    "author": "周宇燕编著"
  },
  {
    "name": "占勇强",
    "borrowTime": "2025-10-26",
    "bookName": "人人读日语, 这样阅读最有效!",
    "author": "张超泽, 张影编著"
  },
  {
    "name": "占勇强",
    "borrowTime": "2025-10-26",
    "bookName": "人人读日语, 这样阅读最有效!",
    "author": "张超泽, 张影编著"
  },
  {
    "name": "卢俊安",
    "borrowTime": "2023-10-04",
    "bookName": "摄影的激情:50位摄影师的照片与故事",
    "author": "德国seen.by网站编"
  },
  {
    "name": "卢嘉明",
    "borrowTime": "2023-10-30",
    "bookName": "黄金瞳.4.4",
    "author": "打眼著"
  },
  {
    "name": "卢嘉明",
    "borrowTime": "2023-10-30",
    "bookName": "原罪.2,暗夜使徒",
    "author": "一曲东风著"
  },
  {
    "name": "卢嘉明",
    "borrowTime": "2023-10-30",
    "bookName": "黄金瞳.4.4",
    "author": "打眼著"
  },
  {
    "name": "卢帅",
    "borrowTime": "2023-11-14",
    "bookName": "牧野诡事",
    "author": "天下霸唱著"
  },
  {
    "name": "卢帅",
    "borrowTime": "2024-05-12",
    "bookName": "诡案罪.4",
    "author": "岳勇著"
  },
  {
    "name": "卢文龙",
    "borrowTime": "2023-11-14",
    "bookName": "明朝那些事儿.增补版",
    "author": "当年明月著"
  },
  {
    "name": "卢文龙",
    "borrowTime": "2023-11-23",
    "bookName": "明朝那些事儿.增补版",
    "author": "当年明月著"
  },
  {
    "name": "卢文龙",
    "borrowTime": "2023-12-05",
    "bookName": "明朝那些事儿.增补版",
    "author": "当年明月著"
  },
  {
    "name": "卢新欣",
    "borrowTime": "2023-09-12",
    "bookName": "沧元图.1",
    "author": "我吃西红柿著"
  },
  {
    "name": "卢新欣",
    "borrowTime": "2023-09-12",
    "bookName": "天齐大陆",
    "author": "月下泷痕著"
  },
  {
    "name": "卢新欣",
    "borrowTime": "2023-09-19",
    "bookName": "三年二班",
    "author": "魔女恩恩著"
  },
  {
    "name": "卢浩榆",
    "borrowTime": "2023-09-12",
    "bookName": "每一座荒城都有温柔童话",
    "author": "希雅著"
  },
  {
    "name": "卢浩榆",
    "borrowTime": "2023-09-12",
    "bookName": "告白",
    "author": "杨思萦著"
  },
  {
    "name": "卢浩榆",
    "borrowTime": "2023-10-08",
    "bookName": "女往无前",
    "author": "烟波人长安著"
  },
  {
    "name": "卢浩榆",
    "borrowTime": "2023-10-19",
    "bookName": "三年二班",
    "author": "魔女恩恩著"
  },
  {
    "name": "卢浩榆",
    "borrowTime": "2025-05-04",
    "bookName": "中华人民共和国民法典:专业实务版",
    "author": "中国法制出版社"
  },
  {
    "name": "史云辉",
    "borrowTime": "2026-03-10",
    "bookName": "建筑设备",
    "author": "戴建中, 赵中永主编"
  },
  {
    "name": "史云辉",
    "borrowTime": "2026-03-10",
    "bookName": "建筑设备",
    "author": "王锡琴主编"
  },
  {
    "name": "史嘉鹏",
    "borrowTime": "2023-10-17",
    "bookName": "死亡解剖台",
    "author": "(美) 斐德列克·萨吉伯著"
  },
  {
    "name": "史嘉鹏",
    "borrowTime": "2023-11-06",
    "bookName": "怪兽",
    "author": "雁北堂主编"
  },
  {
    "name": "史嘉鹏",
    "borrowTime": "2023-11-12",
    "bookName": "地底世界之幽潜重泉",
    "author": "天下霸唱著"
  },
  {
    "name": "史文泽",
    "borrowTime": "2023-10-21",
    "bookName": "操盘:千股涨停",
    "author": "许枫著"
  },
  {
    "name": "史文泽",
    "borrowTime": "2023-12-11",
    "bookName": "美国海军陆战队图鉴.上册,两栖作战部队",
    "author": "王强编著"
  },
  {
    "name": "史文泽",
    "borrowTime": "2024-05-16",
    "bookName": "明朝那些事儿.第1部,朱元璋: 从和尚到皇帝.图文精印版",
    "author": "当年明月著"
  },
  {
    "name": "史策燃",
    "borrowTime": "2023-09-19",
    "bookName": "尸案调查科.第二季.1,罪恶根源",
    "author": "九滴水著"
  },
  {
    "name": "司刚明",
    "borrowTime": "2023-09-07",
    "bookName": "解忧杂货店",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "司刚明",
    "borrowTime": "2023-09-18",
    "bookName": "黄金瞳.1.1",
    "author": "打眼著"
  },
  {
    "name": "司刚明",
    "borrowTime": "2023-09-26",
    "bookName": "黄金瞳.6.6",
    "author": "打眼著"
  },
  {
    "name": "司刚明",
    "borrowTime": "2023-11-05",
    "bookName": "画魔",
    "author": "轩胖儿著"
  },
  {
    "name": "吉赞宇",
    "borrowTime": "2023-10-23",
    "bookName": "明朝那些事儿.增补版",
    "author": "当年明月著"
  },
  {
    "name": "吉赞宇",
    "borrowTime": "2023-10-30",
    "bookName": "明朝那些事儿.第1部,朱元璋: 从和尚到皇帝.图文精印版",
    "author": "当年明月著"
  },
  {
    "name": "吉赞宇",
    "borrowTime": "2024-09-18",
    "bookName": "四级词汇词根+联想记忆法",
    "author": "俞敏洪编著"
  },
  {
    "name": "吉赞宇",
    "borrowTime": "2024-11-12",
    "bookName": "四级词汇词根+联想记忆法",
    "author": "俞敏洪编著"
  },
  {
    "name": "吕佰延",
    "borrowTime": "2023-10-16",
    "bookName": "女法医手记之破译密码",
    "author": "刘真著"
  },
  {
    "name": "吕佰延",
    "borrowTime": "2023-11-15",
    "bookName": "瓦尔登湖:博物图鉴版",
    "author": "(美) 亨利·戴维·梭罗著"
  },
  {
    "name": "吕晋安",
    "borrowTime": "2023-12-04",
    "bookName": "世界简史",
    "author": "何炳松著"
  },
  {
    "name": "吕柯",
    "borrowTime": "2023-11-17",
    "bookName": "怪诞故事集",
    "author": "(意) 伊塔洛·卡尔维诺编"
  },
  {
    "name": "吕柯",
    "borrowTime": "2023-11-19",
    "bookName": "印度异闻录",
    "author": "羊行屮著"
  },
  {
    "name": "吕柯",
    "borrowTime": "2024-06-24",
    "bookName": "吞噬星空:典藏版.1",
    "author": "我吃西红柿著"
  },
  {
    "name": "吕柯",
    "borrowTime": "2024-06-24",
    "bookName": "沙海.第二卷,沙蟒蛇巢",
    "author": "南派三叔著"
  },
  {
    "name": "吕梦",
    "borrowTime": "2023-12-01",
    "bookName": "遇见你就烂漫了",
    "author": "蝶之灵作品"
  },
  {
    "name": "吕浩博",
    "borrowTime": "2023-09-21",
    "bookName": "超禁忌游戏.1",
    "author": "宁航一著"
  },
  {
    "name": "吕辉",
    "borrowTime": "2024-09-08",
    "bookName": "嵬城.1,血路",
    "author": "冷露著"
  },
  {
    "name": "吕鑫",
    "borrowTime": "2025-04-09",
    "bookName": "人生海海",
    "author": "麦家著"
  },
  {
    "name": "吕鑫",
    "borrowTime": "2025-10-27",
    "bookName": "蛤蟆先生去看心理医生",
    "author": "(英)罗伯特·戴博德(Robert de Board)著"
  },
  {
    "name": "吴乙灼",
    "borrowTime": "2023-10-30",
    "bookName": "明朝那些事儿.增补版",
    "author": "当年明月著"
  },
  {
    "name": "吴乙灼",
    "borrowTime": "2023-11-10",
    "bookName": "黄金瞳.2.2",
    "author": "打眼著"
  },
  {
    "name": "吴乙灼",
    "borrowTime": "2023-11-10",
    "bookName": "黄金瞳.1.1",
    "author": "打眼著"
  },
  {
    "name": "吴乙灼",
    "borrowTime": "2023-11-17",
    "bookName": "淘宝高手.2:淘宝淘尽世间珍宝 收藏崛起亿万富豪",
    "author": "张小斌著"
  },
  {
    "name": "吴乙灼",
    "borrowTime": "2023-11-17",
    "bookName": "淘宝高手:淘宝淘尽世间珍宝 收藏崛起亿万富豪",
    "author": "张小斌著"
  },
  {
    "name": "吴乙灼",
    "borrowTime": "2024-05-20",
    "bookName": "无证之罪.第2版",
    "author": "紫金陈著"
  },
  {
    "name": "吴乙灼",
    "borrowTime": "2024-05-20",
    "bookName": "福尔摩斯探案全集",
    "author": "(英) 柯南·道尔著"
  },
  {
    "name": "吴俊仪",
    "borrowTime": "2023-09-25",
    "bookName": "悖论13.3版",
    "author": "(日)东野圭吾著"
  },
  {
    "name": "吴俊仪",
    "borrowTime": "2023-10-06",
    "bookName": "11字谜案",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "吴俊仪",
    "borrowTime": "2023-12-19",
    "bookName": "牧野诡事",
    "author": "天下霸唱著"
  },
  {
    "name": "吴光正",
    "borrowTime": "2023-09-18",
    "bookName": "世界经典悬疑故事.超值彩图版",
    "author": "白虹主编"
  },
  {
    "name": "吴季星",
    "borrowTime": "2023-10-08",
    "bookName": "平凡的世界",
    "author": "路遥著"
  },
  {
    "name": "吴季星",
    "borrowTime": "2023-10-30",
    "bookName": "平凡的世界",
    "author": "路遥著"
  },
  {
    "name": "吴季星",
    "borrowTime": "2024-05-08",
    "bookName": "丰乳肥臀",
    "author": "莫言 [著]"
  },
  {
    "name": "吴季星",
    "borrowTime": "2024-09-02",
    "bookName": "兄弟.第3版",
    "author": "余华"
  },
  {
    "name": "吴季星",
    "borrowTime": "2024-09-18",
    "bookName": "在细雨中呼喊.第3版",
    "author": "余华"
  },
  {
    "name": "吴季星",
    "borrowTime": "2024-10-08",
    "bookName": "红树林",
    "author": "莫言作品"
  },
  {
    "name": "吴昊峻",
    "borrowTime": "2023-10-30",
    "bookName": "海盗鬼皮书",
    "author": "旋翼之刃著"
  },
  {
    "name": "吴松延",
    "borrowTime": "2023-11-28",
    "bookName": "踏着月光的行板",
    "author": "迟子建著"
  },
  {
    "name": "吴松延",
    "borrowTime": "2023-12-05",
    "bookName": "牧野诡事",
    "author": "天下霸唱著"
  },
  {
    "name": "吴松延",
    "borrowTime": "2024-04-28",
    "bookName": "白夜行.第2版",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "吴松延",
    "borrowTime": "2024-04-28",
    "bookName": "诡秘之主.1,绯红之月",
    "author": "爱潜水的乌贼著"
  },
  {
    "name": "吴松延",
    "borrowTime": "2024-05-29",
    "bookName": "从红月开始",
    "author": "黑山老鬼著"
  },
  {
    "name": "吴松延",
    "borrowTime": "2024-05-29",
    "bookName": "守夜者.1,罪案终结者的觉醒",
    "author": "法医秦明著"
  },
  {
    "name": "吴松延",
    "borrowTime": "2024-05-29",
    "bookName": "盗墓笔记.3,云顶天宫",
    "author": "南派三叔著"
  },
  {
    "name": "吴松延",
    "borrowTime": "2024-09-08",
    "bookName": "大奉打更人",
    "author": "卖报小郎君著"
  },
  {
    "name": "吴松延",
    "borrowTime": "2024-09-23",
    "bookName": "怪物同学会",
    "author": "全球华语科幻星云奖组委会编"
  },
  {
    "name": "吴松延",
    "borrowTime": "2024-09-24",
    "bookName": "幸存者",
    "author": "法医秦明著"
  },
  {
    "name": "吴松延",
    "borrowTime": "2024-09-24",
    "bookName": "守夜者.2,黑暗潜能",
    "author": "法医秦明著"
  },
  {
    "name": "吴松延",
    "borrowTime": "2024-11-06",
    "bookName": "九州缥缈录.Ⅰ,蛮荒.修订版",
    "author": "江南著"
  },
  {
    "name": "吴松延",
    "borrowTime": "2024-11-06",
    "bookName": "九州缥缈录.Ⅰ,蛮荒.修订版",
    "author": "江南著"
  },
  {
    "name": "吴松延",
    "borrowTime": "2024-12-09",
    "bookName": "秘密",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "吴松延",
    "borrowTime": "2025-03-05",
    "bookName": "假面饭店.第2版",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "吴松延",
    "borrowTime": "2025-03-05",
    "bookName": "龙族.Ⅳ,奥丁之渊",
    "author": "江南著"
  },
  {
    "name": "吴松延",
    "borrowTime": "2025-03-05",
    "bookName": "龙族.Ⅱ,悼亡者之瞳",
    "author": "江南著"
  },
  {
    "name": "吴焕",
    "borrowTime": "2023-10-21",
    "bookName": "四世同堂",
    "author": "老舍著"
  },
  {
    "name": "吴焕",
    "borrowTime": "2023-10-30",
    "bookName": "长夜难明",
    "author": "紫金陈著"
  },
  {
    "name": "吴焕",
    "borrowTime": "2023-10-30",
    "bookName": "飘",
    "author": "(美) 玛格丽特·米切尔著"
  },
  {
    "name": "吴焕",
    "borrowTime": "2024-05-20",
    "bookName": "红树林",
    "author": "莫言作品"
  },
  {
    "name": "吴焕",
    "borrowTime": "2025-03-05",
    "bookName": "活着.2版",
    "author": "余华著"
  },
  {
    "name": "吴福印",
    "borrowTime": "2023-12-04",
    "bookName": "恶魔之地:洛夫克拉夫特乡",
    "author": "(美) 马特·拉夫著"
  },
  {
    "name": "吴福印",
    "borrowTime": "2023-12-04",
    "bookName": "诡秘之主.1,绯红之月",
    "author": "爱潜水的乌贼著"
  },
  {
    "name": "吴禹睿",
    "borrowTime": "2023-09-20",
    "bookName": "格里莎三部曲.Ⅰ,太阳召唤",
    "author": "(美) 李·巴杜格著"
  },
  {
    "name": "吴自豪",
    "borrowTime": "2023-10-19",
    "bookName": "山海经,赤影传说.上",
    "author": "原创故事豆丁, 易小草, 耀之"
  },
  {
    "name": "吴自豪",
    "borrowTime": "2024-09-22",
    "bookName": "摸金传人.5,湘西蛊术",
    "author": "罗晓著"
  },
  {
    "name": "吴致旭",
    "borrowTime": "2023-10-16",
    "bookName": "摸金校尉之九幽将军",
    "author": "天下霸唱著"
  },
  {
    "name": "吴致旭",
    "borrowTime": "2023-10-16",
    "bookName": "诡计设计师:完美罪恶",
    "author": "张嘉骏作品"
  },
  {
    "name": "吴蒙献",
    "borrowTime": "2023-10-23",
    "bookName": "血色现场",
    "author": "暗夜著"
  },
  {
    "name": "吴蒙献",
    "borrowTime": "2023-10-23",
    "bookName": "血色现场",
    "author": "暗夜著"
  },
  {
    "name": "吴蒙献",
    "borrowTime": "2023-11-01",
    "bookName": "诡案罪.4",
    "author": "岳勇著"
  },
  {
    "name": "吴蒙献",
    "borrowTime": "2023-11-01",
    "bookName": "狼图腾.修订版",
    "author": "姜戎著"
  },
  {
    "name": "吴限",
    "borrowTime": "2024-09-25",
    "bookName": "工程制图习题集",
    "author": "汪正俊主编"
  },
  {
    "name": "吴限",
    "borrowTime": "2024-09-25",
    "bookName": "工程制图",
    "author": "张新来主编"
  },
  {
    "name": "周俊杰",
    "borrowTime": "2023-09-25",
    "bookName": "慢慢来, 谈一场不赶时间的恋爱",
    "author": "吴雅楠著"
  },
  {
    "name": "周喜旺",
    "borrowTime": "2023-10-16",
    "bookName": "奋不顾身爱上你",
    "author": "伊达公主著"
  },
  {
    "name": "周喜旺",
    "borrowTime": "2023-10-17",
    "bookName": "兄弟.第3版",
    "author": "余华"
  },
  {
    "name": "周喜旺",
    "borrowTime": "2023-10-17",
    "bookName": "2020中国中篇小说年选",
    "author": "谢有顺编选"
  },
  {
    "name": "周喜旺",
    "borrowTime": "2023-11-22",
    "bookName": "糟糕, 是心动的感觉",
    "author": "梓榆著"
  },
  {
    "name": "周天赐",
    "borrowTime": "2023-10-16",
    "bookName": "兽血大陆.5",
    "author": "灵隐狐著"
  },
  {
    "name": "周天赐",
    "borrowTime": "2023-10-16",
    "bookName": "兽血大陆.3",
    "author": "灵隐狐著"
  },
  {
    "name": "周天赐",
    "borrowTime": "2023-10-16",
    "bookName": "兽血大陆.4",
    "author": "灵隐狐著"
  },
  {
    "name": "周天赐",
    "borrowTime": "2026-03-04",
    "bookName": "胰脏物语",
    "author": "(日)住野夜著"
  },
  {
    "name": "周子皓",
    "borrowTime": "2023-10-30",
    "bookName": "修女安魂曲.修订版",
    "author": "(法) 阿尔贝·加缪著"
  },
  {
    "name": "周明玉",
    "borrowTime": "2024-10-08",
    "bookName": "瓦尔登湖:博物图鉴版",
    "author": "(美) 亨利·戴维·梭罗著"
  },
  {
    "name": "周明玉",
    "borrowTime": "2024-10-20",
    "bookName": "瓦尔登湖:博物图鉴版",
    "author": "(美) 亨利·戴维·梭罗著"
  },
  {
    "name": "周明玉",
    "borrowTime": "2025-09-11",
    "bookName": "一人之下.2",
    "author": "米二编绘"
  },
  {
    "name": "周明玉",
    "borrowTime": "2025-09-11",
    "bookName": "理智与情感",
    "author": "(英) 简·奥斯汀著"
  },
  {
    "name": "周星名",
    "borrowTime": "2023-10-11",
    "bookName": "触不到的你",
    "author": "宅小花著"
  },
  {
    "name": "周星名",
    "borrowTime": "2024-05-06",
    "bookName": "朱公案",
    "author": "广思著"
  },
  {
    "name": "周星名",
    "borrowTime": "2024-05-10",
    "bookName": "北欧神话",
    "author": "(爱尔兰)帕德里克·科勒姆著"
  },
  {
    "name": "周清松",
    "borrowTime": "2023-10-18",
    "bookName": "原罪.3,拔云见日",
    "author": "一曲东风著"
  },
  {
    "name": "周清松",
    "borrowTime": "2024-09-02",
    "bookName": "龙族.Ⅳ,奥丁之渊",
    "author": "江南著"
  },
  {
    "name": "周煜博",
    "borrowTime": "2023-11-16",
    "bookName": "西游疯魔录,心魔祭",
    "author": "沐少尘著"
  },
  {
    "name": "周煜晟",
    "borrowTime": "2023-09-25",
    "bookName": "外层空间,水晶之匙",
    "author": "刘波著"
  },
  {
    "name": "周煜晟",
    "borrowTime": "2023-10-06",
    "bookName": "清道夫",
    "author": "秦明著"
  },
  {
    "name": "周煜晟",
    "borrowTime": "2023-10-18",
    "bookName": "白夜追凶",
    "author": "剧本原著指纹"
  },
  {
    "name": "周煜晟",
    "borrowTime": "2023-11-16",
    "bookName": "搜神记.2,龙神太子",
    "author": "树下野狐著"
  },
  {
    "name": "周煜晟",
    "borrowTime": "2023-11-24",
    "bookName": "摸金传人.1,明陵疑冢",
    "author": "罗晓著"
  },
  {
    "name": "周煜晟",
    "borrowTime": "2023-11-24",
    "bookName": "摸金传人.2,摄魂奇珠",
    "author": "罗晓著"
  },
  {
    "name": "周煜晟",
    "borrowTime": "2023-12-05",
    "bookName": "地狱变.新版",
    "author": "蔡骏著"
  },
  {
    "name": "周煜晟",
    "borrowTime": "2023-12-11",
    "bookName": "寻情记.2,锡杖",
    "author": "鬼山僧作品"
  },
  {
    "name": "周煜晟",
    "borrowTime": "2023-12-13",
    "bookName": "幸存者",
    "author": "秦明著"
  },
  {
    "name": "周煜晟",
    "borrowTime": "2024-05-05",
    "bookName": "黄金瞳.1.1",
    "author": "打眼著"
  },
  {
    "name": "周煜晟",
    "borrowTime": "2024-09-13",
    "bookName": "守夜者",
    "author": "法医秦明著"
  },
  {
    "name": "周煜晟",
    "borrowTime": "2024-09-19",
    "bookName": "守夜者.2,黑暗潜能",
    "author": "法医秦明著"
  },
  {
    "name": "周煜晟",
    "borrowTime": "2024-10-16",
    "bookName": "首席医官.3",
    "author": "谢荣鹏著"
  },
  {
    "name": "周煜晟",
    "borrowTime": "2024-11-07",
    "bookName": "韩警官.Ⅵ,猎凶迷雾",
    "author": "卓牧闲著"
  },
  {
    "name": "周熙尧",
    "borrowTime": "2023-10-30",
    "bookName": "唐太宗",
    "author": "赵扬著"
  },
  {
    "name": "周琪珺",
    "borrowTime": "2023-09-20",
    "bookName": "女法医:温柔的解剖",
    "author": "明菲著"
  },
  {
    "name": "周琪珺",
    "borrowTime": "2023-11-12",
    "bookName": "星坟:望古神话",
    "author": "天使奥斯卡著"
  },
  {
    "name": "周琪珺",
    "borrowTime": "2023-11-15",
    "bookName": "哑舍.壹",
    "author": "玄色著"
  },
  {
    "name": "周禹彤",
    "borrowTime": "2024-05-08",
    "bookName": "法医笔记:死亡与识骨背后",
    "author": "王敏著"
  },
  {
    "name": "周航",
    "borrowTime": "2023-12-08",
    "bookName": "曹操:《卑鄙的圣: 曹操》全新精装版.4",
    "author": "王晓磊著"
  },
  {
    "name": "周航",
    "borrowTime": "2024-05-07",
    "bookName": "曹操:《卑鄙的圣: 曹操》全新精装版.5",
    "author": "王晓磊著"
  },
  {
    "name": "周航",
    "borrowTime": "2024-05-07",
    "bookName": "曹操:《卑鄙的圣: 曹操》全新精装版.4",
    "author": "王晓磊著"
  },
  {
    "name": "唐伯超",
    "borrowTime": "2024-12-18",
    "bookName": "我与地坛",
    "author": "史铁生著"
  },
  {
    "name": "唐伯超",
    "borrowTime": "2024-12-18",
    "bookName": "我与地坛",
    "author": "史铁生著"
  },
  {
    "name": "唐佳伟",
    "borrowTime": "2023-11-25",
    "bookName": "地球大炮",
    "author": "刘慈欣，夏笳等著"
  },
  {
    "name": "唐佳伟",
    "borrowTime": "2024-04-29",
    "bookName": "龙族.Ⅰ,火之晨曦",
    "author": "江南著"
  },
  {
    "name": "唐佳伟",
    "borrowTime": "2024-04-29",
    "bookName": "龙族.Ⅲ,黑月之潮.上",
    "author": "江南著"
  },
  {
    "name": "唐佳伟",
    "borrowTime": "2024-10-27",
    "bookName": "刘慈欣获奖作品集:纪念珍藏版",
    "author": "刘慈欣著"
  },
  {
    "name": "唐佳伟",
    "borrowTime": "2024-10-27",
    "bookName": "中国当代文学经典必读,2010短篇小说卷",
    "author": "吴义勤主编"
  },
  {
    "name": "唐前程",
    "borrowTime": "2023-11-17",
    "bookName": "克苏鲁神话合集",
    "author": "(美) 霍华德·菲利普·洛夫克拉夫特著"
  },
  {
    "name": "唐前程",
    "borrowTime": "2023-11-29",
    "bookName": "绝对零度.1,飞天",
    "author": "樊落著"
  },
  {
    "name": "唐前程",
    "borrowTime": "2023-12-03",
    "bookName": "心理罪.3,教化场",
    "author": "雷米著"
  },
  {
    "name": "唐前程",
    "borrowTime": "2023-12-06",
    "bookName": "摸金玦之鬼门天师",
    "author": "天下霸唱[著]"
  },
  {
    "name": "唐前程",
    "borrowTime": "2023-12-10",
    "bookName": "古剑屠魔录",
    "author": "月关著"
  },
  {
    "name": "唐前程",
    "borrowTime": "2023-12-10",
    "bookName": "龙族.Ⅰ,火之晨曦",
    "author": "江南著"
  },
  {
    "name": "唐前程",
    "borrowTime": "2024-06-05",
    "bookName": "奇异博士.第一季",
    "author": "(美)格雷格·派克著"
  },
  {
    "name": "唐前程",
    "borrowTime": "2024-06-05",
    "bookName": "神奇女侠.2,勇气",
    "author": "(美)布莱恩·阿扎瑞罗著"
  },
  {
    "name": "唐前程",
    "borrowTime": "2024-09-06",
    "bookName": "天齐大陆",
    "author": "月下泷痕著"
  },
  {
    "name": "唐前程",
    "borrowTime": "2024-10-08",
    "bookName": "D坂杀人事件",
    "author": "(日)江户川乱步著"
  },
  {
    "name": "商焱",
    "borrowTime": "2023-11-25",
    "bookName": "时空尽头",
    "author": "王晋康等著"
  },
  {
    "name": "商焱",
    "borrowTime": "2024-05-06",
    "bookName": "E=mc3：边角料科研奇思录",
    "author": "杨枫，王博言主编"
  },
  {
    "name": "国家宝",
    "borrowTime": "2023-10-11",
    "bookName": "天空的城.3.3",
    "author": "超级大坦克科比著"
  },
  {
    "name": "国家宝",
    "borrowTime": "2023-10-12",
    "bookName": "那些有钱的年轻人, 原名: 老子是癞蛤蟆",
    "author": "烽火戏诸侯著"
  },
  {
    "name": "国家宝",
    "borrowTime": "2023-10-12",
    "bookName": "那些有钱的年轻人, 原名: 老子是癞蛤蟆",
    "author": "烽火戏诸侯著"
  },
  {
    "name": "夏庆禹",
    "borrowTime": "2023-10-07",
    "bookName": "罪全书.6",
    "author": "蜘蛛著"
  },
  {
    "name": "夏庆禹",
    "borrowTime": "2023-11-12",
    "bookName": "诡案组.2.Season two.第2季",
    "author": "求无欲著"
  },
  {
    "name": "夏庆禹",
    "borrowTime": "2023-11-17",
    "bookName": "危险的维纳斯",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "夏庆禹",
    "borrowTime": "2023-11-17",
    "bookName": "危险的维纳斯",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "姜云开",
    "borrowTime": "2023-09-25",
    "bookName": "千与千寻",
    "author": "(日)宫崎骏原作·脚本·导演"
  },
  {
    "name": "姜先泽",
    "borrowTime": "2023-11-16",
    "bookName": "黄金手",
    "author": "阿怪作品"
  },
  {
    "name": "姜凯舰",
    "borrowTime": "2023-10-10",
    "bookName": "盗墓笔记:十年",
    "author": "南派三叔著"
  },
  {
    "name": "姜博",
    "borrowTime": "2023-10-16",
    "bookName": "偷窥一百二十天.新版",
    "author": "蔡骏著"
  },
  {
    "name": "姜博",
    "borrowTime": "2023-10-17",
    "bookName": "天道图书馆.2,龙争虎斗",
    "author": "横扫天涯著"
  },
  {
    "name": "姜博",
    "borrowTime": "2023-11-19",
    "bookName": "北纬30°神秘现象全记录",
    "author": "马郁文编著"
  },
  {
    "name": "姜威祥",
    "borrowTime": "2024-05-13",
    "bookName": "古希腊神话故事",
    "author": "凌雅丽主编"
  },
  {
    "name": "姜孟哲",
    "borrowTime": "2023-11-10",
    "bookName": "元尊.6,逆流而上",
    "author": "天蚕土豆著"
  },
  {
    "name": "姜宗良",
    "borrowTime": "2023-11-16",
    "bookName": "简读聊斋志异",
    "author": "一水间编著"
  },
  {
    "name": "姜昊",
    "borrowTime": "2023-09-24",
    "bookName": "历史悬案:科学探索扑朔迷离的千古历史谜案",
    "author": "马兰主编"
  },
  {
    "name": "姜昊",
    "borrowTime": "2025-03-31",
    "bookName": "活出你的样子:柯勒律治写给年轻人的16封信",
    "author": "(英)斯蒂芬·柯勒律治著"
  },
  {
    "name": "姜昊",
    "borrowTime": "2025-03-31",
    "bookName": "你好，朋友圈",
    "author": "王洁著"
  },
  {
    "name": "姜睿洋",
    "borrowTime": "2026-04-20",
    "bookName": "活着.第2版",
    "author": "余华"
  },
  {
    "name": "姜睿洋",
    "borrowTime": "2026-04-20",
    "bookName": "百年孤独.第2版",
    "author": "加西亚·马尔克斯著"
  },
  {
    "name": "姜睿洋",
    "borrowTime": "2026-04-23",
    "bookName": "长安的荔枝",
    "author": "马伯庸著"
  },
  {
    "name": "姜睿洋",
    "borrowTime": "2026-04-23",
    "bookName": "一读就上瘾的中国史",
    "author": "温伯陵著"
  },
  {
    "name": "姜禹丞",
    "borrowTime": "2023-09-19",
    "bookName": "你是人间的四月天",
    "author": "林徽因著"
  },
  {
    "name": "姜禹丞",
    "borrowTime": "2023-09-24",
    "bookName": "心居",
    "author": "滕肖澜著"
  },
  {
    "name": "孔建业",
    "borrowTime": "2023-10-09",
    "bookName": "北纬30°神秘现象全记录",
    "author": "马郁文编著"
  },
  {
    "name": "孔祥智",
    "borrowTime": "2023-10-06",
    "bookName": "黑铁时代",
    "author": "王小波著"
  },
  {
    "name": "孙一",
    "borrowTime": "2023-11-19",
    "bookName": "牧野诡事",
    "author": "天下霸唱著"
  },
  {
    "name": "孙一",
    "borrowTime": "2023-11-19",
    "bookName": "陆家古宅",
    "author": "孙磊著"
  },
  {
    "name": "孙一",
    "borrowTime": "2023-12-04",
    "bookName": "摸金传人.5,湘西蛊术",
    "author": "罗晓著"
  },
  {
    "name": "孙伟熙",
    "borrowTime": "2025-11-18",
    "bookName": "入党培训教材",
    "author": "张荣臣主编"
  },
  {
    "name": "孙伟熙",
    "borrowTime": "2025-11-18",
    "bookName": "读懂党章",
    "author": "李忠杰著"
  },
  {
    "name": "孙伟熙",
    "borrowTime": "2025-11-18",
    "bookName": "入党培训教材",
    "author": "张荣臣主编"
  },
  {
    "name": "孙伟熙",
    "borrowTime": "2025-11-18",
    "bookName": "读懂党章",
    "author": "李忠杰著"
  },
  {
    "name": "孙健哲",
    "borrowTime": "2023-10-31",
    "bookName": "他似晨风起",
    "author": "惜双双著"
  },
  {
    "name": "孙博",
    "borrowTime": "2023-10-10",
    "bookName": "人间游戏,牢笼",
    "author": "钟宇著"
  },
  {
    "name": "孙国瑜",
    "borrowTime": "2023-11-12",
    "bookName": "兄弟.第3版",
    "author": "余华"
  },
  {
    "name": "孙国瑜",
    "borrowTime": "2025-09-22",
    "bookName": "摸金传人.10,消失的师兄",
    "author": "罗晓著"
  },
  {
    "name": "孙国瑜",
    "borrowTime": "2025-09-22",
    "bookName": "摸金传人.9,八臂蛇怪",
    "author": "罗晓著"
  },
  {
    "name": "孙圆泽",
    "borrowTime": "2024-05-06",
    "bookName": "地狱公寓.3",
    "author": "董协著"
  },
  {
    "name": "孙圆泽",
    "borrowTime": "2024-05-12",
    "bookName": "明朝那些事儿.第1部,朱元璋: 从和尚到皇帝.图文精印版",
    "author": "当年明月著"
  },
  {
    "name": "孙圆泽",
    "borrowTime": "2024-05-12",
    "bookName": "明朝那些事儿.增补版",
    "author": "当年明月著"
  },
  {
    "name": "孙圆泽",
    "borrowTime": "2024-05-16",
    "bookName": "明朝那些事儿.增补版",
    "author": "当年明月著"
  },
  {
    "name": "孙圆泽",
    "borrowTime": "2024-05-24",
    "bookName": "明朝那些事儿.增补版",
    "author": "当年明月著"
  },
  {
    "name": "孙圆泽",
    "borrowTime": "2024-05-24",
    "bookName": "消失的证人",
    "author": "吕旭著"
  },
  {
    "name": "孙圣然",
    "borrowTime": "2023-12-01",
    "bookName": "故都的秋:郁达夫散文精选",
    "author": "郁达夫著"
  },
  {
    "name": "孙嫡",
    "borrowTime": "2023-09-22",
    "bookName": "偷偷藏不住.上册",
    "author": "竹已著"
  },
  {
    "name": "孙宇",
    "borrowTime": "2023-09-23",
    "bookName": "犯罪心理档案.第三季",
    "author": "刚雪印作品"
  },
  {
    "name": "孙宇",
    "borrowTime": "2023-09-24",
    "bookName": "罪全书.4",
    "author": "蜘蛛著"
  },
  {
    "name": "孙宇",
    "borrowTime": "2023-10-30",
    "bookName": "罪全书.4",
    "author": "蜘蛛著"
  },
  {
    "name": "孙宏仁",
    "borrowTime": "2023-10-07",
    "bookName": "心理大师",
    "author": "钟宇作品"
  },
  {
    "name": "孙宏仁",
    "borrowTime": "2023-10-18",
    "bookName": "搜神记.1,神农使者",
    "author": "树下野狐著"
  },
  {
    "name": "孙小淳",
    "borrowTime": "2023-09-14",
    "bookName": "满世界找诡:散客月下四海奇谭",
    "author": "散客月下著"
  },
  {
    "name": "孙泽源",
    "borrowTime": "2023-10-17",
    "bookName": "龙族.Ⅰ,火之晨曦",
    "author": "江南著"
  },
  {
    "name": "孙泽源",
    "borrowTime": "2023-11-17",
    "bookName": "龙族.Ⅱ,悼亡者之瞳",
    "author": "江南著"
  },
  {
    "name": "孙泽源",
    "borrowTime": "2023-12-13",
    "bookName": "龙族.Ⅱ,悼亡者之瞳",
    "author": "江南著"
  },
  {
    "name": "孙浩然",
    "borrowTime": "2023-09-20",
    "bookName": "诡案组外传",
    "author": "求无欲著"
  },
  {
    "name": "孙浩然",
    "borrowTime": "2023-09-20",
    "bookName": "幸存者",
    "author": "秦明著"
  },
  {
    "name": "孙海博",
    "borrowTime": "2023-10-15",
    "bookName": "守夜者.3,生死盲点",
    "author": "法医秦明著"
  },
  {
    "name": "孙滢翕",
    "borrowTime": "2025-11-01",
    "bookName": "铁道概论",
    "author": "焦胜军主编"
  },
  {
    "name": "孙滢翕",
    "borrowTime": "2025-11-26",
    "bookName": "铁路运输知识读本",
    "author": "《铁路运输知识读本》编委会编"
  },
  {
    "name": "孙滢翕",
    "borrowTime": "2025-12-03",
    "bookName": "铁路普通货物运输",
    "author": "冯双, 谢淑润主编"
  },
  {
    "name": "孙立宇",
    "borrowTime": "2023-11-07",
    "bookName": "雪中悍刀行.11,逍遥游春秋",
    "author": "烽火戏诸侯著"
  },
  {
    "name": "孙紫琪",
    "borrowTime": "2023-09-26",
    "bookName": "重回犯罪现场.3",
    "author": "风雨如书著"
  },
  {
    "name": "孙紫琪",
    "borrowTime": "2023-10-23",
    "bookName": "重回犯罪现场.3",
    "author": "风雨如书著"
  },
  {
    "name": "孙紫琪",
    "borrowTime": "2025-11-25",
    "bookName": "铁道概论",
    "author": "中国国家铁路集团有限公司运输部主编"
  },
  {
    "name": "孙铭泽",
    "borrowTime": "2023-09-20",
    "bookName": "犯罪心理学",
    "author": "(美) Curt R. Bartol, Anne M. Bartol著"
  },
  {
    "name": "孙雨彤",
    "borrowTime": "2025-11-03",
    "bookName": "带壳的牡蛎是大人的心脏",
    "author": "拟泥nini著绘"
  },
  {
    "name": "孙靖童",
    "borrowTime": "2023-09-20",
    "bookName": "难哄",
    "author": "竹已著"
  },
  {
    "name": "孙靖童",
    "borrowTime": "2023-10-31",
    "bookName": "解剖室诡秘档案",
    "author": "月翼著"
  },
  {
    "name": "孙飞",
    "borrowTime": "2024-05-13",
    "bookName": "十宗罪.5",
    "author": "蜘蛛著"
  },
  {
    "name": "孙飞",
    "borrowTime": "2024-05-15",
    "bookName": "尸案调查科.第二季.2,一念深渊",
    "author": "九滴水著"
  },
  {
    "name": "孙飞",
    "borrowTime": "2024-05-29",
    "bookName": "蓝裙子杀人事件",
    "author": "艾西著"
  },
  {
    "name": "孙飞",
    "borrowTime": "2024-05-29",
    "bookName": "刑警手记,虚拟谋杀",
    "author": "野兵著"
  },
  {
    "name": "孙飞",
    "borrowTime": "2024-05-29",
    "bookName": "佣兵天下全集.4.4",
    "author": "说不得大师著"
  },
  {
    "name": "孙飞",
    "borrowTime": "2024-06-24",
    "bookName": "诡案组外传",
    "author": "求无欲著"
  },
  {
    "name": "孙飞",
    "borrowTime": "2024-06-24",
    "bookName": "诡案罪.4",
    "author": "岳勇著"
  },
  {
    "name": "孟令轩",
    "borrowTime": "2023-09-19",
    "bookName": "重回犯罪现场.3",
    "author": "风雨如书著"
  },
  {
    "name": "孟令轩",
    "borrowTime": "2023-11-02",
    "bookName": "龙族.Ⅰ,火之晨曦",
    "author": "江南著"
  },
  {
    "name": "孟令轩",
    "borrowTime": "2023-12-07",
    "bookName": "女法医手记之破译密码",
    "author": "刘真著"
  },
  {
    "name": "孟令轩",
    "borrowTime": "2023-12-14",
    "bookName": "武破苍穹.2",
    "author": "雨辰宇著"
  },
  {
    "name": "孟令轩",
    "borrowTime": "2023-12-14",
    "bookName": "武破苍穹.1",
    "author": "雨辰宇著"
  },
  {
    "name": "孟令轩",
    "borrowTime": "2026-04-10",
    "bookName": "云上摆渡人",
    "author": "未名苏苏"
  },
  {
    "name": "孟令轩",
    "borrowTime": "2026-05-21",
    "bookName": "寻情记.1,木鱼",
    "author": "鬼山僧作品"
  },
  {
    "name": "孟令轩",
    "borrowTime": "2026-05-21",
    "bookName": "寻情记.3,袈裟",
    "author": "鬼山僧作品"
  },
  {
    "name": "孟志伟",
    "borrowTime": "2023-09-19",
    "bookName": "法医专家",
    "author": "王文杰著"
  },
  {
    "name": "孟志伟",
    "borrowTime": "2024-09-26",
    "bookName": "第七天.3版",
    "author": "余华著"
  },
  {
    "name": "孟思辰",
    "borrowTime": "2023-11-07",
    "bookName": "丧钟为谁而鸣",
    "author": "(美) 海明威著"
  },
  {
    "name": "孟昭兵",
    "borrowTime": "2023-12-17",
    "bookName": "斗罗大陆.第二部,绝世唐门.24",
    "author": "唐家三少著"
  },
  {
    "name": "孟昭兵",
    "borrowTime": "2024-05-13",
    "bookName": "魔兽战神,鲲鹏战场",
    "author": "龙人著"
  },
  {
    "name": "孟昭兵",
    "borrowTime": "2024-05-29",
    "bookName": "武破苍穹.5",
    "author": "雨辰宇著"
  },
  {
    "name": "孟昭兵",
    "borrowTime": "2024-05-29",
    "bookName": "武破苍穹.4",
    "author": "雨辰宇著"
  },
  {
    "name": "孟昭兵",
    "borrowTime": "2024-06-24",
    "bookName": "封魔师.2",
    "author": "陨落星辰著"
  },
  {
    "name": "孟昭兵",
    "borrowTime": "2024-06-24",
    "bookName": "封魔师.1",
    "author": "陨落星辰著"
  },
  {
    "name": "孟熙然",
    "borrowTime": "2024-06-04",
    "bookName": "沙海.1,[荒沙诡影]",
    "author": "南派三叔著"
  },
  {
    "name": "孟熙然",
    "borrowTime": "2024-09-19",
    "bookName": "漫画讲透大学中庸",
    "author": "小读客阅读研究社著"
  },
  {
    "name": "孟熙然",
    "borrowTime": "2024-09-19",
    "bookName": "漫画讲透论语,仁义篇",
    "author": "小读客阅读研究社著"
  },
  {
    "name": "孟翔毅",
    "borrowTime": "2023-09-27",
    "bookName": "怪诞实录.第二季",
    "author": "凤仪著"
  },
  {
    "name": "季琳棋",
    "borrowTime": "2023-09-10",
    "bookName": "你是我学不会的别离",
    "author": "古月公子著"
  },
  {
    "name": "季琳棋",
    "borrowTime": "2023-10-08",
    "bookName": "南风有归期",
    "author": "子木桑桑著"
  },
  {
    "name": "季琳棋",
    "borrowTime": "2023-10-19",
    "bookName": "快把我哥带走.2,分秒必争.2版",
    "author": "幽·灵绘著"
  },
  {
    "name": "季琳棋",
    "borrowTime": "2023-10-19",
    "bookName": "三国演义",
    "author": "蔡志忠编绘"
  },
  {
    "name": "安桐庆",
    "borrowTime": "2023-09-05",
    "bookName": "御剑天下",
    "author": "辰阳著"
  },
  {
    "name": "安洋辰",
    "borrowTime": "2023-10-11",
    "bookName": "陷阱",
    "author": "蒋玉龙著"
  },
  {
    "name": "安洋辰",
    "borrowTime": "2023-10-11",
    "bookName": "喂食者协会",
    "author": "那多著"
  },
  {
    "name": "安洋辰",
    "borrowTime": "2023-11-08",
    "bookName": "重回犯罪现场.3",
    "author": "风雨如书著"
  },
  {
    "name": "宋伟赫",
    "borrowTime": "2023-09-19",
    "bookName": "盗墓笔记:十年",
    "author": "南派三叔著"
  },
  {
    "name": "宋伟赫",
    "borrowTime": "2023-09-20",
    "bookName": "山海经,赤影传说.上",
    "author": "原创故事豆丁, 易小草, 耀之"
  },
  {
    "name": "宋佩霖",
    "borrowTime": "2023-10-12",
    "bookName": "啊2.0.增补版",
    "author": "大冰作品"
  },
  {
    "name": "宋佩霖",
    "borrowTime": "2023-10-12",
    "bookName": "灵魂有毒",
    "author": "王珂著"
  },
  {
    "name": "宋奉时",
    "borrowTime": "2023-09-18",
    "bookName": "你看完不敢睡, 看了还想看的悬疑小说.Ⅰ",
    "author": "白虹主编"
  },
  {
    "name": "宋奉时",
    "borrowTime": "2023-09-19",
    "bookName": "守夜者.3,生死盲点",
    "author": "法医秦明著"
  },
  {
    "name": "宋昊泽",
    "borrowTime": "2023-09-19",
    "bookName": "特立独行刘强东",
    "author": "刘子鸣著"
  },
  {
    "name": "宋昊泽",
    "borrowTime": "2023-11-12",
    "bookName": "雪中悍刀行.14,杯中起涟漪",
    "author": "烽火戏诸侯著"
  },
  {
    "name": "宋昊洋",
    "borrowTime": "2023-11-20",
    "bookName": "平凡的世界",
    "author": "路遥著"
  },
  {
    "name": "宋昊轩",
    "borrowTime": "2023-10-08",
    "bookName": "仙剑奇侠传.叁",
    "author": "管平潮作品"
  },
  {
    "name": "宋海卓",
    "borrowTime": "2023-11-13",
    "bookName": "法医档案.03,迟来真相.03,Truth comes late",
    "author": "戴西著"
  },
  {
    "name": "宋财进",
    "borrowTime": "2023-09-04",
    "bookName": "黑死馆杀人事件",
    "author": "(日)小栗虫太郎著"
  },
  {
    "name": "宋财进",
    "borrowTime": "2024-09-02",
    "bookName": "脑髓地狱",
    "author": "(日)梦野久作著"
  },
  {
    "name": "宋财进",
    "borrowTime": "2024-09-02",
    "bookName": "K和N的悲剧",
    "author": "(日)高野和明著"
  },
  {
    "name": "宋财进",
    "borrowTime": "2024-09-02",
    "bookName": "暗黑医院:消失的病患",
    "author": "(日)知念实希人著"
  },
  {
    "name": "宋财进",
    "borrowTime": "2024-09-02",
    "bookName": "暗黑医院:消失的病患",
    "author": "(日)知念实希人著"
  },
  {
    "name": "宋财进",
    "borrowTime": "2024-09-18",
    "bookName": "双月城的惨剧",
    "author": "(日)加贺美雅之著"
  },
  {
    "name": "宋财进",
    "borrowTime": "2024-10-16",
    "bookName": "今夏",
    "author": "爱看天著"
  },
  {
    "name": "宋财进",
    "borrowTime": "2024-10-16",
    "bookName": "草莓醋",
    "author": "非期而然著"
  },
  {
    "name": "宋财进",
    "borrowTime": "2024-10-16",
    "bookName": "逐风",
    "author": "漆环念著"
  },
  {
    "name": "宫振宇",
    "borrowTime": "2023-11-13",
    "bookName": "雪中悍刀行.2,白马出凉州",
    "author": "烽火戏诸侯著"
  },
  {
    "name": "宫森",
    "borrowTime": "2023-11-12",
    "bookName": "金棺陵兽",
    "author": "天下霸唱著"
  },
  {
    "name": "宫森",
    "borrowTime": "2023-11-16",
    "bookName": "牧野诡事",
    "author": "天下霸唱著"
  },
  {
    "name": "宫苏航",
    "borrowTime": "2023-10-16",
    "bookName": "连环罪:心理有诡",
    "author": "墨绿青苔著"
  },
  {
    "name": "宿欣阳",
    "borrowTime": "2023-10-08",
    "bookName": "嵬城.1,血路",
    "author": "冷露著"
  },
  {
    "name": "寇岩",
    "borrowTime": "2023-09-26",
    "bookName": "永夜君王.卷贰,阴谋·阳谋",
    "author": "烟雨江南著"
  },
  {
    "name": "寇岩",
    "borrowTime": "2023-10-07",
    "bookName": "古剑屠魔录",
    "author": "月关著"
  },
  {
    "name": "寇岩",
    "borrowTime": "2023-10-09",
    "bookName": "羽冥殿",
    "author": "陈镜安著"
  },
  {
    "name": "寇岩",
    "borrowTime": "2024-05-13",
    "bookName": "天之炽.1.1,红龙的归来",
    "author": "江南作品"
  },
  {
    "name": "寇岩",
    "borrowTime": "2024-05-15",
    "bookName": "武破苍穹.3",
    "author": "雨辰宇著"
  },
  {
    "name": "寇岩",
    "borrowTime": "2024-05-15",
    "bookName": "武破苍穹.2",
    "author": "雨辰宇著"
  },
  {
    "name": "寇岩",
    "borrowTime": "2024-05-15",
    "bookName": "武破苍穹.1",
    "author": "雨辰宇著"
  },
  {
    "name": "寇岩",
    "borrowTime": "2024-05-15",
    "bookName": "武破苍穹.4",
    "author": "雨辰宇著"
  },
  {
    "name": "寇岩",
    "borrowTime": "2024-05-15",
    "bookName": "武破苍穹.5",
    "author": "雨辰宇著"
  },
  {
    "name": "寇岩",
    "borrowTime": "2024-05-29",
    "bookName": "佣兵天下全集.2.2",
    "author": "说不得大师著"
  },
  {
    "name": "寇岩",
    "borrowTime": "2024-05-29",
    "bookName": "佣兵天下全集.3.3",
    "author": "说不得大师著"
  },
  {
    "name": "寇岩",
    "borrowTime": "2024-05-29",
    "bookName": "佣兵天下全集.6.6",
    "author": "说不得大师著"
  },
  {
    "name": "寇岩",
    "borrowTime": "2024-05-29",
    "bookName": "佣兵天下全集.5.5",
    "author": "说不得大师著"
  },
  {
    "name": "富勃淋",
    "borrowTime": "2024-09-05",
    "bookName": "官场现形记",
    "author": "(清)李伯元著"
  },
  {
    "name": "富勃淋",
    "borrowTime": "2024-09-12",
    "bookName": "怪物同学会",
    "author": "全球华语科幻星云奖组委会编"
  },
  {
    "name": "富勃淋",
    "borrowTime": "2024-09-12",
    "bookName": "岸边露伴在卢浮",
    "author": "(日)荒木飞吕彦著"
  },
  {
    "name": "富勃淋",
    "borrowTime": "2024-09-24",
    "bookName": "大奉打更人",
    "author": "卖报小郎君著"
  },
  {
    "name": "尚天赐",
    "borrowTime": "2023-09-18",
    "bookName": "神级召唤师.1",
    "author": "蝶之灵著"
  },
  {
    "name": "尚天赐",
    "borrowTime": "2023-10-09",
    "bookName": "绝世仙罗",
    "author": "石子狂徒著"
  },
  {
    "name": "尚星龙",
    "borrowTime": "2025-03-05",
    "bookName": "活着",
    "author": "余华著"
  },
  {
    "name": "尚星龙",
    "borrowTime": "2025-03-05",
    "bookName": "基础单词3500,学1个会3个",
    "author": "王全民编著"
  },
  {
    "name": "尚星龙",
    "borrowTime": "2025-03-05",
    "bookName": "四级词汇词根+联想记忆法.第2版",
    "author": "俞敏洪编著"
  },
  {
    "name": "尚钰书",
    "borrowTime": "2023-11-08",
    "bookName": "寻情记.5,古卷",
    "author": "鬼山僧作品"
  },
  {
    "name": "尚靖萱",
    "borrowTime": "2023-10-08",
    "bookName": "了不起的盖茨比",
    "author": "(美) 菲茨杰拉德著"
  },
  {
    "name": "尚靖萱",
    "borrowTime": "2023-10-08",
    "bookName": "杀死一只知更鸟",
    "author": "(美) 哈珀·李著"
  },
  {
    "name": "尚靖萱",
    "borrowTime": "2023-11-04",
    "bookName": "一个人的记忆",
    "author": "史铁生著"
  },
  {
    "name": "尚靖萱",
    "borrowTime": "2024-05-25",
    "bookName": "优势谈判:斯坦福商学院谈判金规则",
    "author": "(美)玛格丽特·A. 尼尔(Margaret A. Neale)，(美)托马斯·Z. 利斯(Thomas Z. Lys)著"
  },
  {
    "name": "尚靖萱",
    "borrowTime": "2024-05-25",
    "bookName": "中华人民共和国民法典.大字本",
    "author": "中国法制出版社"
  },
  {
    "name": "尚靖萱",
    "borrowTime": "2024-09-22",
    "bookName": "你当像鸟飞往你的山",
    "author": "(美) 塔拉·韦斯特弗著"
  },
  {
    "name": "尚靖萱",
    "borrowTime": "2024-10-11",
    "bookName": "明朝那些事儿.增补版",
    "author": "当年明月著"
  },
  {
    "name": "尚靖萱",
    "borrowTime": "2024-11-27",
    "bookName": "张翔讲民法",
    "author": "张翔编著"
  },
  {
    "name": "尚靖萱",
    "borrowTime": "2024-11-27",
    "bookName": "张翔讲民法",
    "author": "张翔编著"
  },
  {
    "name": "尚靖萱",
    "borrowTime": "2025-05-21",
    "bookName": "蛤蟆先生去看心理医生",
    "author": "(英)罗伯特·戴博德(Robert de Board)著"
  },
  {
    "name": "尚靖萱",
    "borrowTime": "2025-05-26",
    "bookName": "飘",
    "author": "(美) 玛格丽特·米切尔著"
  },
  {
    "name": "尚靖萱",
    "borrowTime": "2025-10-21",
    "bookName": "人性心理学,心智开悟的98个基本法则",
    "author": "王溢嘉著"
  },
  {
    "name": "尹相智",
    "borrowTime": "2023-10-12",
    "bookName": "克苏鲁神话合集",
    "author": "(美) 霍华德·菲利普·洛夫克拉夫特著"
  },
  {
    "name": "岳建华",
    "borrowTime": "2023-09-20",
    "bookName": "我是猫",
    "author": "(日) 夏目漱石著"
  },
  {
    "name": "岳建华",
    "borrowTime": "2023-10-10",
    "bookName": "天堂旅行团",
    "author": "张嘉佳著"
  },
  {
    "name": "岳昊然",
    "borrowTime": "2024-09-08",
    "bookName": "龙族.Ⅲ,黑月之潮.上",
    "author": "江南著"
  },
  {
    "name": "岳昊然",
    "borrowTime": "2024-09-08",
    "bookName": "龙族.Ⅰ,火之晨曦",
    "author": "江南著"
  },
  {
    "name": "岳昊然",
    "borrowTime": "2024-09-08",
    "bookName": "龙族.Ⅳ,奥丁之渊",
    "author": "江南著"
  },
  {
    "name": "崔升赫",
    "borrowTime": "2024-12-01",
    "bookName": "中国画的心性",
    "author": "江宏，邵琦著"
  },
  {
    "name": "崔升赫",
    "borrowTime": "2024-12-01",
    "bookName": "拜占庭帝国史:从拜占庭建城到君士坦丁堡陷落:公元前667年－公元1453年",
    "author": "(英) 查尔斯·欧曼著"
  },
  {
    "name": "崔升赫",
    "borrowTime": "2024-12-01",
    "bookName": "网络安全技术:微课版",
    "author": "赵正文，林雪云，王娟主编"
  },
  {
    "name": "崔升赫",
    "borrowTime": "2024-12-01",
    "bookName": "建筑电气专业技术措施.第2版",
    "author": "北京市建筑设计研究院有限公司编"
  },
  {
    "name": "崔升赫",
    "borrowTime": "2024-12-01",
    "bookName": "室内配线与照明工程",
    "author": "曹孟州编著"
  },
  {
    "name": "崔升赫",
    "borrowTime": "2024-12-01",
    "bookName": "系统安全与防护指南",
    "author": "(美)爱德华·格里福(Edward Griffor)主编"
  },
  {
    "name": "崔博文",
    "borrowTime": "2023-09-25",
    "bookName": "心理大师",
    "author": "钟宇作品"
  },
  {
    "name": "崔博文",
    "borrowTime": "2023-10-10",
    "bookName": "胰脏物语",
    "author": "(日) 住野夜著"
  },
  {
    "name": "崔博文",
    "borrowTime": "2023-10-16",
    "bookName": "福尔摩斯探案集全集:被称为侦探小说的“圣经”",
    "author": "(英) 柯南·道尔著"
  },
  {
    "name": "崔峻豪",
    "borrowTime": "2023-09-27",
    "bookName": "天谴者",
    "author": "法医秦明著"
  },
  {
    "name": "崔峻豪",
    "borrowTime": "2023-10-20",
    "bookName": "天谴者",
    "author": "法医秦明著"
  },
  {
    "name": "崔晓晗",
    "borrowTime": "2024-11-20",
    "bookName": "柿子树下",
    "author": "党华著"
  },
  {
    "name": "崔晓晗",
    "borrowTime": "2025-03-08",
    "bookName": "长安的荔枝",
    "author": "马伯庸著"
  },
  {
    "name": "崔晓晗",
    "borrowTime": "2025-03-11",
    "bookName": "蛤蟆先生去看心理医生",
    "author": "(英)罗伯特·戴博德(Robert de Board)著"
  },
  {
    "name": "崔晓晗",
    "borrowTime": "2025-03-13",
    "bookName": "王统照精品选",
    "author": "王统照著"
  },
  {
    "name": "崔晓晗",
    "borrowTime": "2026-05-07",
    "bookName": "巴尔干的铜钥匙",
    "author": "毕淑敏作品"
  },
  {
    "name": "崔晓晗",
    "borrowTime": "2026-05-07",
    "bookName": "窗边的小豆豆.第2版",
    "author": "(日) 黑柳彻子著"
  },
  {
    "name": "崔欣",
    "borrowTime": "2023-09-19",
    "bookName": "我不是好老师 他们也不是好学生",
    "author": "王刚著"
  },
  {
    "name": "崔泽鹏",
    "borrowTime": "2023-11-09",
    "bookName": "有趣得让人睡不着的三国史.3",
    "author": "醉罢君山著"
  },
  {
    "name": "崔泽鹏",
    "borrowTime": "2023-11-09",
    "bookName": "有趣得让人睡不着的三国史.2",
    "author": "醉罢君山著"
  },
  {
    "name": "崔泽鹏",
    "borrowTime": "2023-12-03",
    "bookName": "西晋风云.卷一",
    "author": "孙峰著"
  },
  {
    "name": "崔泽鹏",
    "borrowTime": "2023-12-03",
    "bookName": "西晋风云.卷二",
    "author": "孙峰著"
  },
  {
    "name": "常治禹",
    "borrowTime": "2023-12-13",
    "bookName": "狼行成双.上",
    "author": "巫哲著"
  },
  {
    "name": "常治禹",
    "borrowTime": "2024-05-25",
    "bookName": "吞海",
    "author": "淮上著"
  },
  {
    "name": "常诚",
    "borrowTime": "2023-12-14",
    "bookName": "九州缥缈录.Ⅰ,蛮荒.修订版",
    "author": "江南著"
  },
  {
    "name": "常诚",
    "borrowTime": "2025-09-09",
    "bookName": "一人之下.2",
    "author": "米二编绘"
  },
  {
    "name": "常诚",
    "borrowTime": "2025-09-15",
    "bookName": "剑来",
    "author": "烽火戏诸侯著"
  },
  {
    "name": "常诚",
    "borrowTime": "2025-10-23",
    "bookName": "她他",
    "author": "映漾著"
  },
  {
    "name": "常诚",
    "borrowTime": "2025-10-23",
    "bookName": "危险的维纳斯",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "常诚",
    "borrowTime": "2025-10-23",
    "bookName": "恋爱的贡多拉",
    "author": "(日) 东野圭吾"
  },
  {
    "name": "常诚",
    "borrowTime": "2025-11-20",
    "bookName": "夏目友人帐",
    "author": "漫画原作绿川幸"
  },
  {
    "name": "庄宇",
    "borrowTime": "2023-12-17",
    "bookName": "怒江之战",
    "author": "南派三叔, 乾坤著"
  },
  {
    "name": "庞帅",
    "borrowTime": "2024-05-19",
    "bookName": "边城.修订版",
    "author": "沈从文著"
  },
  {
    "name": "庞帅",
    "borrowTime": "2024-05-25",
    "bookName": "雪中悍刀行.2,白马出凉州",
    "author": "烽火戏诸侯著"
  },
  {
    "name": "庞帅",
    "borrowTime": "2024-05-25",
    "bookName": "龙族.Ⅰ,火之晨曦",
    "author": "江南著"
  },
  {
    "name": "庞帅",
    "borrowTime": "2024-05-25",
    "bookName": "龙族.Ⅱ,悼亡者之瞳",
    "author": "江南著"
  },
  {
    "name": "康坤",
    "borrowTime": "2024-09-11",
    "bookName": "人世间",
    "author": "梁晓声著"
  },
  {
    "name": "张一茗",
    "borrowTime": "2023-09-18",
    "bookName": "你看完不敢睡, 看了还想看的悬疑小说.Ⅰ",
    "author": "白虹主编"
  },
  {
    "name": "张一茗",
    "borrowTime": "2023-11-09",
    "bookName": "斗罗大陆.第三部,龙王传说.8",
    "author": "唐家三少著"
  },
  {
    "name": "张丁于",
    "borrowTime": "2023-11-19",
    "bookName": "紫川:典藏版.5,一统天下.下",
    "author": "老猪著"
  },
  {
    "name": "张丁于",
    "borrowTime": "2023-11-21",
    "bookName": "紫川.3,铁腕统领.下",
    "author": "老猪著"
  },
  {
    "name": "张丁于",
    "borrowTime": "2023-12-10",
    "bookName": "史记",
    "author": "(西汉) 司马迁著"
  },
  {
    "name": "张丁于",
    "borrowTime": "2024-05-26",
    "bookName": "大奉打更人",
    "author": "卖报小郎君著"
  },
  {
    "name": "张仕元",
    "borrowTime": "2023-10-10",
    "bookName": "铁道概论",
    "author": "王海星主编"
  },
  {
    "name": "张仕元",
    "borrowTime": "2023-10-24",
    "bookName": "悬案组",
    "author": "独孤求剩著"
  },
  {
    "name": "张任",
    "borrowTime": "2023-10-12",
    "bookName": "星际移民",
    "author": "刘慈欣等著"
  },
  {
    "name": "张任",
    "borrowTime": "2023-10-20",
    "bookName": "尸案调查科.2,重案捕手",
    "author": "九滴水著"
  },
  {
    "name": "张传林",
    "borrowTime": "2025-04-17",
    "bookName": "LKJ操作使用手册",
    "author": "《LKJ操作使用手册》编委会编"
  },
  {
    "name": "张传林",
    "borrowTime": "2025-04-17",
    "bookName": "LKJ操作使用手册",
    "author": "《LKJ操作使用手册》编委会编"
  },
  {
    "name": "张传林",
    "borrowTime": "2025-04-17",
    "bookName": "LKJ操作使用手册",
    "author": "《LKJ操作使用手册》编委会编"
  },
  {
    "name": "张传林",
    "borrowTime": "2025-04-17",
    "bookName": "LKJ操作使用手册",
    "author": "《LKJ操作使用手册》编委会编"
  },
  {
    "name": "张传林",
    "borrowTime": "2025-12-04",
    "bookName": "诡案组.2.Season two.第2季",
    "author": "求无欲著"
  },
  {
    "name": "张佳东",
    "borrowTime": "2023-10-06",
    "bookName": "仙剑奇侠传.叁",
    "author": "管平潮作品"
  },
  {
    "name": "张佳东",
    "borrowTime": "2023-10-07",
    "bookName": "雪中悍刀行.14,杯中起涟漪",
    "author": "烽火戏诸侯著"
  },
  {
    "name": "张佳鑫",
    "borrowTime": "2023-10-09",
    "bookName": "人间失格",
    "author": "(日) 太宰治著"
  },
  {
    "name": "张凯",
    "borrowTime": "2023-10-08",
    "bookName": "鬼谷子全解.彩图全解版",
    "author": "思履主编"
  },
  {
    "name": "张博洋",
    "borrowTime": "2023-10-10",
    "bookName": "择天记.第一卷,恰同学少年",
    "author": "猫腻著"
  },
  {
    "name": "张嗣嵩",
    "borrowTime": "2023-10-08",
    "bookName": "他似晨风起",
    "author": "惜双双著"
  },
  {
    "name": "张嗣嵩",
    "borrowTime": "2023-10-08",
    "bookName": "他似晨风起",
    "author": "惜双双著"
  },
  {
    "name": "张嗣嵩",
    "borrowTime": "2023-12-05",
    "bookName": "搜神记.2,龙神太子",
    "author": "树下野狐著"
  },
  {
    "name": "张嘉斌",
    "borrowTime": "2023-09-18",
    "bookName": "你当像鸟飞往你的山",
    "author": "(美) 塔拉·韦斯特弗著"
  },
  {
    "name": "张嘉斌",
    "borrowTime": "2023-11-18",
    "bookName": "我们仨",
    "author": "杨绛著"
  },
  {
    "name": "张嘉航",
    "borrowTime": "2023-10-23",
    "bookName": "世界经典悬疑故事.超值彩图版",
    "author": "白虹主编"
  },
  {
    "name": "张嘉航",
    "borrowTime": "2023-12-05",
    "bookName": "雪中悍刀行.2,白马出凉州",
    "author": "烽火戏诸侯著"
  },
  {
    "name": "张天佑",
    "borrowTime": "2023-10-10",
    "bookName": "中国奇异档案记录.第四季",
    "author": "宋歌编著"
  },
  {
    "name": "张天佑",
    "borrowTime": "2023-11-12",
    "bookName": "鬼吹灯",
    "author": "天下霸唱著"
  },
  {
    "name": "张子恒",
    "borrowTime": "2023-09-19",
    "bookName": "萌夫下山",
    "author": "岑小沐著"
  },
  {
    "name": "张子涵",
    "borrowTime": "2023-10-10",
    "bookName": "我不是好老师 他们也不是好学生",
    "author": "王刚著"
  },
  {
    "name": "张宁",
    "borrowTime": "2023-11-27",
    "bookName": "玲珑双剑",
    "author": "倪匡著"
  },
  {
    "name": "张宁",
    "borrowTime": "2025-10-31",
    "bookName": "积案调查组",
    "author": "狐狸猫著"
  },
  {
    "name": "张宇",
    "borrowTime": "2026-03-10",
    "bookName": "安娜·卡列尼娜.上.第2版",
    "author": "(俄罗斯) 列夫·托尔斯泰著"
  },
  {
    "name": "张宇",
    "borrowTime": "2026-03-10",
    "bookName": "我是猫",
    "author": "(日) 夏目漱石著"
  },
  {
    "name": "张宏博",
    "borrowTime": "2023-11-30",
    "bookName": "盗墓笔记.五",
    "author": "南派三叔著"
  },
  {
    "name": "张宜杰",
    "borrowTime": "2023-09-19",
    "bookName": "雪中悍刀行.7,白发舞太安",
    "author": "烽火戏诸侯著"
  },
  {
    "name": "张宜杰",
    "borrowTime": "2023-09-26",
    "bookName": "兽血大陆.1",
    "author": "灵隐狐著"
  },
  {
    "name": "张宜杰",
    "borrowTime": "2023-09-27",
    "bookName": "兽血大陆.2",
    "author": "灵隐狐著"
  },
  {
    "name": "张宜杰",
    "borrowTime": "2023-09-27",
    "bookName": "兽血大陆.3",
    "author": "灵隐狐著"
  },
  {
    "name": "张宜杰",
    "borrowTime": "2023-10-21",
    "bookName": "莽荒纪.1",
    "author": "原著我吃西红柿"
  },
  {
    "name": "张宜杰",
    "borrowTime": "2023-10-21",
    "bookName": "绝色大陆.上",
    "author": "林家成作品"
  },
  {
    "name": "张宜杰",
    "borrowTime": "2023-11-01",
    "bookName": "九州缥缈录.Ⅰ,蛮荒.修订版",
    "author": "江南著"
  },
  {
    "name": "张宜杰",
    "borrowTime": "2023-11-01",
    "bookName": "天之炽.1.1,红龙的归来",
    "author": "江南作品"
  },
  {
    "name": "张富凯",
    "borrowTime": "2024-09-27",
    "bookName": "散落星河的记忆.Ⅱ,窃梦",
    "author": "桐华[著]"
  },
  {
    "name": "张巍瀚",
    "borrowTime": "2023-11-14",
    "bookName": "必须犯规的游戏:大结局",
    "author": "宁航一著"
  },
  {
    "name": "张彦希",
    "borrowTime": "2023-09-19",
    "bookName": "宇宙的落幕",
    "author": "王晋康, 欧阳广聪等著"
  },
  {
    "name": "张德良",
    "borrowTime": "2023-10-31",
    "bookName": "明朝那些事儿.第叁部,太监弄乱的王朝",
    "author": "当年明月著"
  },
  {
    "name": "张志江",
    "borrowTime": "2023-10-19",
    "bookName": "十日谈.第2版",
    "author": "(意) 薄伽丘著"
  },
  {
    "name": "张志超",
    "borrowTime": "2023-09-20",
    "bookName": "犯罪心理档案.第二季",
    "author": "刚雪印作品"
  },
  {
    "name": "张志超",
    "borrowTime": "2023-10-12",
    "bookName": "读心诡探",
    "author": "风雨如书著"
  },
  {
    "name": "张成彬",
    "borrowTime": "2023-10-07",
    "bookName": "古剑屠魔录",
    "author": "月关著"
  },
  {
    "name": "张成彬",
    "borrowTime": "2023-10-23",
    "bookName": "爱在漫步云端的日子",
    "author": "米娜著"
  },
  {
    "name": "张敏",
    "borrowTime": "2023-09-12",
    "bookName": "西游疯魔录,心魔祭",
    "author": "沐少尘著"
  },
  {
    "name": "张敏",
    "borrowTime": "2023-10-07",
    "bookName": "气冲星河.1,少年无双",
    "author": "犁天著"
  },
  {
    "name": "张敏",
    "borrowTime": "2023-10-16",
    "bookName": "御剑天下",
    "author": "辰阳著"
  },
  {
    "name": "张敏",
    "borrowTime": "2023-12-04",
    "bookName": "这个店有古怪",
    "author": "明月听风著"
  },
  {
    "name": "张敏",
    "borrowTime": "2023-12-04",
    "bookName": "留美驱魔人.1",
    "author": "宸彬[著]"
  },
  {
    "name": "张敏",
    "borrowTime": "2024-04-28",
    "bookName": "玲珑双剑",
    "author": "倪匡著"
  },
  {
    "name": "张文军",
    "borrowTime": "2023-11-15",
    "bookName": "黄金瞳.1.1",
    "author": "打眼著"
  },
  {
    "name": "张文军",
    "borrowTime": "2025-09-19",
    "bookName": "夏至玫瑰",
    "author": "猪蝶著"
  },
  {
    "name": "张文军",
    "borrowTime": "2025-09-27",
    "bookName": "你的心跳",
    "author": "Zoody著"
  },
  {
    "name": "张斌扬",
    "borrowTime": "2023-11-21",
    "bookName": "民调局异闻录.2,麒麟地宫",
    "author": "耳东水寿著"
  },
  {
    "name": "张昊",
    "borrowTime": "2023-09-26",
    "bookName": "盗墓笔记.五",
    "author": "南派三叔著"
  },
  {
    "name": "张昊霖",
    "borrowTime": "2023-10-16",
    "bookName": "黑案私探社",
    "author": "中雨作品"
  },
  {
    "name": "张昊霖",
    "borrowTime": "2023-11-01",
    "bookName": "斗罗大陆.第四部,终极斗罗.16",
    "author": "唐家三少著"
  },
  {
    "name": "张昊霖",
    "borrowTime": "2023-11-15",
    "bookName": "草莓印",
    "author": "不止是颗菜著"
  },
  {
    "name": "张昊霖",
    "borrowTime": "2024-06-18",
    "bookName": "我是寻找夏目的猫",
    "author": "(日)白野猫咪著"
  },
  {
    "name": "张明赫",
    "borrowTime": "2023-09-20",
    "bookName": "九州缥缈录.Ⅰ,蛮荒.修订版",
    "author": "江南著"
  },
  {
    "name": "张明赫",
    "borrowTime": "2024-09-28",
    "bookName": "摸金校尉之九幽将军",
    "author": "天下霸唱著"
  },
  {
    "name": "张昕旸",
    "borrowTime": "2024-09-08",
    "bookName": "直美与加奈子",
    "author": "(日)奥田英朗著"
  },
  {
    "name": "张昕旸",
    "borrowTime": "2024-09-08",
    "bookName": "罪全书.5",
    "author": "蜘蛛著"
  },
  {
    "name": "张晋",
    "borrowTime": "2025-12-06",
    "bookName": "铁道概论",
    "author": "中国国家铁路集团有限公司运输部主编"
  },
  {
    "name": "张晓宇",
    "borrowTime": "2023-11-07",
    "bookName": "暗网.Ⅰ,揭秘数字货币骗局",
    "author": "探索者, 黄天威著"
  },
  {
    "name": "张智",
    "borrowTime": "2023-09-18",
    "bookName": "假面饭店",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "张桐升",
    "borrowTime": "2025-05-23",
    "bookName": "党员干部第一课:学习新党章",
    "author": "《党员干部第一课》编写组编"
  },
  {
    "name": "张正",
    "borrowTime": "2025-12-03",
    "bookName": "铁道概论",
    "author": "中国国家铁路集团有限公司运输部主编"
  },
  {
    "name": "张永星",
    "borrowTime": "2023-11-03",
    "bookName": "重案追击:罪恶的心理画像",
    "author": "琉天玺著"
  },
  {
    "name": "张永星",
    "borrowTime": "2023-11-08",
    "bookName": "89号档案馆",
    "author": "孙铭苑著"
  },
  {
    "name": "张洪阳",
    "borrowTime": "2025-09-22",
    "bookName": "还原犯罪现场.3,血雾森林",
    "author": "风雨如书著"
  },
  {
    "name": "张洪阳",
    "borrowTime": "2025-09-22",
    "bookName": "盗墓笔记.2,秦岭神树",
    "author": "南派三叔著"
  },
  {
    "name": "张洪阳",
    "borrowTime": "2025-09-22",
    "bookName": "盗墓笔记.3,云顶天宫",
    "author": "南派三叔著"
  },
  {
    "name": "张洪阳",
    "borrowTime": "2025-09-22",
    "bookName": "盗墓笔记.4,蛇沼鬼城",
    "author": "南派三叔著"
  },
  {
    "name": "张浩",
    "borrowTime": "2023-09-26",
    "bookName": "蛇骨山秘闻",
    "author": "铁头著"
  },
  {
    "name": "张浩",
    "borrowTime": "2023-10-06",
    "bookName": "诡案罪.4",
    "author": "岳勇著"
  },
  {
    "name": "张浩男",
    "borrowTime": "2023-09-24",
    "bookName": "兄弟.第3版",
    "author": "余华"
  },
  {
    "name": "张浩男",
    "borrowTime": "2024-09-21",
    "bookName": "大英博物馆人类简史",
    "author": "(英) 黛布拉·曼考夫著"
  },
  {
    "name": "张涵朔",
    "borrowTime": "2023-10-18",
    "bookName": "刑侦一科.上",
    "author": "黑羽时晴著"
  },
  {
    "name": "张淼",
    "borrowTime": "2025-03-05",
    "bookName": "大学体育教学与运动训练方法研究",
    "author": "周琪著"
  },
  {
    "name": "张淼",
    "borrowTime": "2025-03-06",
    "bookName": "盗墓笔记之秦岭神树.2",
    "author": "南派三叔原著"
  },
  {
    "name": "张淼",
    "borrowTime": "2025-03-06",
    "bookName": "七国银河:镐京魅影",
    "author": "宝树，阿缺著"
  },
  {
    "name": "张淼",
    "borrowTime": "2025-03-06",
    "bookName": "金棺陵兽",
    "author": "天下霸唱著"
  },
  {
    "name": "张渤生",
    "borrowTime": "2023-11-15",
    "bookName": "上知天文, 下知你心",
    "author": "谢潸然著"
  },
  {
    "name": "张瀚文",
    "borrowTime": "2023-09-18",
    "bookName": "诡案罪.4",
    "author": "岳勇著"
  },
  {
    "name": "张瀚文",
    "borrowTime": "2023-11-02",
    "bookName": "积案调查组",
    "author": "狐狸猫著"
  },
  {
    "name": "张皓博",
    "borrowTime": "2023-09-20",
    "bookName": "斗罗大陆.第二部,绝世唐门.23",
    "author": "唐家三少著"
  },
  {
    "name": "张皓博",
    "borrowTime": "2023-09-20",
    "bookName": "斗罗大陆.第二部,绝世唐门.24",
    "author": "唐家三少著"
  },
  {
    "name": "张皓博",
    "borrowTime": "2023-09-24",
    "bookName": "非自然事件",
    "author": "超级月亮著"
  },
  {
    "name": "张皓博",
    "borrowTime": "2023-10-08",
    "bookName": "天火大道.1",
    "author": "唐家三少著"
  },
  {
    "name": "张皓博",
    "borrowTime": "2023-10-12",
    "bookName": "沧元图.1",
    "author": "我吃西红柿著"
  },
  {
    "name": "张皓博",
    "borrowTime": "2023-11-23",
    "bookName": "毒后倾国.上",
    "author": "鹦鹉晒月作品"
  },
  {
    "name": "张皓博",
    "borrowTime": "2023-11-23",
    "bookName": "毒后倾国.下",
    "author": "鹦鹉晒月作品"
  },
  {
    "name": "张稼峻",
    "borrowTime": "2023-11-01",
    "bookName": "恶意.第3版",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "张稼峻",
    "borrowTime": "2023-12-07",
    "bookName": "地狱公寓.3",
    "author": "董协著"
  },
  {
    "name": "张稼峻",
    "borrowTime": "2023-12-08",
    "bookName": "黄金瞳.1.1",
    "author": "打眼著"
  },
  {
    "name": "张策",
    "borrowTime": "2023-09-26",
    "bookName": "黄金手",
    "author": "阿怪作品"
  },
  {
    "name": "张美玲",
    "borrowTime": "2024-10-28",
    "bookName": "漫画光影表现技法",
    "author": "何耀, 王海鸥编著"
  },
  {
    "name": "张美玲",
    "borrowTime": "2025-03-12",
    "bookName": "张道真英语用法:大众珍藏版.3版",
    "author": "张道真著"
  },
  {
    "name": "张美玲",
    "borrowTime": "2026-03-30",
    "bookName": "银河帝国.1,基地",
    "author": "(美) 艾萨克·阿西莫夫著"
  },
  {
    "name": "张美玲",
    "borrowTime": "2026-05-22",
    "bookName": "银河帝国.1,基地",
    "author": "(美) 艾萨克·阿西莫夫著"
  },
  {
    "name": "张美玲",
    "borrowTime": "2026-05-22",
    "bookName": "明朝那些事儿.增补版",
    "author": "当年明月著"
  },
  {
    "name": "张航",
    "borrowTime": "2023-09-26",
    "bookName": "燕归来",
    "author": "张恨水著"
  },
  {
    "name": "张艺严",
    "borrowTime": "2025-12-06",
    "bookName": "铁道概论",
    "author": "中国国家铁路集团有限公司运输部主编"
  },
  {
    "name": "张藩",
    "borrowTime": "2023-09-21",
    "bookName": "《黄河》三十周年精品文库,长篇小说梗概",
    "author": "总主编杜学文"
  },
  {
    "name": "张诚",
    "borrowTime": "2023-09-18",
    "bookName": "史记",
    "author": "(西汉) 司马迁著"
  },
  {
    "name": "张贵鹏",
    "borrowTime": "2024-06-16",
    "bookName": "我吃西红柿与《吞噬星空》",
    "author": "夏烈著"
  },
  {
    "name": "张贵鹏",
    "borrowTime": "2024-09-04",
    "bookName": "潮起潮落.一:长篇小说",
    "author": "李红著"
  },
  {
    "name": "张贵鹏",
    "borrowTime": "2024-09-04",
    "bookName": "佣兵天下全集.1.1",
    "author": "说不得大师著"
  },
  {
    "name": "张贵鹏",
    "borrowTime": "2024-09-04",
    "bookName": "十宗罪前传",
    "author": "蜘蛛作品"
  },
  {
    "name": "张贵鹏",
    "borrowTime": "2024-09-04",
    "bookName": "沧元图.1",
    "author": "我吃西红柿著"
  },
  {
    "name": "张贵鹏",
    "borrowTime": "2024-09-05",
    "bookName": "天齐大陆",
    "author": "月下泷痕著"
  },
  {
    "name": "张贵鹏",
    "borrowTime": "2024-09-05",
    "bookName": "魔兽战神,鲲鹏战场",
    "author": "龙人著"
  },
  {
    "name": "张贵鹏",
    "borrowTime": "2024-09-23",
    "bookName": "斗罗大陆.第四部,终极斗罗.16",
    "author": "唐家三少著"
  },
  {
    "name": "张贵鹏",
    "borrowTime": "2024-09-23",
    "bookName": "尸案调查科.2,重案捕手",
    "author": "九滴水著"
  },
  {
    "name": "张贵鹏",
    "borrowTime": "2024-09-23",
    "bookName": "刘慈欣获奖作品集:纪念珍藏版",
    "author": "刘慈欣著"
  },
  {
    "name": "张贵鹏",
    "borrowTime": "2024-10-15",
    "bookName": "诡案组外传",
    "author": "求无欲著"
  },
  {
    "name": "张贵鹏",
    "borrowTime": "2024-10-15",
    "bookName": "天齐大陆",
    "author": "月下泷痕著"
  },
  {
    "name": "张贵鹏",
    "borrowTime": "2024-10-17",
    "bookName": "尸案调查科.第二季.2,一念深渊",
    "author": "九滴水著"
  },
  {
    "name": "张贵鹏",
    "borrowTime": "2024-10-24",
    "bookName": "萌后, 请卸妆",
    "author": "江静九著"
  },
  {
    "name": "张贵鹏",
    "borrowTime": "2024-10-24",
    "bookName": "倾世风华.上",
    "author": "水何采采著"
  },
  {
    "name": "张贵鹏",
    "borrowTime": "2024-10-24",
    "bookName": "绝色大陆.上",
    "author": "林家成作品"
  },
  {
    "name": "张贵鹏",
    "borrowTime": "2024-10-29",
    "bookName": "元曲中的旅游",
    "author": "李金早主编"
  },
  {
    "name": "张贵鹏",
    "borrowTime": "2024-10-29",
    "bookName": "女主当自强",
    "author": "淡樱著"
  },
  {
    "name": "张贵鹏",
    "borrowTime": "2024-10-29",
    "bookName": "如沐春风",
    "author": "洛书,"
  },
  {
    "name": "张鑫宇",
    "borrowTime": "2023-11-29",
    "bookName": "守夜者.3,生死盲点",
    "author": "法医秦明著"
  },
  {
    "name": "张隽嵩",
    "borrowTime": "2024-05-13",
    "bookName": "灭罪者",
    "author": "鲁奇著"
  },
  {
    "name": "张隽嵩",
    "borrowTime": "2024-05-29",
    "bookName": "喂食者协会",
    "author": "那多著"
  },
  {
    "name": "张隽嵩",
    "borrowTime": "2024-05-29",
    "bookName": "十宗罪前传",
    "author": "蜘蛛作品"
  },
  {
    "name": "张雪松",
    "borrowTime": "2023-12-12",
    "bookName": "为什么男人想要性, 女人需要爱?",
    "author": "(澳) 芭芭拉·皮斯, 艾伦·皮斯著"
  },
  {
    "name": "张雪松",
    "borrowTime": "2024-05-15",
    "bookName": "从内耗到心流:复杂时代下的熵减行动指南",
    "author": "杨鸣著"
  },
  {
    "name": "张雪松",
    "borrowTime": "2024-05-24",
    "bookName": "班级管理难题35问",
    "author": "李迪著"
  },
  {
    "name": "张雪松",
    "borrowTime": "2024-09-23",
    "bookName": "拳王格斗:爆炸式重拳与侵略性防守:explosive punching & aggressive defense",
    "author": "(美)杰克·邓普西著"
  },
  {
    "name": "张雪松",
    "borrowTime": "2024-10-14",
    "bookName": "拳王格斗:爆炸式重拳与侵略性防守:explosive punching & aggressive defense",
    "author": "(美)杰克·邓普西著"
  },
  {
    "name": "张雪松",
    "borrowTime": "2024-10-21",
    "bookName": "论语.1",
    "author": "洋洋兔编绘"
  },
  {
    "name": "张雪松",
    "borrowTime": "2024-10-29",
    "bookName": "拳王格斗:爆炸式重拳与侵略性防守:explosive punching & aggressive defense",
    "author": "(美)杰克·邓普西著"
  },
  {
    "name": "张雪松",
    "borrowTime": "2024-12-12",
    "bookName": "拯救视力图解指南",
    "author": "(日)深作秀春著"
  },
  {
    "name": "彭涵",
    "borrowTime": "2023-09-27",
    "bookName": "无罪辩护",
    "author": "张海生著"
  },
  {
    "name": "徐凯琦",
    "borrowTime": "2023-09-19",
    "bookName": "心理大师",
    "author": "钟宇作品"
  },
  {
    "name": "徐凯琦",
    "borrowTime": "2023-10-07",
    "bookName": "黑案私探社",
    "author": "中雨作品"
  },
  {
    "name": "徐凯琦",
    "borrowTime": "2023-10-16",
    "bookName": "谜案组",
    "author": "秦园著"
  },
  {
    "name": "徐凯琦",
    "borrowTime": "2023-11-03",
    "bookName": "谜案组",
    "author": "秦园著"
  },
  {
    "name": "徐凯琦",
    "borrowTime": "2023-11-03",
    "bookName": "朱威讲诡异案之诡异日记",
    "author": "朱威著"
  },
  {
    "name": "徐凯琦",
    "borrowTime": "2023-11-03",
    "bookName": "十宗罪.5",
    "author": "蜘蛛著"
  },
  {
    "name": "徐凯琦",
    "borrowTime": "2023-11-07",
    "bookName": "自来水之污, 又名, 李泰和方小甜的平行世界",
    "author": "潇潇潇潇如编绘"
  },
  {
    "name": "徐凯琦",
    "borrowTime": "2023-11-07",
    "bookName": "上知天文, 下知你心",
    "author": "谢潸然著"
  },
  {
    "name": "徐升鑫",
    "borrowTime": "2023-10-07",
    "bookName": "赘婿.2,心如猛虎",
    "author": "愤怒的香蕉著"
  },
  {
    "name": "徐升鑫",
    "borrowTime": "2023-11-15",
    "bookName": "克苏鲁神话合集",
    "author": "(美) 霍华德·菲利普·洛夫克拉夫特著"
  },
  {
    "name": "徐升鑫",
    "borrowTime": "2023-11-15",
    "bookName": "傲世君少.4",
    "author": "风凌天下著"
  },
  {
    "name": "徐升鑫",
    "borrowTime": "2023-12-04",
    "bookName": "龙族.Ⅲ,黑月之潮,上.修订版",
    "author": "江南著"
  },
  {
    "name": "徐博宇",
    "borrowTime": "2023-09-18",
    "bookName": "希腊罗马神话集:永恒的诸神、英雄、爱情与冒险故事",
    "author": "(美)伊迪丝·汉密尔顿著"
  },
  {
    "name": "徐可成",
    "borrowTime": "2023-11-21",
    "bookName": "撒野",
    "author": "巫哲著"
  },
  {
    "name": "徐可成",
    "borrowTime": "2023-11-27",
    "bookName": "偷偷藏不住.上册",
    "author": "竹已著"
  },
  {
    "name": "徐可成",
    "borrowTime": "2023-11-27",
    "bookName": "白鹿原",
    "author": "陈忠实著"
  },
  {
    "name": "徐可成",
    "borrowTime": "2024-09-05",
    "bookName": "牧羊少年奇幻之旅",
    "author": "(巴西) 保罗·柯艾略著"
  },
  {
    "name": "徐弘岩",
    "borrowTime": "2023-10-08",
    "bookName": "天道图书馆.2,龙争虎斗",
    "author": "横扫天涯著"
  },
  {
    "name": "徐昊林",
    "borrowTime": "2023-09-12",
    "bookName": "图解二十五史故事:读历史故事 悟兴衰之道.彩图典藏版",
    "author": "木清编"
  },
  {
    "name": "徐昊林",
    "borrowTime": "2024-05-05",
    "bookName": "骈文",
    "author": "邓瑞全，孟祥静著"
  },
  {
    "name": "徐昊林",
    "borrowTime": "2024-05-05",
    "bookName": "乐府",
    "author": "王一娟著"
  },
  {
    "name": "徐昊林",
    "borrowTime": "2024-05-05",
    "bookName": "楚辞",
    "author": "周建忠著"
  },
  {
    "name": "徐昊林",
    "borrowTime": "2024-05-05",
    "bookName": "诗经心读",
    "author": "柳恩铭著"
  },
  {
    "name": "徐昊林",
    "borrowTime": "2024-05-05",
    "bookName": "最远的旅行",
    "author": "汤蕴瑾著"
  },
  {
    "name": "徐昊林",
    "borrowTime": "2024-06-04",
    "bookName": "边城",
    "author": "沈从文[著]"
  },
  {
    "name": "徐昊林",
    "borrowTime": "2024-06-04",
    "bookName": "失火的天堂",
    "author": "琼瑶,"
  },
  {
    "name": "徐昊林",
    "borrowTime": "2024-09-20",
    "bookName": "冬天的秘密",
    "author": "王俊凯著"
  },
  {
    "name": "徐浩宸",
    "borrowTime": "2025-11-20",
    "bookName": "不同班同学",
    "author": "安德林著"
  },
  {
    "name": "徐浩宸",
    "borrowTime": "2025-11-20",
    "bookName": "毕业生",
    "author": "梁晓声著"
  },
  {
    "name": "徐熙翔",
    "borrowTime": "2023-11-14",
    "bookName": "张作霖全传",
    "author": "李洪文著"
  },
  {
    "name": "徐维一",
    "borrowTime": "2023-09-19",
    "bookName": "无证之罪.第2版",
    "author": "紫金陈著"
  },
  {
    "name": "徐美金",
    "borrowTime": "2023-11-05",
    "bookName": "地底世界之幽潜重泉",
    "author": "天下霸唱著"
  },
  {
    "name": "徐美金",
    "borrowTime": "2023-12-14",
    "bookName": "谜小说.2010年第3辑,秘密",
    "author": "蔡骏主编"
  },
  {
    "name": "徐翰轩",
    "borrowTime": "2023-09-27",
    "bookName": "诡计设计师:完美罪恶",
    "author": "张嘉骏作品"
  },
  {
    "name": "徐翰轩",
    "borrowTime": "2023-09-27",
    "bookName": "隋唐演义:注释本",
    "author": "(清) 褚人获编撰"
  },
  {
    "name": "徐艺洋",
    "borrowTime": "2023-11-08",
    "bookName": "吞噬星空:典藏版.1",
    "author": "我吃西红柿著"
  },
  {
    "name": "徐艺洋",
    "borrowTime": "2023-11-20",
    "bookName": "诡秘之主.1,绯红之月",
    "author": "爱潜水的乌贼著"
  },
  {
    "name": "徐艺洋",
    "borrowTime": "2024-05-10",
    "bookName": "挪威的森林",
    "author": "村上春树著"
  },
  {
    "name": "徐轩",
    "borrowTime": "2023-10-16",
    "bookName": "三体",
    "author": "刘慈欣著"
  },
  {
    "name": "徐鉴书",
    "borrowTime": "2023-10-20",
    "bookName": "猫的公寓",
    "author": "何鹰著"
  },
  {
    "name": "徐鉴书",
    "borrowTime": "2023-10-20",
    "bookName": "理想主义罗曼史",
    "author": "王扬灵著"
  },
  {
    "name": "徐鉴书",
    "borrowTime": "2023-10-20",
    "bookName": "深夜古董店,寻瓷之旅",
    "author": "吉羽著"
  },
  {
    "name": "徐鉴书",
    "borrowTime": "2023-10-20",
    "bookName": "失踪法则",
    "author": "绿丝著"
  },
  {
    "name": "徐鸿梁",
    "borrowTime": "2024-09-19",
    "bookName": "车站信号自动控制系统维护",
    "author": "钱艺, 翟红兵主编"
  },
  {
    "name": "徐鸿梁",
    "borrowTime": "2024-12-25",
    "bookName": "区间信号自动控制.第3版",
    "author": "林瑜筠主编"
  },
  {
    "name": "徐鸿梁",
    "borrowTime": "2025-03-04",
    "bookName": "区间信号自动控制.第3版",
    "author": "林瑜筠主编"
  },
  {
    "name": "徐鸿梁",
    "borrowTime": "2025-03-04",
    "bookName": "铁路调度指挥系统维护",
    "author": "卢广文主编"
  },
  {
    "name": "徐鸿梁",
    "borrowTime": "2025-04-03",
    "bookName": "区间信号自动控制.第3版",
    "author": "林瑜筠主编"
  },
  {
    "name": "徐鸿梁",
    "borrowTime": "2025-04-07",
    "bookName": "铁路调度指挥系统维护",
    "author": "卢广文主编"
  },
  {
    "name": "徐鸿梁",
    "borrowTime": "2025-05-10",
    "bookName": "区间信号自动控制.第3版",
    "author": "林瑜筠主编"
  },
  {
    "name": "徐鸿梁",
    "borrowTime": "2025-05-10",
    "bookName": "铁路调度指挥系统维护",
    "author": "卢广文主编"
  },
  {
    "name": "徐鸿梁",
    "borrowTime": "2025-06-01",
    "bookName": "区间信号自动控制.第3版",
    "author": "林瑜筠主编"
  },
  {
    "name": "徐鸿梁",
    "borrowTime": "2025-06-02",
    "bookName": "铁路调度指挥系统维护",
    "author": "卢广文主编"
  },
  {
    "name": "徐鸿梁",
    "borrowTime": "2025-06-29",
    "bookName": "区间信号自动控制.第3版",
    "author": "林瑜筠主编"
  },
  {
    "name": "徐鸿梁",
    "borrowTime": "2025-06-29",
    "bookName": "铁路调度指挥系统维护",
    "author": "卢广文主编"
  },
  {
    "name": "徐鸿梁",
    "borrowTime": "2025-08-31",
    "bookName": "区间信号自动控制.第3版",
    "author": "林瑜筠主编"
  },
  {
    "name": "徐鸿梁",
    "borrowTime": "2026-03-04",
    "bookName": "ZPW-2000移频自动闭塞系统原理、维护和故障处理",
    "author": "李文海主编"
  },
  {
    "name": "徐鸿梁",
    "borrowTime": "2026-03-04",
    "bookName": "25Hz相敏轨道电路原理、维护和故障处理.第2版",
    "author": "李文海主编"
  },
  {
    "name": "徐鸿梁",
    "borrowTime": "2026-03-04",
    "bookName": "区间闭塞设备维护",
    "author": "主编穆中华"
  },
  {
    "name": "徐鸿梁",
    "borrowTime": "2026-03-09",
    "bookName": "微信小程序开发实战",
    "author": "张益珲编著"
  },
  {
    "name": "徐鸿梁",
    "borrowTime": "2026-03-09",
    "bookName": "",
    "author": ""
  },
  {
    "name": "徐鸿梁",
    "borrowTime": "2026-04-02",
    "bookName": "ZPW-2000A型自动闭塞设备知识问答与故障案例",
    "author": "北京铁路局编"
  },
  {
    "name": "徐鸿梁",
    "borrowTime": "2026-04-02",
    "bookName": "区间闭塞设备维护",
    "author": "主编穆中华"
  },
  {
    "name": "徐鸿梁",
    "borrowTime": "2026-04-02",
    "bookName": "ZPW-2000A移频自动闭塞系统原理、维护和故障处理",
    "author": "李文海主编"
  },
  {
    "name": "徐鸿梁",
    "borrowTime": "2026-04-02",
    "bookName": "ZPW-2000A型无绝缘移频自动闭塞设备维修与故障处理",
    "author": "《ZPW-2000A型无绝缘移频自动闭塞设备维修与故障处理》编委会编"
  },
  {
    "name": "徐鸿飞",
    "borrowTime": "2023-09-19",
    "bookName": "神医帝妃.第1部.第一卷,同是天涯沦落人",
    "author": "阿彩著"
  },
  {
    "name": "徐鸿飞",
    "borrowTime": "2023-10-10",
    "bookName": "一座营盘",
    "author": "陶纯著"
  },
  {
    "name": "徐鸿飞",
    "borrowTime": "2023-11-12",
    "bookName": "十大王牌军",
    "author": "陈冠任著"
  },
  {
    "name": "徐鸿飞",
    "borrowTime": "2024-10-25",
    "bookName": "轻松看懂电气控制线路及实物接线图",
    "author": "杜萌，刘振全，王汉芝编著"
  },
  {
    "name": "敖博文",
    "borrowTime": "2024-09-10",
    "bookName": "寻宝记神兽发电站.3.2版",
    "author": "任诗元编创"
  },
  {
    "name": "敖博文",
    "borrowTime": "2024-09-10",
    "bookName": "寻宝记神兽发电站.3.2版",
    "author": "任诗元编创"
  },
  {
    "name": "敖博文",
    "borrowTime": "2024-09-12",
    "bookName": "斗罗大陆.Ⅱ,绝世唐门.61:漫画版",
    "author": "唐家三少原著"
  },
  {
    "name": "敖博文",
    "borrowTime": "2024-09-12",
    "bookName": "斗罗大陆.Ⅱ,绝世唐门.62:漫画版",
    "author": "唐家三少原著"
  },
  {
    "name": "敖博文",
    "borrowTime": "2024-09-12",
    "bookName": "快把我哥带走.2,分秒必争.2版",
    "author": "幽·灵绘著"
  },
  {
    "name": "敖博文",
    "borrowTime": "2024-09-12",
    "bookName": "一拳超人.15,暗中活动的人们",
    "author": "(日) ONE原作"
  },
  {
    "name": "明业程",
    "borrowTime": "2023-10-07",
    "bookName": "吴承恩捉妖记",
    "author": "有时右逝著"
  },
  {
    "name": "明业程",
    "borrowTime": "2023-10-19",
    "bookName": "中国怪谈",
    "author": "赵志明著"
  },
  {
    "name": "明业程",
    "borrowTime": "2023-10-19",
    "bookName": "五道口贴吧故事",
    "author": "贺奕著"
  },
  {
    "name": "明业程",
    "borrowTime": "2023-10-21",
    "bookName": "超禁忌秘密.2.2",
    "author": "宁航一著"
  },
  {
    "name": "明业程",
    "borrowTime": "2023-10-21",
    "bookName": "黄金瞳.1.1",
    "author": "打眼著"
  },
  {
    "name": "明业程",
    "borrowTime": "2023-11-04",
    "bookName": "黄金瞳.2.2",
    "author": "打眼著"
  },
  {
    "name": "晁开辉",
    "borrowTime": "2023-09-18",
    "bookName": "你看完不敢睡, 看了还想看的悬疑小说.Ⅰ",
    "author": "白虹主编"
  },
  {
    "name": "晁开辉",
    "borrowTime": "2023-10-10",
    "bookName": "怪诞实录.第二季",
    "author": "凤仪著"
  },
  {
    "name": "曲学文",
    "borrowTime": "2023-10-10",
    "bookName": "撒野",
    "author": "巫哲著"
  },
  {
    "name": "曲学文",
    "borrowTime": "2023-11-17",
    "bookName": "偷偷藏不住.上册",
    "author": "竹已著"
  },
  {
    "name": "曲学文",
    "borrowTime": "2023-11-17",
    "bookName": "偷偷藏不住.上册",
    "author": "竹已著"
  },
  {
    "name": "曲烁",
    "borrowTime": "2023-09-25",
    "bookName": "龙族.Ⅰ,火之晨曦",
    "author": "江南著"
  },
  {
    "name": "曲烁",
    "borrowTime": "2023-10-07",
    "bookName": "黄金瞳.1.1",
    "author": "打眼著"
  },
  {
    "name": "曲烁",
    "borrowTime": "2023-10-23",
    "bookName": "龙族.Ⅳ,奥丁之渊",
    "author": "江南著"
  },
  {
    "name": "曲烁",
    "borrowTime": "2023-11-06",
    "bookName": "天齐大陆",
    "author": "月下泷痕著"
  },
  {
    "name": "曲烁",
    "borrowTime": "2024-04-29",
    "bookName": "女法医:温柔的解剖",
    "author": "明菲著"
  },
  {
    "name": "曲烁",
    "borrowTime": "2024-04-29",
    "bookName": "兽血大陆.1",
    "author": "灵隐狐著"
  },
  {
    "name": "曲烁",
    "borrowTime": "2024-04-29",
    "bookName": "沙海.第二卷,沙蟒蛇巢",
    "author": "南派三叔著"
  },
  {
    "name": "曲烁",
    "borrowTime": "2024-05-10",
    "bookName": "龙族.Ⅲ,黑月之潮,上.修订版",
    "author": "江南著"
  },
  {
    "name": "曲烁",
    "borrowTime": "2024-11-24",
    "bookName": "沙海.第二卷,沙蟒蛇巢",
    "author": "南派三叔著"
  },
  {
    "name": "曲烁",
    "borrowTime": "2024-11-24",
    "bookName": "沙海.第二卷,沙蟒蛇巢",
    "author": "南派三叔著"
  },
  {
    "name": "曲烁",
    "borrowTime": "2025-03-09",
    "bookName": "伍六七,玄武国篇.01",
    "author": "何小疯著绘"
  },
  {
    "name": "曲烁",
    "borrowTime": "2025-03-09",
    "bookName": "沙海.第二卷,沙蟒蛇巢",
    "author": "南派三叔著"
  },
  {
    "name": "曹司瀚",
    "borrowTime": "2023-09-27",
    "bookName": "兽血大陆.5",
    "author": "灵隐狐著"
  },
  {
    "name": "曹司瀚",
    "borrowTime": "2023-09-27",
    "bookName": "兽血大陆.4",
    "author": "灵隐狐著"
  },
  {
    "name": "曹司瀚",
    "borrowTime": "2023-10-09",
    "bookName": "武破苍穹.1",
    "author": "雨辰宇著"
  },
  {
    "name": "曹司瀚",
    "borrowTime": "2023-10-09",
    "bookName": "武破苍穹.2",
    "author": "雨辰宇著"
  },
  {
    "name": "曹司瀚",
    "borrowTime": "2023-11-01",
    "bookName": "诡秘之主.1,绯红之月",
    "author": "爱潜水的乌贼著"
  },
  {
    "name": "曹庭",
    "borrowTime": "2023-11-03",
    "bookName": "新诡案组",
    "author": "求无尘著"
  },
  {
    "name": "曹庭",
    "borrowTime": "2023-11-03",
    "bookName": "满世界找诡:散客月下四海奇谭",
    "author": "散客月下著"
  },
  {
    "name": "曹庭",
    "borrowTime": "2023-11-17",
    "bookName": "风雪山神庙",
    "author": "林戈声著"
  },
  {
    "name": "曹庭",
    "borrowTime": "2023-11-17",
    "bookName": "风雪山神庙",
    "author": "林戈声著"
  },
  {
    "name": "曹文硕",
    "borrowTime": "2023-11-14",
    "bookName": "知行合一王阳明:1472-1529",
    "author": "度阴山著"
  },
  {
    "name": "曹训宁",
    "borrowTime": "2023-10-07",
    "bookName": "黄金瞳.1.1",
    "author": "打眼著"
  },
  {
    "name": "朱伟东",
    "borrowTime": "2023-09-24",
    "bookName": "民调局异闻录.1,稚国迷窟",
    "author": "耳东水寿著"
  },
  {
    "name": "朱伟东",
    "borrowTime": "2023-10-06",
    "bookName": "民调局异闻录.1,稚国迷窟",
    "author": "耳东水寿著"
  },
  {
    "name": "朱伟东",
    "borrowTime": "2023-11-14",
    "bookName": "诡秘之主.1,绯红之月",
    "author": "爱潜水的乌贼著"
  },
  {
    "name": "朱伟东",
    "borrowTime": "2023-11-20",
    "bookName": "替身S",
    "author": "绫辻行人"
  },
  {
    "name": "朱伟东",
    "borrowTime": "2023-11-20",
    "bookName": "替身",
    "author": "绫辻行人著"
  },
  {
    "name": "朱伟东",
    "borrowTime": "2024-05-06",
    "bookName": "怪咖奇异事件簿,时间囚徒",
    "author": "蔡必贵著"
  },
  {
    "name": "朱伟东",
    "borrowTime": "2024-05-06",
    "bookName": "怪咖奇异事件簿,雪山禁忌",
    "author": "蔡必贵著"
  },
  {
    "name": "朱伟东",
    "borrowTime": "2024-05-06",
    "bookName": "怪咖奇异事件簿,游戏匿踪",
    "author": "蔡必贵著"
  },
  {
    "name": "朱伟东",
    "borrowTime": "2024-05-06",
    "bookName": "怪咖奇异事件簿,海岛梦境",
    "author": "蔡必贵著"
  },
  {
    "name": "朱伟东",
    "borrowTime": "2024-05-06",
    "bookName": "怪咖奇异事件簿,地库牢笼",
    "author": "蔡必贵著"
  },
  {
    "name": "朱伟东",
    "borrowTime": "2024-05-12",
    "bookName": "怪咖奇异事件簿,死亡待定",
    "author": "蔡必贵著"
  },
  {
    "name": "朱伟东",
    "borrowTime": "2024-05-12",
    "bookName": "怪咖奇异事件簿,真实妄想",
    "author": "蔡必贵著"
  },
  {
    "name": "朱伟东",
    "borrowTime": "2024-05-15",
    "bookName": "替身",
    "author": "绫辻行人著"
  },
  {
    "name": "朱伟东",
    "borrowTime": "2024-06-16",
    "bookName": "替身",
    "author": "绫辻行人著"
  },
  {
    "name": "朱伟东",
    "borrowTime": "2024-06-16",
    "bookName": "天气之子",
    "author": "(日) 新海诚著"
  },
  {
    "name": "朱佳成",
    "borrowTime": "2023-09-10",
    "bookName": "罪全书.6",
    "author": "蜘蛛著"
  },
  {
    "name": "朱佳成",
    "borrowTime": "2023-10-15",
    "bookName": "克苏鲁神话合集",
    "author": "(美) 霍华德·菲利普·洛夫克拉夫特著"
  },
  {
    "name": "朱佳成",
    "borrowTime": "2023-10-29",
    "bookName": "天气之子",
    "author": "(日) 新海诚著"
  },
  {
    "name": "朱佳成",
    "borrowTime": "2023-10-30",
    "bookName": "斗罗大陆.第四部,终极斗罗.16",
    "author": "唐家三少著"
  },
  {
    "name": "朱佳成",
    "borrowTime": "2023-10-30",
    "bookName": "斗罗大陆.第四部,终极斗罗.12",
    "author": "唐家三少著"
  },
  {
    "name": "朱佳成",
    "borrowTime": "2023-11-01",
    "bookName": "雪中悍刀行.11,逍遥游春秋",
    "author": "烽火戏诸侯著"
  },
  {
    "name": "朱佳成",
    "borrowTime": "2023-11-25",
    "bookName": "仙剑奇侠传.叁",
    "author": "管平潮作品"
  },
  {
    "name": "朱佳成",
    "borrowTime": "2023-11-25",
    "bookName": "仙剑奇侠传.肆",
    "author": "管平潮作品"
  },
  {
    "name": "朱傲楠",
    "borrowTime": "2023-10-09",
    "bookName": "斗破苍穹大主宰",
    "author": "天蚕土豆著"
  },
  {
    "name": "朱宇森",
    "borrowTime": "2025-10-09",
    "bookName": "反思，向前一步的工作方法",
    "author": "(日)熊平美香著"
  },
  {
    "name": "朱宇森",
    "borrowTime": "2025-11-05",
    "bookName": "自我的觉醒:拥抱真实自我的力量:how to escape your limitations and become the person you were born to be",
    "author": "(英)安德鲁·帕尔(Andrew Parr)著"
  },
  {
    "name": "朱宇森",
    "borrowTime": "2025-11-24",
    "bookName": "《周易》卦爻象辞正解",
    "author": "王孝庆著"
  },
  {
    "name": "朱家旺",
    "borrowTime": "2023-10-11",
    "bookName": "哇呜! 你可以带走我吗",
    "author": "虽虽酱绘著"
  },
  {
    "name": "朱家旺",
    "borrowTime": "2023-10-21",
    "bookName": "摸金传人.5,湘西蛊术",
    "author": "罗晓著"
  },
  {
    "name": "朱家旺",
    "borrowTime": "2023-11-05",
    "bookName": "斗罗大陆.第四部,终极斗罗.13",
    "author": "唐家三少著"
  },
  {
    "name": "朱庆凯",
    "borrowTime": "2023-10-08",
    "bookName": "恶意.第3版",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "朱庆凯",
    "borrowTime": "2023-12-10",
    "bookName": "东方快车谋杀案.第2版",
    "author": "(英) 阿加莎·克里斯蒂著"
  },
  {
    "name": "朱庆凯",
    "borrowTime": "2023-12-10",
    "bookName": "嫌疑人X的献身.第2版",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "朱庆凯",
    "borrowTime": "2024-09-12",
    "bookName": "岸边露伴在卢浮",
    "author": "(日)荒木飞吕彦著"
  },
  {
    "name": "朱庆凯",
    "borrowTime": "2024-09-26",
    "bookName": "局外人",
    "author": "(法)阿尔贝·加缪著"
  },
  {
    "name": "朱庆凯",
    "borrowTime": "2024-10-29",
    "bookName": "局外人",
    "author": "(法)阿尔贝·加缪著"
  },
  {
    "name": "朱欣原",
    "borrowTime": "2023-09-25",
    "bookName": "兽血大陆.1",
    "author": "灵隐狐著"
  },
  {
    "name": "朱欣原",
    "borrowTime": "2023-09-27",
    "bookName": "兽血大陆.2",
    "author": "灵隐狐著"
  },
  {
    "name": "朱欣原",
    "borrowTime": "2023-10-08",
    "bookName": "兽血大陆.3",
    "author": "灵隐狐著"
  },
  {
    "name": "朱欣原",
    "borrowTime": "2023-10-11",
    "bookName": "兽血大陆.4",
    "author": "灵隐狐著"
  },
  {
    "name": "朱欣原",
    "borrowTime": "2023-10-11",
    "bookName": "兽血大陆.5",
    "author": "灵隐狐著"
  },
  {
    "name": "朱欣原",
    "borrowTime": "2023-10-11",
    "bookName": "摸金传人.2,摄魂奇珠",
    "author": "罗晓著"
  },
  {
    "name": "朱欣原",
    "borrowTime": "2023-10-29",
    "bookName": "魔兽战神,鲲鹏战场",
    "author": "龙人著"
  },
  {
    "name": "朱欣原",
    "borrowTime": "2023-11-08",
    "bookName": "魔兽战神.2,十大战王",
    "author": "龙人著"
  },
  {
    "name": "朱治豪",
    "borrowTime": "2023-10-08",
    "bookName": "悲鸣之剑",
    "author": "刘靖宇著"
  },
  {
    "name": "朱治豪",
    "borrowTime": "2023-12-02",
    "bookName": "诡秘之主.1,绯红之月",
    "author": "爱潜水的乌贼著"
  },
  {
    "name": "朱治豪",
    "borrowTime": "2024-05-29",
    "bookName": "告白",
    "author": "(日) 凑佳苗著"
  },
  {
    "name": "朱美珊",
    "borrowTime": "2023-09-25",
    "bookName": "佛头遗案.第2版",
    "author": "楮实子著"
  },
  {
    "name": "朱逸婷",
    "borrowTime": "2024-10-13",
    "bookName": "犯罪心理档案.第四季",
    "author": "刚雪印著"
  },
  {
    "name": "朴冠達",
    "borrowTime": "2023-09-20",
    "bookName": "世界经典悬疑故事.超值彩图版",
    "author": "白虹主编"
  },
  {
    "name": "朴冠達",
    "borrowTime": "2023-10-06",
    "bookName": "惩罚者:大结局,完美谎言",
    "author": "韦一同著"
  },
  {
    "name": "朴冠達",
    "borrowTime": "2023-10-16",
    "bookName": "无证之罪.第2版",
    "author": "紫金陈著"
  },
  {
    "name": "朴冠達",
    "borrowTime": "2023-10-29",
    "bookName": "幸存者",
    "author": "秦明著"
  },
  {
    "name": "朴冠達",
    "borrowTime": "2023-11-12",
    "bookName": "诡计设计师:完美罪恶",
    "author": "张嘉骏作品"
  },
  {
    "name": "李世博",
    "borrowTime": "2023-09-12",
    "bookName": "世界经典悬疑故事",
    "author": "白虹主编"
  },
  {
    "name": "李世帆",
    "borrowTime": "2023-11-22",
    "bookName": "魔戒.第一部,魔戒同盟.Ⅰ,The fellowship of the ring.插图本",
    "author": "(英) J. R. R. 托尔金著"
  },
  {
    "name": "李世帆",
    "borrowTime": "2024-11-11",
    "bookName": "暮天归思",
    "author": "余秋雨著"
  },
  {
    "name": "李世帆",
    "borrowTime": "2024-11-11",
    "bookName": "天之炽.1.1,红龙的归来",
    "author": "江南作品"
  },
  {
    "name": "李世帆",
    "borrowTime": "2025-11-30",
    "bookName": "铁道概论",
    "author": "中国国家铁路集团有限公司运输部主编"
  },
  {
    "name": "李东旭",
    "borrowTime": "2024-06-26",
    "bookName": "图说资本论",
    "author": "卡尔·海因里希·马克思著"
  },
  {
    "name": "李中宇",
    "borrowTime": "2023-10-16",
    "bookName": "围观历史之摄政",
    "author": "儒爵爷著"
  },
  {
    "name": "李佳咏",
    "borrowTime": "2023-09-27",
    "bookName": "痕迹",
    "author": "毕蔷著"
  },
  {
    "name": "李佳咏",
    "borrowTime": "2023-09-27",
    "bookName": "灭罪者",
    "author": "鲁奇著"
  },
  {
    "name": "李佳航",
    "borrowTime": "2023-12-04",
    "bookName": "世界怪奇实话.第三辑",
    "author": "(日) 牧逸马著"
  },
  {
    "name": "李俊杰",
    "borrowTime": "2023-10-27",
    "bookName": "再见, 小青春",
    "author": "陌安凉著"
  },
  {
    "name": "李俊杰",
    "borrowTime": "2025-03-10",
    "bookName": "土木工程材料",
    "author": "赵亚丁主编"
  },
  {
    "name": "李俊杰",
    "borrowTime": "2025-03-10",
    "bookName": "土木工程材料学.2版",
    "author": "姜晨光主编"
  },
  {
    "name": "李俊达",
    "borrowTime": "2023-10-15",
    "bookName": "盘龙.Ⅱ,龙血之怒",
    "author": "我吃西红柿作品"
  },
  {
    "name": "李俊达",
    "borrowTime": "2024-05-06",
    "bookName": "嫌疑人X的献身.第2版",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "李兴华",
    "borrowTime": "2025-05-13",
    "bookName": "哈利·波特与魔法石",
    "author": "(英) J.K.罗琳著"
  },
  {
    "name": "李兴华",
    "borrowTime": "2025-05-13",
    "bookName": "哈利·波特与火焰杯",
    "author": "(英) J.K.罗琳著"
  },
  {
    "name": "李兴华",
    "borrowTime": "2025-05-13",
    "bookName": "哈利·波特与“混血王子”",
    "author": "(英) J. K.罗琳著"
  },
  {
    "name": "李兴华",
    "borrowTime": "2025-06-26",
    "bookName": "哈利·波特与魔法石",
    "author": "(英) J.K.罗琳著"
  },
  {
    "name": "李军领",
    "borrowTime": "2023-10-23",
    "bookName": "吞噬星空:典藏版.1",
    "author": "我吃西红柿著"
  },
  {
    "name": "李和华",
    "borrowTime": "2023-10-12",
    "bookName": "武破苍穹.5",
    "author": "雨辰宇著"
  },
  {
    "name": "李和华",
    "borrowTime": "2023-10-12",
    "bookName": "武破苍穹.3",
    "author": "雨辰宇著"
  },
  {
    "name": "李和华",
    "borrowTime": "2023-10-12",
    "bookName": "武破苍穹.4",
    "author": "雨辰宇著"
  },
  {
    "name": "李和华",
    "borrowTime": "2023-10-16",
    "bookName": "犯罪心理档案.第三季",
    "author": "刚雪印作品"
  },
  {
    "name": "李和华",
    "borrowTime": "2024-06-04",
    "bookName": "罪全书.4",
    "author": "蜘蛛著"
  },
  {
    "name": "李响",
    "borrowTime": "2023-10-14",
    "bookName": "九州缥缈录.Ⅲ.Ⅲ,天下名将",
    "author": "江南著"
  },
  {
    "name": "李响",
    "borrowTime": "2024-09-12",
    "bookName": "七种武器,离别钩·霸王枪.3",
    "author": "古龙,"
  },
  {
    "name": "李响",
    "borrowTime": "2024-09-28",
    "bookName": "七种武器,愤怒的小马·七杀手.4",
    "author": "古龙,"
  },
  {
    "name": "李响",
    "borrowTime": "2024-10-17",
    "bookName": "欢乐英雄.上",
    "author": "古龙,"
  },
  {
    "name": "李响",
    "borrowTime": "2024-10-29",
    "bookName": "欢乐英雄.下",
    "author": "古龙,"
  },
  {
    "name": "李响",
    "borrowTime": "2024-11-11",
    "bookName": "英雄无泪",
    "author": "古龙,"
  },
  {
    "name": "李响",
    "borrowTime": "2024-11-25",
    "bookName": "大地飞鹰.上",
    "author": "古龙,"
  },
  {
    "name": "李响",
    "borrowTime": "2024-12-09",
    "bookName": "大地飞鹰.下",
    "author": "古龙,"
  },
  {
    "name": "李响",
    "borrowTime": "2025-03-05",
    "bookName": "三少爷的剑",
    "author": "古龙,"
  },
  {
    "name": "李啸宇",
    "borrowTime": "2023-10-15",
    "bookName": "婉约词",
    "author": "(唐) 温庭筠等著"
  },
  {
    "name": "李啸宇",
    "borrowTime": "2023-10-23",
    "bookName": "罪全书.6",
    "author": "蜘蛛著"
  },
  {
    "name": "李啸宇",
    "borrowTime": "2023-10-31",
    "bookName": "天谴者",
    "author": "法医秦明著"
  },
  {
    "name": "李啸宇",
    "borrowTime": "2023-11-05",
    "bookName": "盘龙.Ⅱ,龙血之怒",
    "author": "我吃西红柿作品"
  },
  {
    "name": "李国涛",
    "borrowTime": "2023-09-19",
    "bookName": "简读聊斋志异",
    "author": "一水间编著"
  },
  {
    "name": "李国涛",
    "borrowTime": "2023-09-19",
    "bookName": "简读聊斋志异",
    "author": "一水间编著"
  },
  {
    "name": "李国涛",
    "borrowTime": "2023-10-21",
    "bookName": "亡者永生",
    "author": "那多著"
  },
  {
    "name": "李国涛",
    "borrowTime": "2023-10-23",
    "bookName": "绝对零度.1,飞天",
    "author": "樊落著"
  },
  {
    "name": "李国涛",
    "borrowTime": "2023-11-22",
    "bookName": "黄金瞳.1.1",
    "author": "打眼著"
  },
  {
    "name": "李国涛",
    "borrowTime": "2024-05-08",
    "bookName": "黄金瞳.8.8",
    "author": "打眼著"
  },
  {
    "name": "李奇朔",
    "borrowTime": "2023-10-29",
    "bookName": "死前七天",
    "author": "(瑞典) 卡瑞纳·伯格费尔特著"
  },
  {
    "name": "李奇朔",
    "borrowTime": "2023-11-21",
    "bookName": "重回犯罪现场.3",
    "author": "风雨如书著"
  },
  {
    "name": "李子豪",
    "borrowTime": "2023-09-14",
    "bookName": "吞噬星空:典藏版.1",
    "author": "我吃西红柿著"
  },
  {
    "name": "李子豪",
    "borrowTime": "2023-09-24",
    "bookName": "天道图书馆.2,龙争虎斗",
    "author": "横扫天涯著"
  },
  {
    "name": "李子豪",
    "borrowTime": "2023-09-26",
    "bookName": "气冲星河.1,少年无双",
    "author": "犁天著"
  },
  {
    "name": "李子豪",
    "borrowTime": "2023-10-16",
    "bookName": "无终仙境",
    "author": "天下霸唱著"
  },
  {
    "name": "李子豪",
    "borrowTime": "2023-10-20",
    "bookName": "气冲星河.9,太古之谜",
    "author": "犁天著"
  },
  {
    "name": "李子豪",
    "borrowTime": "2023-10-31",
    "bookName": "武破苍穹.1",
    "author": "雨辰宇著"
  },
  {
    "name": "李子豪",
    "borrowTime": "2023-11-05",
    "bookName": "武破苍穹.3",
    "author": "雨辰宇著"
  },
  {
    "name": "李子豪",
    "borrowTime": "2023-11-05",
    "bookName": "武破苍穹.2",
    "author": "雨辰宇著"
  },
  {
    "name": "李子豪",
    "borrowTime": "2023-11-07",
    "bookName": "武破苍穹.4",
    "author": "雨辰宇著"
  },
  {
    "name": "李子豪",
    "borrowTime": "2023-11-07",
    "bookName": "武破苍穹.5",
    "author": "雨辰宇著"
  },
  {
    "name": "李子豪",
    "borrowTime": "2023-11-12",
    "bookName": "兽血大陆.1",
    "author": "灵隐狐著"
  },
  {
    "name": "李子豪",
    "borrowTime": "2023-11-12",
    "bookName": "兽血大陆.3",
    "author": "灵隐狐著"
  },
  {
    "name": "李子豪",
    "borrowTime": "2023-11-12",
    "bookName": "兽血大陆.2",
    "author": "灵隐狐著"
  },
  {
    "name": "李子豪",
    "borrowTime": "2023-11-15",
    "bookName": "兽血大陆.5",
    "author": "灵隐狐著"
  },
  {
    "name": "李子豪",
    "borrowTime": "2023-11-15",
    "bookName": "兽血大陆.4",
    "author": "灵隐狐著"
  },
  {
    "name": "李子豪",
    "borrowTime": "2023-11-22",
    "bookName": "末日解剖",
    "author": "谢宗玉著"
  },
  {
    "name": "李宇泽",
    "borrowTime": "2023-10-15",
    "bookName": "七宗罪:魔鬼的侧影:twenty-five years of FBI war stories",
    "author": "(美)詹姆斯·博汀著"
  },
  {
    "name": "李宣纬",
    "borrowTime": "2024-09-21",
    "bookName": "康熙大帝",
    "author": "阎崇年著"
  },
  {
    "name": "李宣纬",
    "borrowTime": "2024-10-19",
    "bookName": "运作",
    "author": "何常在著"
  },
  {
    "name": "李宣纬",
    "borrowTime": "2024-10-19",
    "bookName": "说话办事的艺术",
    "author": "刘德胜改编"
  },
  {
    "name": "李广",
    "borrowTime": "2023-10-11",
    "bookName": "吞噬星空:典藏版.1",
    "author": "我吃西红柿著"
  },
  {
    "name": "李忠泽",
    "borrowTime": "2023-11-21",
    "bookName": "偷窥者:死亡不是结束而是另一种开始",
    "author": "秦明著"
  },
  {
    "name": "李想",
    "borrowTime": "2025-09-22",
    "bookName": "焦虑是一种能量",
    "author": "尹依依著"
  },
  {
    "name": "李慧涛",
    "borrowTime": "2023-09-25",
    "bookName": "山海经,赤影传说.下",
    "author": "原创故事豆丁, 易小草, 耀之"
  },
  {
    "name": "李慧涛",
    "borrowTime": "2023-09-25",
    "bookName": "山海经,赤影传说.上",
    "author": "原创故事豆丁, 易小草, 耀之"
  },
  {
    "name": "李新桐",
    "borrowTime": "2023-12-05",
    "bookName": "印度异闻录",
    "author": "羊行屮著"
  },
  {
    "name": "李新桐",
    "borrowTime": "2024-05-07",
    "bookName": "民调局异闻录.1,稚国迷窟",
    "author": "耳东水寿著"
  },
  {
    "name": "李旺龙",
    "borrowTime": "2025-10-13",
    "bookName": "荒野植被",
    "author": "麦香鸡呢著"
  },
  {
    "name": "李昊阳",
    "borrowTime": "2023-09-19",
    "bookName": "极凶之地",
    "author": "轩胖儿著"
  },
  {
    "name": "李昊阳",
    "borrowTime": "2023-10-22",
    "bookName": "怪谈·高野圣僧",
    "author": "(日)泉镜花著"
  },
  {
    "name": "李明洋",
    "borrowTime": "2023-11-03",
    "bookName": "杀死一只知更鸟",
    "author": "(美) 哈珀·李著"
  },
  {
    "name": "李明洋",
    "borrowTime": "2023-11-03",
    "bookName": "怪物恋人",
    "author": "郭斯特作品"
  },
  {
    "name": "李明洋",
    "borrowTime": "2023-11-29",
    "bookName": "杀死一只知更鸟",
    "author": "(美) 哈珀·李著"
  },
  {
    "name": "李明轩",
    "borrowTime": "2023-10-07",
    "bookName": "我在青春里等你",
    "author": "宛沐清著"
  },
  {
    "name": "李明轩",
    "borrowTime": "2023-11-06",
    "bookName": "我在青春里等你",
    "author": "宛沐清著"
  },
  {
    "name": "李明道",
    "borrowTime": "2023-11-20",
    "bookName": "心理罪.1,第七个读者",
    "author": "雷米著"
  },
  {
    "name": "李易泽",
    "borrowTime": "2024-05-12",
    "bookName": "路由交换技术与网络工程设计",
    "author": "饶绪黎，章丞编著"
  },
  {
    "name": "李星鹏",
    "borrowTime": "2024-09-02",
    "bookName": "后来的我们 没有了我们",
    "author": "野子著"
  },
  {
    "name": "李星鹏",
    "borrowTime": "2024-09-02",
    "bookName": "脑洞大会:真相, 可不止一个！",
    "author": "上海金孵文化传播有限公司编"
  },
  {
    "name": "李晓颖",
    "borrowTime": "2025-05-20",
    "bookName": "罪全书.5",
    "author": "蜘蛛著"
  },
  {
    "name": "李晨",
    "borrowTime": "2023-10-18",
    "bookName": "没有人是无辜的",
    "author": "梦亦非著"
  },
  {
    "name": "李晨",
    "borrowTime": "2024-05-14",
    "bookName": "白夜行.第2版",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "李晨",
    "borrowTime": "2024-09-19",
    "bookName": "怪物同学会",
    "author": "全球华语科幻星云奖组委会编"
  },
  {
    "name": "李智宇",
    "borrowTime": "2024-10-24",
    "bookName": "尸案调查科.第二季.2,一念深渊",
    "author": "九滴水著"
  },
  {
    "name": "李林峰",
    "borrowTime": "2023-10-21",
    "bookName": "你的行为使我们恐惧",
    "author": "莫言,"
  },
  {
    "name": "李林峰",
    "borrowTime": "2023-11-07",
    "bookName": "平凡的世界",
    "author": "路遥著"
  },
  {
    "name": "李栋梁",
    "borrowTime": "2023-11-28",
    "bookName": "明朝那些事儿.增补版",
    "author": "当年明月著"
  },
  {
    "name": "李梓郡",
    "borrowTime": "2023-10-07",
    "bookName": "特案科:刑警手记.下",
    "author": "风雨如书著"
  },
  {
    "name": "李梓郡",
    "borrowTime": "2023-10-23",
    "bookName": "心理罪,第七个读者",
    "author": "雷米作品"
  },
  {
    "name": "李欣然",
    "borrowTime": "2023-09-27",
    "bookName": "围城.第2版",
    "author": "钱锺书著"
  },
  {
    "name": "李泓辰",
    "borrowTime": "2024-11-18",
    "bookName": "南渡北归,离别:大结局",
    "author": "岳南著"
  },
  {
    "name": "李泓辰",
    "borrowTime": "2024-11-18",
    "bookName": "南渡北归.第一部,南渡",
    "author": "岳南著"
  },
  {
    "name": "李泓辰",
    "borrowTime": "2024-11-18",
    "bookName": "南渡北归.第二部,北归",
    "author": "岳南著"
  },
  {
    "name": "李泰琦",
    "borrowTime": "2023-10-22",
    "bookName": "怪诞故事集",
    "author": "(意) 伊塔洛·卡尔维诺编"
  },
  {
    "name": "李泽楷",
    "borrowTime": "2023-10-11",
    "bookName": "濒死之眼",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "李泽楷",
    "borrowTime": "2023-10-11",
    "bookName": "飞鸟集·新月集",
    "author": "(印度) 泰戈尔著"
  },
  {
    "name": "李泽楷",
    "borrowTime": "2023-10-20",
    "bookName": "中国短篇小说年度佳作.2014",
    "author": "孟繁华主编"
  },
  {
    "name": "李泽楷",
    "borrowTime": "2023-10-20",
    "bookName": "阿弥陀佛么么哒",
    "author": "大冰作品"
  },
  {
    "name": "李泽楷",
    "borrowTime": "2023-10-20",
    "bookName": "好吗好的",
    "author": "大冰作品"
  },
  {
    "name": "李浩然",
    "borrowTime": "2023-09-12",
    "bookName": "黄金瞳.2.2",
    "author": "打眼著"
  },
  {
    "name": "李浩然",
    "borrowTime": "2023-09-25",
    "bookName": "撒野",
    "author": "巫哲著"
  },
  {
    "name": "李海涛",
    "borrowTime": "2023-09-12",
    "bookName": "世界经典推理小说",
    "author": "王春祥主编"
  },
  {
    "name": "李海涛",
    "borrowTime": "2023-11-24",
    "bookName": "魔兽战神.4,战皇之路",
    "author": "龙人著"
  },
  {
    "name": "李海涛",
    "borrowTime": "2023-11-24",
    "bookName": "猎凶者.1",
    "author": "范亮著"
  },
  {
    "name": "李海涛",
    "borrowTime": "2023-12-04",
    "bookName": "重回犯罪现场.3",
    "author": "风雨如书著"
  },
  {
    "name": "李海涛",
    "borrowTime": "2023-12-05",
    "bookName": "特案科:刑警手记.上",
    "author": "风雨如书著"
  },
  {
    "name": "李海涛",
    "borrowTime": "2024-05-05",
    "bookName": "斗罗大陆.第四部,终极斗罗.12",
    "author": "唐家三少著"
  },
  {
    "name": "李海玉",
    "borrowTime": "2025-03-06",
    "bookName": "余罪:我的刑侦笔记.1",
    "author": "常书欣著"
  },
  {
    "name": "李海玉",
    "borrowTime": "2025-03-08",
    "bookName": "余罪:我的刑侦笔记.2",
    "author": "常书欣著"
  },
  {
    "name": "李海玉",
    "borrowTime": "2025-03-09",
    "bookName": "余罪:我的刑侦笔记.3:一个传奇警察和毒贩、悍匪、黑道大佬的交锋实录",
    "author": "常书欣著"
  },
  {
    "name": "李海玉",
    "borrowTime": "2025-03-11",
    "bookName": "余罪:我的刑侦笔记.5",
    "author": "常书欣著"
  },
  {
    "name": "李海玉",
    "borrowTime": "2025-03-11",
    "bookName": "余罪:我的刑侦笔记.4:一个传奇警察和毒贩、悍匪、黑道大佬的交锋实录",
    "author": "常书欣著"
  },
  {
    "name": "李海玉",
    "borrowTime": "2025-03-14",
    "bookName": "余罪:我的刑侦笔记.8",
    "author": "常书欣著"
  },
  {
    "name": "李海玉",
    "borrowTime": "2025-03-14",
    "bookName": "余罪:我的刑侦笔记.6",
    "author": "常书欣著"
  },
  {
    "name": "李海玉",
    "borrowTime": "2025-03-14",
    "bookName": "余罪:我的刑侦笔记.7",
    "author": "常书欣著"
  },
  {
    "name": "李海玉",
    "borrowTime": "2025-03-30",
    "bookName": "那些有钱的年轻人, 原名: 老子是癞蛤蟆",
    "author": "烽火戏诸侯著"
  },
  {
    "name": "李海玉",
    "borrowTime": "2025-03-30",
    "bookName": "人民的名义:纪念版",
    "author": "周梅森著"
  },
  {
    "name": "李海玉",
    "borrowTime": "2025-04-25",
    "bookName": "人民的名义:纪念版",
    "author": "周梅森著"
  },
  {
    "name": "李海玉",
    "borrowTime": "2025-10-28",
    "bookName": "摸金校尉之九幽将军",
    "author": "天下霸唱著"
  },
  {
    "name": "李炀",
    "borrowTime": "2023-12-03",
    "bookName": "白色橄榄树",
    "author": "玖月晞著"
  },
  {
    "name": "李烨",
    "borrowTime": "2023-11-16",
    "bookName": "白色橄榄树",
    "author": "玖月晞著"
  },
  {
    "name": "李瑞",
    "borrowTime": "2024-04-28",
    "bookName": "白夜追凶",
    "author": "剧本原著指纹"
  },
  {
    "name": "李瑞",
    "borrowTime": "2024-10-08",
    "bookName": "嫌疑人X的献身.第2版",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "李瑞",
    "borrowTime": "2024-11-27",
    "bookName": "寻情记.6,舍利",
    "author": "鬼山僧作品"
  },
  {
    "name": "李瑞",
    "borrowTime": "2025-03-05",
    "bookName": "救赎.下",
    "author": "陆沉著"
  },
  {
    "name": "李禹歧",
    "borrowTime": "2023-09-18",
    "bookName": "人间游戏,牢笼",
    "author": "钟宇著"
  },
  {
    "name": "李禹歧",
    "borrowTime": "2023-09-27",
    "bookName": "89号档案馆",
    "author": "孙铭苑著"
  },
  {
    "name": "李禹歧",
    "borrowTime": "2023-10-06",
    "bookName": "世界经典悬疑故事.超值彩图版",
    "author": "白虹主编"
  },
  {
    "name": "李禹歧",
    "borrowTime": "2023-10-08",
    "bookName": "诡案组.3,双尾猫妖.修订版",
    "author": "求无欲著"
  },
  {
    "name": "李禹歧",
    "borrowTime": "2023-10-22",
    "bookName": "摸金传人.5,湘西蛊术",
    "author": "罗晓著"
  },
  {
    "name": "李禹歧",
    "borrowTime": "2023-11-02",
    "bookName": "黄金瞳.1.1",
    "author": "打眼著"
  },
  {
    "name": "李秋实",
    "borrowTime": "2024-05-06",
    "bookName": "第七天.3版",
    "author": "余华著"
  },
  {
    "name": "李秋实",
    "borrowTime": "2024-05-15",
    "bookName": "爱你时有风",
    "author": "绿亦歌著"
  },
  {
    "name": "李秋实",
    "borrowTime": "2024-06-11",
    "bookName": "南风有归期",
    "author": "子木桑桑著"
  },
  {
    "name": "李秋实",
    "borrowTime": "2024-09-24",
    "bookName": "彩虹几度",
    "author": "(日)川端康成著"
  },
  {
    "name": "李秋实",
    "borrowTime": "2024-09-26",
    "bookName": "我怕来不及说我爱你",
    "author": "李小艾作品"
  },
  {
    "name": "李秋实",
    "borrowTime": "2024-09-26",
    "bookName": "兽血大陆.1",
    "author": "灵隐狐著"
  },
  {
    "name": "李秋实",
    "borrowTime": "2024-09-28",
    "bookName": "兽血大陆.2",
    "author": "灵隐狐著"
  },
  {
    "name": "李秋实",
    "borrowTime": "2024-09-28",
    "bookName": "兽血大陆.4",
    "author": "灵隐狐著"
  },
  {
    "name": "李秋实",
    "borrowTime": "2024-09-28",
    "bookName": "兽血大陆.3",
    "author": "灵隐狐著"
  },
  {
    "name": "李秋实",
    "borrowTime": "2024-10-13",
    "bookName": "猫侦探的名推理",
    "author": "(日)广元著"
  },
  {
    "name": "李秋实",
    "borrowTime": "2024-10-24",
    "bookName": "赛雷三分钟漫画世界史.2",
    "author": "赛雷"
  },
  {
    "name": "李程辉",
    "borrowTime": "2023-09-04",
    "bookName": "原罪.1,迷案追踪",
    "author": "一曲东风著"
  },
  {
    "name": "李精忠",
    "borrowTime": "2024-05-06",
    "bookName": "心理罪,暗河",
    "author": "雷米作品"
  },
  {
    "name": "李精忠",
    "borrowTime": "2024-09-02",
    "bookName": "龙族.Ⅰ,火之晨曦",
    "author": "江南著"
  },
  {
    "name": "李精忠",
    "borrowTime": "2024-09-02",
    "bookName": "小马哥教你打台球:中式8球实用练习法",
    "author": "马志宇著"
  },
  {
    "name": "李金栋",
    "borrowTime": "2023-09-26",
    "bookName": "连环罪:心理有诡",
    "author": "墨绿青苔著"
  },
  {
    "name": "李金瀚",
    "borrowTime": "2023-11-17",
    "bookName": "世界历史",
    "author": "本册主编李稚勇, 李伟国"
  },
  {
    "name": "李鑫博",
    "borrowTime": "2023-10-10",
    "bookName": "你当像鸟飞往你的山",
    "author": "(美) 塔拉·韦斯特弗著"
  },
  {
    "name": "李鑫博",
    "borrowTime": "2024-05-07",
    "bookName": "时间移民",
    "author": "刘慈欣作品"
  },
  {
    "name": "李鑫博",
    "borrowTime": "2024-05-07",
    "bookName": "新能源汽车概论.2版",
    "author": "高建平主编"
  },
  {
    "name": "李鑫博",
    "borrowTime": "2024-05-19",
    "bookName": "走近有轨电车,设计篇",
    "author": "张中杰主编"
  },
  {
    "name": "李鑫龙",
    "borrowTime": "2026-04-10",
    "bookName": "边缘",
    "author": "格非"
  },
  {
    "name": "李鑫龙",
    "borrowTime": "2026-04-18",
    "bookName": "回应:关于“一带一路”的十种声音",
    "author": "王义桅著"
  },
  {
    "name": "李钰泽",
    "borrowTime": "2023-09-26",
    "bookName": "剑王朝.第五卷,剪翼",
    "author": "无罪著"
  },
  {
    "name": "李钰泽",
    "borrowTime": "2025-12-22",
    "bookName": "牵引变电所运行与维护",
    "author": "北京铁路局编"
  },
  {
    "name": "李铭博",
    "borrowTime": "2023-10-31",
    "bookName": "直播二战",
    "author": "丘吉尔等著"
  },
  {
    "name": "李铭博",
    "borrowTime": "2023-11-28",
    "bookName": "核危机",
    "author": "蒋世杰著"
  },
  {
    "name": "李阔",
    "borrowTime": "2025-06-11",
    "bookName": "东北振兴理论与政策研究",
    "author": "刘海军主编"
  },
  {
    "name": "李雪松",
    "borrowTime": "2023-10-31",
    "bookName": "原罪",
    "author": "吕铮著"
  },
  {
    "name": "李雪松",
    "borrowTime": "2023-11-28",
    "bookName": "法医档案.03,迟来真相.03,Truth comes late",
    "author": "戴西著"
  },
  {
    "name": "杜炳毅",
    "borrowTime": "2023-10-22",
    "bookName": "赘婿.3,山雨欲来",
    "author": "愤怒的香蕉著"
  },
  {
    "name": "杜炳毅",
    "borrowTime": "2023-10-22",
    "bookName": "赘婿.2,心如猛虎",
    "author": "愤怒的香蕉著"
  },
  {
    "name": "杜炳毅",
    "borrowTime": "2023-10-22",
    "bookName": "赘婿.1,江宁晨风",
    "author": "愤怒的香蕉著"
  },
  {
    "name": "杜炳毅",
    "borrowTime": "2023-11-15",
    "bookName": "基本乐理",
    "author": "崔宪主编"
  },
  {
    "name": "杜炳毅",
    "borrowTime": "2023-11-15",
    "bookName": "古筝轻松入门:111首独奏曲超精选",
    "author": "袁叶子编著"
  },
  {
    "name": "杜磊宏",
    "borrowTime": "2024-10-23",
    "bookName": "羊皮卷",
    "author": "(美)奥格·曼狄诺著"
  },
  {
    "name": "杜磊宏",
    "borrowTime": "2024-11-15",
    "bookName": "红岩.3版",
    "author": "罗广斌，杨益言著"
  },
  {
    "name": "杜磊宏",
    "borrowTime": "2024-11-15",
    "bookName": "场馆、史迹与红岩精神",
    "author": "朱军，王春山编著"
  },
  {
    "name": "杨丰玮",
    "borrowTime": "2023-09-26",
    "bookName": "十宗罪.5",
    "author": "蜘蛛著"
  },
  {
    "name": "杨丰齐",
    "borrowTime": "2023-10-10",
    "bookName": "堂吉诃德",
    "author": "(西) 米格尔·塞万提斯著"
  },
  {
    "name": "杨丰齐",
    "borrowTime": "2023-11-30",
    "bookName": "杀死一只知更鸟",
    "author": "(美) 哈珀·李著"
  },
  {
    "name": "杨丰齐",
    "borrowTime": "2024-10-08",
    "bookName": "牛津拜占庭史",
    "author": "(英) 西里尔·曼戈主编"
  },
  {
    "name": "杨丰齐",
    "borrowTime": "2024-10-23",
    "bookName": "牛津拜占庭史",
    "author": "(英) 西里尔·曼戈主编"
  },
  {
    "name": "杨丰齐",
    "borrowTime": "2024-11-13",
    "bookName": "牛津拜占庭史",
    "author": "(英) 西里尔·曼戈主编"
  },
  {
    "name": "杨丰齐",
    "borrowTime": "2024-12-20",
    "bookName": "牛津拜占庭史",
    "author": "(英) 西里尔·曼戈主编"
  },
  {
    "name": "杨储铭",
    "borrowTime": "2023-10-08",
    "bookName": "摸金传人.2,摄魂奇珠",
    "author": "罗晓著"
  },
  {
    "name": "杨储铭",
    "borrowTime": "2023-10-21",
    "bookName": "盗墓玄机:长篇盗墓小说",
    "author": "朱晓翔著"
  },
  {
    "name": "杨储铭",
    "borrowTime": "2023-10-29",
    "bookName": "摸金传人.5,湘西蛊术",
    "author": "罗晓著"
  },
  {
    "name": "杨储铭",
    "borrowTime": "2023-11-30",
    "bookName": "傲世君少.4",
    "author": "风凌天下著"
  },
  {
    "name": "杨储铭",
    "borrowTime": "2023-12-05",
    "bookName": "天齐大陆",
    "author": "月下泷痕著"
  },
  {
    "name": "杨储铭",
    "borrowTime": "2023-12-09",
    "bookName": "兽血大陆.4",
    "author": "灵隐狐著"
  },
  {
    "name": "杨储铭",
    "borrowTime": "2023-12-09",
    "bookName": "兽血大陆.2",
    "author": "灵隐狐著"
  },
  {
    "name": "杨储铭",
    "borrowTime": "2023-12-09",
    "bookName": "兽血大陆.5",
    "author": "灵隐狐著"
  },
  {
    "name": "杨储铭",
    "borrowTime": "2023-12-09",
    "bookName": "兽血大陆.1",
    "author": "灵隐狐著"
  },
  {
    "name": "杨储铭",
    "borrowTime": "2023-12-09",
    "bookName": "兽血大陆.3",
    "author": "灵隐狐著"
  },
  {
    "name": "杨储铭",
    "borrowTime": "2024-05-07",
    "bookName": "独尊苍穹.1,天才重生",
    "author": "犁天著"
  },
  {
    "name": "杨储铭",
    "borrowTime": "2024-05-14",
    "bookName": "天齐大陆",
    "author": "月下泷痕著"
  },
  {
    "name": "杨凯然",
    "borrowTime": "2023-10-12",
    "bookName": "只想做你的小狐狸",
    "author": "矢厘著"
  },
  {
    "name": "杨卓达",
    "borrowTime": "2023-09-24",
    "bookName": "吞噬星空:典藏版.1",
    "author": "我吃西红柿著"
  },
  {
    "name": "杨境骐",
    "borrowTime": "2023-09-18",
    "bookName": "余罪:我的刑侦笔记.1",
    "author": "常书欣著"
  },
  {
    "name": "杨境骐",
    "borrowTime": "2023-11-16",
    "bookName": "守夜者",
    "author": "法医秦明著"
  },
  {
    "name": "杨境骐",
    "borrowTime": "2024-06-25",
    "bookName": "蔷薇之名.2",
    "author": "紫微流年著"
  },
  {
    "name": "杨奇明",
    "borrowTime": "2023-11-20",
    "bookName": "美国海军陆战队图鉴.上册,两栖作战部队",
    "author": "王强编著"
  },
  {
    "name": "杨宽",
    "borrowTime": "2023-09-19",
    "bookName": "绑架游戏",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "杨宽",
    "borrowTime": "2024-09-21",
    "bookName": "灵能百分百.7",
    "author": "(日)ONE绘著"
  },
  {
    "name": "杨宽",
    "borrowTime": "2024-09-21",
    "bookName": "灵能百分百.5",
    "author": "(日)ONE绘著"
  },
  {
    "name": "杨帅",
    "borrowTime": "2023-09-14",
    "bookName": "新绘聊斋志异插画",
    "author": "朱新昌绘"
  },
  {
    "name": "杨德峰",
    "borrowTime": "2023-10-31",
    "bookName": "世界怪奇实话",
    "author": "(日) 牧逸马著"
  },
  {
    "name": "杨德峰",
    "borrowTime": "2023-10-31",
    "bookName": "梦回大汉",
    "author": "玉清秋著"
  },
  {
    "name": "杨德峰",
    "borrowTime": "2023-10-31",
    "bookName": "摸金校尉之九幽将军",
    "author": "天下霸唱著"
  },
  {
    "name": "杨德峰",
    "borrowTime": "2023-11-17",
    "bookName": "原罪.3,拔云见日",
    "author": "一曲东风著"
  },
  {
    "name": "杨振江",
    "borrowTime": "2024-04-30",
    "bookName": "谋杀似水年华",
    "author": "蔡骏著"
  },
  {
    "name": "杨振江",
    "borrowTime": "2025-03-13",
    "bookName": "百年孤独.第2版",
    "author": "加西亚·马尔克斯著"
  },
  {
    "name": "杨振江",
    "borrowTime": "2025-11-18",
    "bookName": "铁道概论",
    "author": "郭喜春，王国博，孙龙梅主编"
  },
  {
    "name": "杨旭",
    "borrowTime": "2023-11-14",
    "bookName": "民调局异闻录.1,稚国迷窟",
    "author": "耳东水寿著"
  },
  {
    "name": "杨春雨",
    "borrowTime": "2023-11-21",
    "bookName": "死亡解剖台",
    "author": "(美) 斐德列克·萨吉伯著"
  },
  {
    "name": "杨春雨",
    "borrowTime": "2023-11-26",
    "bookName": "修真世界.5,冲出古战场",
    "author": "方想著"
  },
  {
    "name": "杨春雨",
    "borrowTime": "2023-12-01",
    "bookName": "盗墓笔记:十年",
    "author": "南派三叔著"
  },
  {
    "name": "杨智尧",
    "borrowTime": "2023-11-20",
    "bookName": "希腊神话",
    "author": "(俄) 尼·库恩著"
  },
  {
    "name": "杨智尧",
    "borrowTime": "2024-06-27",
    "bookName": "中华人民共和国民法典.大字本",
    "author": "中国法制出版社"
  },
  {
    "name": "杨智程",
    "borrowTime": "2023-11-14",
    "bookName": "连环罪:心理有诡",
    "author": "墨绿青苔著"
  },
  {
    "name": "杨曜菘",
    "borrowTime": "2023-09-10",
    "bookName": "克苏鲁神话合集",
    "author": "(美) 霍华德·菲利普·洛夫克拉夫特著"
  },
  {
    "name": "杨浩然",
    "borrowTime": "2023-10-18",
    "bookName": "魔兽战神.2,十大战王",
    "author": "龙人著"
  },
  {
    "name": "杨浩然",
    "borrowTime": "2023-10-21",
    "bookName": "魔兽战神.5,神之墓地",
    "author": "龙人著"
  },
  {
    "name": "杨浩然",
    "borrowTime": "2023-10-21",
    "bookName": "魔兽战神.4,战皇之路",
    "author": "龙人著"
  },
  {
    "name": "杨浩然",
    "borrowTime": "2023-11-15",
    "bookName": "你好，周先生",
    "author": "夜蔓著"
  },
  {
    "name": "杨涛华",
    "borrowTime": "2025-08-28",
    "bookName": "诡秘之主.1,绯红之月",
    "author": "爱潜水的乌贼著"
  },
  {
    "name": "杨淼",
    "borrowTime": "2023-10-09",
    "bookName": "四世同堂",
    "author": "老舍著"
  },
  {
    "name": "杨淼",
    "borrowTime": "2023-10-18",
    "bookName": "阿Q正传.赵延年插图本",
    "author": "鲁迅著"
  },
  {
    "name": "杨淼",
    "borrowTime": "2023-11-15",
    "bookName": "我是猫",
    "author": "(日) 夏目漱石著"
  },
  {
    "name": "杨淼",
    "borrowTime": "2024-09-02",
    "bookName": "我是猫",
    "author": "(日) 夏目漱石著"
  },
  {
    "name": "杨澎淏",
    "borrowTime": "2023-09-18",
    "bookName": "巴别塔之犬.第4版",
    "author": "(美) 卡罗琳·帕克丝特著"
  },
  {
    "name": "杨澎淏",
    "borrowTime": "2023-09-27",
    "bookName": "罪全书.4",
    "author": "蜘蛛著"
  },
  {
    "name": "杨瀚林",
    "borrowTime": "2023-09-24",
    "bookName": "中国奇异档案记录.第四季",
    "author": "宋歌编著"
  },
  {
    "name": "杨瀚林",
    "borrowTime": "2023-09-24",
    "bookName": "诡案罪.4",
    "author": "岳勇著"
  },
  {
    "name": "杨瀚林",
    "borrowTime": "2024-05-07",
    "bookName": "十宗罪前传",
    "author": "蜘蛛作品"
  },
  {
    "name": "杨瀚林",
    "borrowTime": "2024-05-07",
    "bookName": "罪全书.1",
    "author": "蜘蛛著"
  },
  {
    "name": "杨瀚林",
    "borrowTime": "2024-05-13",
    "bookName": "盗墓笔记,秦岭神树",
    "author": "南派三叔著"
  },
  {
    "name": "杨瀚林",
    "borrowTime": "2024-05-13",
    "bookName": "你看完不敢睡, 看了还想看的悬疑小说.Ⅰ",
    "author": "白虹主编"
  },
  {
    "name": "杨瀚林",
    "borrowTime": "2024-05-13",
    "bookName": "诡案组.2,梦魇神兽.修订版",
    "author": "求无欲著"
  },
  {
    "name": "杨瀚林",
    "borrowTime": "2024-05-13",
    "bookName": "诡案组.2,梦魇神兽.修订版",
    "author": "求无欲著"
  },
  {
    "name": "杨炎鑫",
    "borrowTime": "2023-11-13",
    "bookName": "三侠五义.上册",
    "author": "(清)石玉昆著"
  },
  {
    "name": "杨炎鑫",
    "borrowTime": "2023-11-13",
    "bookName": "三侠五义.下册",
    "author": "(清)石玉昆著"
  },
  {
    "name": "杨烨麒",
    "borrowTime": "2023-09-19",
    "bookName": "双城记",
    "author": "(英)查尔斯·狄更斯著"
  },
  {
    "name": "杨父康",
    "borrowTime": "2023-09-20",
    "bookName": "消失的证人",
    "author": "吕旭著"
  },
  {
    "name": "杨竣涵",
    "borrowTime": "2025-04-17",
    "bookName": "三体",
    "author": "刘慈欣著"
  },
  {
    "name": "杨竣涵",
    "borrowTime": "2025-04-17",
    "bookName": "三体.Ⅱ,黑暗森林",
    "author": "刘慈欣著"
  },
  {
    "name": "杨竣涵",
    "borrowTime": "2025-09-22",
    "bookName": "四世同堂",
    "author": "老舍著"
  },
  {
    "name": "杨茗惜",
    "borrowTime": "2023-11-07",
    "bookName": "世界历史",
    "author": "本册主编李稚勇, 李伟国"
  },
  {
    "name": "杨茗惜",
    "borrowTime": "2023-11-21",
    "bookName": "红飘带狮王",
    "author": "沈石溪著"
  },
  {
    "name": "杨茗惜",
    "borrowTime": "2024-05-16",
    "bookName": "魔龙之书",
    "author": "(澳)乔纳森·斯特拉罕编"
  },
  {
    "name": "杨茗惜",
    "borrowTime": "2024-05-16",
    "bookName": "谁能拒绝一只快乐小狗呢",
    "author": "书单狗著"
  },
  {
    "name": "杨茗惜",
    "borrowTime": "2024-05-20",
    "bookName": "小笑话 大视野:课间笑话",
    "author": "《故事会》编辑部编"
  },
  {
    "name": "杨茗惜",
    "borrowTime": "2024-05-20",
    "bookName": "小笑话 大人生:金色笑话",
    "author": "《故事会》编辑部编"
  },
  {
    "name": "杨茗惜",
    "borrowTime": "2024-05-20",
    "bookName": "小笑话 大自然:动物笑话",
    "author": "《故事会》编辑部编"
  },
  {
    "name": "杨茗惜",
    "borrowTime": "2024-05-28",
    "bookName": "蚁国",
    "author": "罗新学著"
  },
  {
    "name": "杨茗惜",
    "borrowTime": "2024-05-29",
    "bookName": "诡秘之主.1,绯红之月",
    "author": "爱潜水的乌贼著"
  },
  {
    "name": "杨茗惜",
    "borrowTime": "2024-06-11",
    "bookName": "大唐扶龙传.下,不死灵鸟",
    "author": "王健霖著"
  },
  {
    "name": "杨茗惜",
    "borrowTime": "2024-11-19",
    "bookName": "星界的纹章.Ⅲ,回归异乡",
    "author": "(日)森冈浩之著"
  },
  {
    "name": "杨茗惜",
    "borrowTime": "2024-11-19",
    "bookName": "星界的纹章.Ⅱ,微型战争",
    "author": "(日)森冈浩之著"
  },
  {
    "name": "杨阳",
    "borrowTime": "2023-11-14",
    "bookName": "边城.修订版",
    "author": "沈从文著"
  },
  {
    "name": "林佳赫",
    "borrowTime": "2023-10-07",
    "bookName": "龙族.Ⅰ,火之晨曦",
    "author": "江南著"
  },
  {
    "name": "林大军",
    "borrowTime": "2023-09-12",
    "bookName": "天之炽.1.1,红龙的归来",
    "author": "江南作品"
  },
  {
    "name": "林大军",
    "borrowTime": "2024-04-28",
    "bookName": "嫌疑人X的献身.第2版",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "林大军",
    "borrowTime": "2024-04-28",
    "bookName": "龙族.Ⅰ,火之晨曦",
    "author": "江南著"
  },
  {
    "name": "林大军",
    "borrowTime": "2024-04-28",
    "bookName": "龙族.Ⅱ,悼亡者之瞳",
    "author": "江南著"
  },
  {
    "name": "林子峰",
    "borrowTime": "2023-09-26",
    "bookName": "你看完不敢睡, 看了还想看的悬疑小说.Ⅰ",
    "author": "白虹主编"
  },
  {
    "name": "林耀辉",
    "borrowTime": "2024-09-24",
    "bookName": "玉符.上",
    "author": "秦守君著"
  },
  {
    "name": "林耀辉",
    "borrowTime": "2024-09-24",
    "bookName": "无人逝去",
    "author": "(日)白井智之著"
  },
  {
    "name": "林耀辉",
    "borrowTime": "2024-10-11",
    "bookName": "镇魂",
    "author": "Priest著"
  },
  {
    "name": "林诗博",
    "borrowTime": "2023-09-25",
    "bookName": "心理罪,暗河",
    "author": "雷米作品"
  },
  {
    "name": "林诗博",
    "borrowTime": "2024-05-15",
    "bookName": "1945：短篇小说集",
    "author": "(匈)桑托·T. 伽博尔(Szántó T. Gábor)著"
  },
  {
    "name": "林诗博",
    "borrowTime": "2024-06-16",
    "bookName": "克苏鲁神话:无可名状之恐惧",
    "author": "(美)H. P. 洛夫克拉夫特(H. P. Lovecraft)著"
  },
  {
    "name": "林诗博",
    "borrowTime": "2025-09-17",
    "bookName": "怪物同学会",
    "author": "全球华语科幻星云奖组委会编"
  },
  {
    "name": "柳宇航",
    "borrowTime": "2023-10-07",
    "bookName": "伤物语",
    "author": "西尾维新"
  },
  {
    "name": "柳宇航",
    "borrowTime": "2024-05-16",
    "bookName": "伪物语.上",
    "author": "西尾维新"
  },
  {
    "name": "柳宇航",
    "borrowTime": "2024-05-16",
    "bookName": "倾物语",
    "author": "西尾维新"
  },
  {
    "name": "柳宇航",
    "borrowTime": "2024-05-16",
    "bookName": "伪物语.下",
    "author": "西尾维新"
  },
  {
    "name": "柴博严",
    "borrowTime": "2023-10-16",
    "bookName": "法医档案.03,迟来真相.03,Truth comes late",
    "author": "戴西著"
  },
  {
    "name": "柴青武",
    "borrowTime": "2023-10-20",
    "bookName": "活在当下:discover the secret for true happiness",
    "author": "(美) 芭芭拉·安吉丽思著"
  },
  {
    "name": "柴青武",
    "borrowTime": "2023-10-21",
    "bookName": "病隙碎笔:插图版",
    "author": "史铁生著"
  },
  {
    "name": "柴青武",
    "borrowTime": "2024-05-06",
    "bookName": "龙族.Ⅲ,黑月之潮,上.修订版",
    "author": "江南著"
  },
  {
    "name": "柴青武",
    "borrowTime": "2024-05-10",
    "bookName": "猫侦探的名推理",
    "author": "(日)广元著"
  },
  {
    "name": "栾利杰",
    "borrowTime": "2023-09-04",
    "bookName": "边城.修订版",
    "author": "沈从文著"
  },
  {
    "name": "栾彬",
    "borrowTime": "2023-10-17",
    "bookName": "女心理师",
    "author": "拾月著"
  },
  {
    "name": "栾彬",
    "borrowTime": "2023-11-05",
    "bookName": "法医专家",
    "author": "王文杰著"
  },
  {
    "name": "梁伟森",
    "borrowTime": "2025-03-30",
    "bookName": "1分钟漫画回话技巧",
    "author": "张笑恒编著"
  },
  {
    "name": "梁伟森",
    "borrowTime": "2025-10-11",
    "bookName": "犯罪心理学",
    "author": "(奥)汉斯·格罗斯(Hans Gross)著"
  },
  {
    "name": "梁伟森",
    "borrowTime": "2025-10-11",
    "bookName": "乌合之众:大众心理研究",
    "author": "(法) 古斯塔夫·勒庞著"
  },
  {
    "name": "梁伟森",
    "borrowTime": "2026-03-06",
    "bookName": "认知觉醒",
    "author": "李春桃编著"
  },
  {
    "name": "梁铭洋",
    "borrowTime": "2023-09-12",
    "bookName": "轻狂",
    "author": "巫哲著"
  },
  {
    "name": "梅立恒",
    "borrowTime": "2023-10-11",
    "bookName": "长夜难明",
    "author": "紫金陈著"
  },
  {
    "name": "梅立恒",
    "borrowTime": "2024-09-22",
    "bookName": "还原犯罪现场.1,人鱼诅咒",
    "author": "风雨如书著"
  },
  {
    "name": "梅立恒",
    "borrowTime": "2025-03-19",
    "bookName": "习近平谈治国理政",
    "author": "习近平著"
  },
  {
    "name": "楼家良",
    "borrowTime": "2023-09-18",
    "bookName": "斗罗大陆.第四部,终极斗罗.12",
    "author": "唐家三少著"
  },
  {
    "name": "楼家良",
    "borrowTime": "2025-03-19",
    "bookName": "铁路货物运输",
    "author": "冯芬玲[等]主编"
  },
  {
    "name": "楼家良",
    "borrowTime": "2025-03-19",
    "bookName": "铁路货物运输",
    "author": "冯芬玲[等]主编"
  },
  {
    "name": "楼家良",
    "borrowTime": "2025-03-24",
    "bookName": "铁路货物运输",
    "author": "冯芬玲[等]主编"
  },
  {
    "name": "楼家良",
    "borrowTime": "2025-03-24",
    "bookName": "铁路货物运输",
    "author": "冯芬玲[等]主编"
  },
  {
    "name": "楼芷荣",
    "borrowTime": "2023-10-15",
    "bookName": "怒江之战",
    "author": "南派三叔, 乾坤著"
  },
  {
    "name": "欧阳宁超",
    "borrowTime": "2023-10-19",
    "bookName": "南风有归期",
    "author": "子木桑桑著"
  },
  {
    "name": "欧阳郴",
    "borrowTime": "2023-11-03",
    "bookName": "平凡的世界",
    "author": "路遥著"
  },
  {
    "name": "欧阳郴",
    "borrowTime": "2023-11-07",
    "bookName": "白银杰克",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "欧阳郴",
    "borrowTime": "2023-11-07",
    "bookName": "危险的维纳斯",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "欧阳郴",
    "borrowTime": "2024-05-13",
    "bookName": "兄弟.第3版",
    "author": "余华"
  },
  {
    "name": "欧阳郴",
    "borrowTime": "2024-09-02",
    "bookName": "最好的推理小说:超值金版",
    "author": "夜暗黑主编"
  },
  {
    "name": "欧阳郴",
    "borrowTime": "2024-09-12",
    "bookName": "假面饭店",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "欧阳郴",
    "borrowTime": "2024-09-18",
    "bookName": "让我留在你身边",
    "author": "张嘉佳著"
  },
  {
    "name": "欧阳郴",
    "borrowTime": "2024-10-13",
    "bookName": "天堂蒜薹之歌",
    "author": "莫言作品"
  },
  {
    "name": "欧阳郴",
    "borrowTime": "2024-10-24",
    "bookName": "酒国",
    "author": "莫言作品"
  },
  {
    "name": "欧阳郴",
    "borrowTime": "2024-10-30",
    "bookName": "十三步",
    "author": "莫言作品"
  },
  {
    "name": "欧阳郴",
    "borrowTime": "2024-11-19",
    "bookName": "离婚",
    "author": "老舍著"
  },
  {
    "name": "欧阳郴",
    "borrowTime": "2025-06-10",
    "bookName": "檀香刑",
    "author": "莫言作品"
  },
  {
    "name": "武佳润",
    "borrowTime": "2023-09-25",
    "bookName": "特案科:刑警手记.上",
    "author": "风雨如书著"
  },
  {
    "name": "武佳润",
    "borrowTime": "2023-09-25",
    "bookName": "特案科:刑警手记.下",
    "author": "风雨如书著"
  },
  {
    "name": "武佳润",
    "borrowTime": "2023-11-15",
    "bookName": "一百位共产党员的红色家书",
    "author": "张丁编"
  },
  {
    "name": "武歆祺",
    "borrowTime": "2023-09-27",
    "bookName": "诡计设计师:完美罪恶",
    "author": "张嘉骏作品"
  },
  {
    "name": "段安宁",
    "borrowTime": "2023-09-24",
    "bookName": "武则天",
    "author": "赵玫著"
  },
  {
    "name": "段安宁",
    "borrowTime": "2023-10-24",
    "bookName": "白鹿原",
    "author": "陈忠实著"
  },
  {
    "name": "段安宁",
    "borrowTime": "2023-10-30",
    "bookName": "电工技术基础,电工学.Ⅰ.第2版",
    "author": "主编王英"
  },
  {
    "name": "段安宁",
    "borrowTime": "2023-11-16",
    "bookName": "资治通鉴故事精读",
    "author": "芳园主编"
  },
  {
    "name": "段安宁",
    "borrowTime": "2024-05-13",
    "bookName": "明朝那些事儿.增补版",
    "author": "当年明月著"
  },
  {
    "name": "段安宁",
    "borrowTime": "2024-06-23",
    "bookName": "哲学基础入门:有趣的哲学家和哲学思维",
    "author": "杨闯世，隋晶著"
  },
  {
    "name": "段安宁",
    "borrowTime": "2024-06-23",
    "bookName": "哲学的自愈力",
    "author": "(意)玛乌拉·刚齐达诺(Maura Gancitano)，(意)安德莱·科拉美第奇(Andrea Colamedici)著"
  },
  {
    "name": "段安宁",
    "borrowTime": "2024-10-10",
    "bookName": "工程制图与识图.3版",
    "author": "王侠，孙刚主编"
  },
  {
    "name": "段安宁",
    "borrowTime": "2024-10-10",
    "bookName": "工程制图基础教程.3版",
    "author": "薛俊芳，刘海主编"
  },
  {
    "name": "段安宁",
    "borrowTime": "2024-10-24",
    "bookName": "轻松看懂电气控制线路及实物接线图",
    "author": "杜萌，刘振全，王汉芝编著"
  },
  {
    "name": "段安宁",
    "borrowTime": "2024-10-25",
    "bookName": "轻松看懂电气控制线路及实物接线图",
    "author": "杜萌，刘振全，王汉芝编著"
  },
  {
    "name": "段安宁",
    "borrowTime": "2024-11-08",
    "bookName": "西门子S7-200 SMART PLC实例指导学与用",
    "author": "韩相争编著"
  },
  {
    "name": "段安宁",
    "borrowTime": "2025-05-22",
    "bookName": "突围:未知时代的探索与创新",
    "author": "吴晨著"
  },
  {
    "name": "段安宁",
    "borrowTime": "2025-09-22",
    "bookName": "轻松看懂电气控制线路及实物接线图",
    "author": "杜萌，刘振全，王汉芝编著"
  },
  {
    "name": "毕伟",
    "borrowTime": "2023-11-14",
    "bookName": "世界怪奇实话",
    "author": "(日) 牧逸马著"
  },
  {
    "name": "毛博涵",
    "borrowTime": "2023-10-31",
    "bookName": "诡秘之主.1,绯红之月",
    "author": "爱潜水的乌贼著"
  },
  {
    "name": "毛博涵",
    "borrowTime": "2023-11-09",
    "bookName": "李世民全传",
    "author": "林文力著"
  },
  {
    "name": "毛博涵",
    "borrowTime": "2023-11-14",
    "bookName": "长安骊歌",
    "author": "郁馥著"
  },
  {
    "name": "毛博涵",
    "borrowTime": "2023-11-28",
    "bookName": "89号档案馆",
    "author": "孙铭苑著"
  },
  {
    "name": "毛博涵",
    "borrowTime": "2023-12-03",
    "bookName": "九州·无尽长门,傀舞",
    "author": "唐缺著"
  },
  {
    "name": "毛博涵",
    "borrowTime": "2023-12-04",
    "bookName": "尸案调查科.2,重案捕手",
    "author": "九滴水著"
  },
  {
    "name": "毛博涵",
    "borrowTime": "2023-12-13",
    "bookName": "剑来.15,天地无拘束",
    "author": "烽火戏诸侯著"
  },
  {
    "name": "毛博涵",
    "borrowTime": "2023-12-13",
    "bookName": "守夜者.3,生死盲点",
    "author": "法医秦明著"
  },
  {
    "name": "毛博涵",
    "borrowTime": "2024-04-29",
    "bookName": "明朝那些事儿.增补版",
    "author": "当年明月著"
  },
  {
    "name": "毛彦婷",
    "borrowTime": "2023-09-22",
    "bookName": "暗格里的秘密.上",
    "author": "耳东兔子著"
  },
  {
    "name": "毛欣越",
    "borrowTime": "2023-09-14",
    "bookName": "偷偷藏不住.下册",
    "author": "竹已著"
  },
  {
    "name": "江宇翔",
    "borrowTime": "2024-09-25",
    "bookName": "地狱公寓.3",
    "author": "董协著"
  },
  {
    "name": "江宏宇",
    "borrowTime": "2023-09-19",
    "bookName": "嵬城.1,血路",
    "author": "冷露著"
  },
  {
    "name": "江宏宇",
    "borrowTime": "2023-10-06",
    "bookName": "路过风景路过你",
    "author": "沈嘉柯著"
  },
  {
    "name": "江宏宇",
    "borrowTime": "2023-10-21",
    "bookName": "夏日梦想家.中",
    "author": "星河蜉蝣著"
  },
  {
    "name": "江宏宇",
    "borrowTime": "2023-10-21",
    "bookName": "夏日梦想家.下",
    "author": "星河蜉蝣著"
  },
  {
    "name": "江志强",
    "borrowTime": "2023-12-01",
    "bookName": "人间失格",
    "author": "(日) 太宰治著"
  },
  {
    "name": "汤震宇",
    "borrowTime": "2024-09-05",
    "bookName": "酒吧长谈",
    "author": "(秘)马里奥·巴尔加斯·略萨著"
  },
  {
    "name": "汪子健",
    "borrowTime": "2023-10-29",
    "bookName": "亡者永生",
    "author": "那多著"
  },
  {
    "name": "汪子健",
    "borrowTime": "2023-10-29",
    "bookName": "末日解剖",
    "author": "谢宗玉著"
  },
  {
    "name": "汪子健",
    "borrowTime": "2023-11-06",
    "bookName": "怪诞实录",
    "author": "凤仪著"
  },
  {
    "name": "汪子健",
    "borrowTime": "2023-11-06",
    "bookName": "怪诞实录.第二季",
    "author": "凤仪著"
  },
  {
    "name": "汪子健",
    "borrowTime": "2023-12-05",
    "bookName": "牧野诡事",
    "author": "天下霸唱著"
  },
  {
    "name": "沈浩楠",
    "borrowTime": "2023-10-18",
    "bookName": "一本书读完人类二战的历史",
    "author": "崔佳编著"
  },
  {
    "name": "沙伯涵",
    "borrowTime": "2024-01-04",
    "bookName": "1984 动物农场",
    "author": "(英) 乔治·奥威尔著"
  },
  {
    "name": "沙伯涵",
    "borrowTime": "2024-01-04",
    "bookName": "1984 动物农场",
    "author": "(英) 乔治·奥威尔著"
  },
  {
    "name": "沙伯涵",
    "borrowTime": "2024-01-04",
    "bookName": "1984 动物农场",
    "author": "(英) 乔治·奥威尔著"
  },
  {
    "name": "洛桑曲登",
    "borrowTime": "2024-09-08",
    "bookName": "武破苍穹.1",
    "author": "雨辰宇著"
  },
  {
    "name": "洛桑曲登",
    "borrowTime": "2024-09-08",
    "bookName": "过劳死:这份工作比命还重要？",
    "author": "(日)牧内昇平著"
  },
  {
    "name": "洛桑曲登",
    "borrowTime": "2024-09-11",
    "bookName": "武破苍穹.2",
    "author": "雨辰宇著"
  },
  {
    "name": "洛桑曲登",
    "borrowTime": "2024-09-18",
    "bookName": "武破苍穹.3",
    "author": "雨辰宇著"
  },
  {
    "name": "洛桑曲登",
    "borrowTime": "2024-09-23",
    "bookName": "武破苍穹.4",
    "author": "雨辰宇著"
  },
  {
    "name": "洛桑曲登",
    "borrowTime": "2024-09-27",
    "bookName": "武破苍穹.5",
    "author": "雨辰宇著"
  },
  {
    "name": "洛桑曲登",
    "borrowTime": "2024-10-08",
    "bookName": "斗破乾坤.1",
    "author": "食堂包子著"
  },
  {
    "name": "洪鑫",
    "borrowTime": "2024-10-31",
    "bookName": "高速铁路动车组控制系统",
    "author": "李向超主编"
  },
  {
    "name": "洪鑫",
    "borrowTime": "2024-10-31",
    "bookName": "动车组机械装置检修",
    "author": "张明思主编"
  },
  {
    "name": "洪鑫",
    "borrowTime": "2025-08-25",
    "bookName": "人像摄影摆姿零基础入门教程",
    "author": "郑志强著"
  },
  {
    "name": "温得福",
    "borrowTime": "2025-11-24",
    "bookName": "折月亮",
    "author": "竹已著"
  },
  {
    "name": "温得福",
    "borrowTime": "2025-11-24",
    "bookName": "何地雪吹",
    "author": "李丁尧著"
  },
  {
    "name": "温得福",
    "borrowTime": "2025-11-24",
    "bookName": "别恋",
    "author": "陆朝朝著"
  },
  {
    "name": "温敬博",
    "borrowTime": "2023-09-19",
    "bookName": "你不知道的刑侦内幕:一线警察讲段子.1",
    "author": "何斌著"
  },
  {
    "name": "温泳",
    "borrowTime": "2023-11-06",
    "bookName": "疑云记:都市命案奇谈",
    "author": "似水无痕著"
  },
  {
    "name": "潘勃源",
    "borrowTime": "2024-11-28",
    "bookName": "游戏像素图与界面制作教程",
    "author": "房晓溪，姜宁编著"
  },
  {
    "name": "潘勃源",
    "borrowTime": "2024-11-28",
    "bookName": "像素世界:像素画设计专业教程",
    "author": "小猴耳朵编著"
  },
  {
    "name": "潘博",
    "borrowTime": "2023-09-18",
    "bookName": "情商高就是说话办事让人舒服",
    "author": "改编刘刚"
  },
  {
    "name": "潘成烨",
    "borrowTime": "2023-09-21",
    "bookName": "怪诞历史",
    "author": "(英) 乔恩·怀特编著"
  },
  {
    "name": "潘成烨",
    "borrowTime": "2023-10-21",
    "bookName": "怪诞历史",
    "author": "(英) 乔恩·怀特编著"
  },
  {
    "name": "潘成烨",
    "borrowTime": "2023-11-12",
    "bookName": "怪诞历史",
    "author": "(英) 乔恩·怀特编著"
  },
  {
    "name": "潘成烨",
    "borrowTime": "2023-11-26",
    "bookName": "怪诞历史",
    "author": "(英) 乔恩·怀特编著"
  },
  {
    "name": "潘成烨",
    "borrowTime": "2024-05-29",
    "bookName": "犯罪心理档案.第二季",
    "author": "刚雪印作品"
  },
  {
    "name": "潘炳材",
    "borrowTime": "2023-09-23",
    "bookName": "文城:a novel",
    "author": "余华著"
  },
  {
    "name": "潘首铭",
    "borrowTime": "2023-10-17",
    "bookName": "我不是好老师 他们也不是好学生",
    "author": "王刚著"
  },
  {
    "name": "潘首铭",
    "borrowTime": "2023-11-19",
    "bookName": "斗罗大陆.第四部,终极斗罗.16",
    "author": "唐家三少著"
  },
  {
    "name": "焦亚宁",
    "borrowTime": "2024-11-17",
    "bookName": "天道图书馆.2,龙争虎斗",
    "author": "横扫天涯著"
  },
  {
    "name": "牛佳力",
    "borrowTime": "2023-09-25",
    "bookName": "斗罗大陆.第三部,龙王传说.8",
    "author": "唐家三少著"
  },
  {
    "name": "牟百信",
    "borrowTime": "2023-11-08",
    "bookName": "雪中悍刀行.11,逍遥游春秋",
    "author": "烽火戏诸侯著"
  },
  {
    "name": "王一同",
    "borrowTime": "2023-10-08",
    "bookName": "天谴者",
    "author": "法医秦明著"
  },
  {
    "name": "王一同",
    "borrowTime": "2023-11-17",
    "bookName": "御龙:地下国度",
    "author": "天纹诡眼著"
  },
  {
    "name": "王一涵",
    "borrowTime": "2023-09-20",
    "bookName": "十二事务所",
    "author": "钟晓生著"
  },
  {
    "name": "王一涵",
    "borrowTime": "2023-09-20",
    "bookName": "十二事务所",
    "author": "钟晓生著"
  },
  {
    "name": "王世博",
    "borrowTime": "2023-10-11",
    "bookName": "漫无止境!,萌系美少女漫画素描技法",
    "author": "CO米工作室编著"
  },
  {
    "name": "王业辉",
    "borrowTime": "2024-06-17",
    "bookName": "人间失格",
    "author": "(日) 太宰治著"
  },
  {
    "name": "王云皓",
    "borrowTime": "2023-11-21",
    "bookName": "白日梦我",
    "author": "栖见著"
  },
  {
    "name": "王伟豪",
    "borrowTime": "2023-09-20",
    "bookName": "教父前传",
    "author": "(美国) 马里奥·普佐, 埃德·法尔科著"
  },
  {
    "name": "王传宝",
    "borrowTime": "2023-09-20",
    "bookName": "死亡解剖台",
    "author": "(美) 斐德列克·萨吉伯著"
  },
  {
    "name": "王传宝",
    "borrowTime": "2023-09-20",
    "bookName": "诡案组外传",
    "author": "求无欲著"
  },
  {
    "name": "王俊",
    "borrowTime": "2026-05-19",
    "bookName": "西线无战事",
    "author": "(德)雷马克著"
  },
  {
    "name": "王俊",
    "borrowTime": "2026-05-19",
    "bookName": "西线无战事",
    "author": "(德)雷马克著"
  },
  {
    "name": "王健羽",
    "borrowTime": "2025-03-13",
    "bookName": "龙族.Ⅰ,火之晨曦",
    "author": "江南著"
  },
  {
    "name": "王先成",
    "borrowTime": "2023-09-05",
    "bookName": "诡案组.2,梦魇神兽.修订版",
    "author": "求无欲著"
  },
  {
    "name": "王先成",
    "borrowTime": "2023-09-26",
    "bookName": "云之彼端, 约定的地方",
    "author": "(日) 新海诚原作"
  },
  {
    "name": "王凯征",
    "borrowTime": "2023-10-07",
    "bookName": "太阳照常升起",
    "author": "(美) 海明威著"
  },
  {
    "name": "王凯征",
    "borrowTime": "2023-10-23",
    "bookName": "我是猫",
    "author": "(日) 夏目漱石著"
  },
  {
    "name": "王凯征",
    "borrowTime": "2023-10-23",
    "bookName": "挪威的森林",
    "author": "村上春树著"
  },
  {
    "name": "王凯征",
    "borrowTime": "2023-12-06",
    "bookName": "仲夏之死:自选短篇集",
    "author": "译者陈德文"
  },
  {
    "name": "王凯征",
    "borrowTime": "2025-06-30",
    "bookName": "胰脏物语",
    "author": "(日) 住野夜著"
  },
  {
    "name": "王凯征",
    "borrowTime": "2025-09-09",
    "bookName": "化身",
    "author": "渡边淳一作品"
  },
  {
    "name": "王博",
    "borrowTime": "2023-10-07",
    "bookName": "世界经典神话故事.全彩珍藏版",
    "author": "余祖政等编著"
  },
  {
    "name": "王博",
    "borrowTime": "2023-10-17",
    "bookName": "黄金瞳.1.1",
    "author": "打眼著"
  },
  {
    "name": "王博",
    "borrowTime": "2023-10-21",
    "bookName": "黄金瞳.2.2",
    "author": "打眼著"
  },
  {
    "name": "王博",
    "borrowTime": "2023-11-07",
    "bookName": "黄金瞳.6.6",
    "author": "打眼著"
  },
  {
    "name": "王博",
    "borrowTime": "2025-05-26",
    "bookName": "欢迎来到实力至上主义的教室.4",
    "author": "(日) 衣笠彰梧著"
  },
  {
    "name": "王博",
    "borrowTime": "2025-05-26",
    "bookName": "人间失格",
    "author": "(日) 太宰治著"
  },
  {
    "name": "王嘉宁",
    "borrowTime": "2024-06-04",
    "bookName": "第十一根手指",
    "author": "秦明著"
  },
  {
    "name": "王天洋",
    "borrowTime": "2023-10-19",
    "bookName": "你看完不敢睡, 看了还想看的悬疑小说.Ⅰ",
    "author": "白虹主编"
  },
  {
    "name": "王天洋",
    "borrowTime": "2023-10-19",
    "bookName": "诡案组.2.Season two.第2季",
    "author": "求无欲著"
  },
  {
    "name": "王天洋",
    "borrowTime": "2023-10-19",
    "bookName": "原罪.3,拔云见日",
    "author": "一曲东风著"
  },
  {
    "name": "王天洋",
    "borrowTime": "2023-10-19",
    "bookName": "幸存者",
    "author": "法医秦明著"
  },
  {
    "name": "王奕贺",
    "borrowTime": "2023-12-04",
    "bookName": "十宗罪.5",
    "author": "蜘蛛著"
  },
  {
    "name": "王嫡",
    "borrowTime": "2025-03-14",
    "bookName": "文学回忆录:1989-1944.下",
    "author": "木心讲述"
  },
  {
    "name": "王子萌",
    "borrowTime": "2023-11-18",
    "bookName": "活着",
    "author": "余华著"
  },
  {
    "name": "王子豪",
    "borrowTime": "2023-09-21",
    "bookName": "平凡的世界",
    "author": "路遥著"
  },
  {
    "name": "王子豪",
    "borrowTime": "2023-10-17",
    "bookName": "赘婿.1,江宁晨风",
    "author": "愤怒的香蕉著"
  },
  {
    "name": "王学政",
    "borrowTime": "2023-11-14",
    "bookName": "龙族.Ⅳ,奥丁之渊",
    "author": "江南著"
  },
  {
    "name": "王学政",
    "borrowTime": "2023-11-21",
    "bookName": "撒野",
    "author": "巫哲著"
  },
  {
    "name": "王学雷",
    "borrowTime": "2023-11-02",
    "bookName": "异域奇谈,日本卷",
    "author": "桐木著"
  },
  {
    "name": "王宁",
    "borrowTime": "2024-09-12",
    "bookName": "漫画素描技法从入门到精通,头部与身体",
    "author": "C·C动漫社著"
  },
  {
    "name": "王宇杰",
    "borrowTime": "2024-12-11",
    "bookName": "铁路货物运输",
    "author": "中国国家铁路集团有限公司货运部主编"
  },
  {
    "name": "王宇杰",
    "borrowTime": "2024-12-11",
    "bookName": "铁路货物运输",
    "author": "冯芬玲[等]主编"
  },
  {
    "name": "王宇鹏",
    "borrowTime": "2023-11-06",
    "bookName": "你当像鸟飞往你的山",
    "author": "(美) 塔拉·韦斯特弗著"
  },
  {
    "name": "王宇鹏",
    "borrowTime": "2024-11-18",
    "bookName": "地狱变",
    "author": "(日)芥川龙之介著"
  },
  {
    "name": "王守欢",
    "borrowTime": "2023-09-19",
    "bookName": "炼妖师",
    "author": "柳三笑著"
  },
  {
    "name": "王守欢",
    "borrowTime": "2023-10-06",
    "bookName": "霓裳",
    "author": "清歌一片著"
  },
  {
    "name": "王守欢",
    "borrowTime": "2023-10-10",
    "bookName": "悲鸣之剑",
    "author": "刘靖宇著"
  },
  {
    "name": "王守欢",
    "borrowTime": "2023-10-30",
    "bookName": "保卫孙子",
    "author": "吕宏强, 吕帆著"
  },
  {
    "name": "王守欢",
    "borrowTime": "2023-11-19",
    "bookName": "铸剑江湖.下",
    "author": "龙人著"
  },
  {
    "name": "王守欢",
    "borrowTime": "2023-11-27",
    "bookName": "元气时光师",
    "author": "喵哆哆著"
  },
  {
    "name": "王守欢",
    "borrowTime": "2023-11-27",
    "bookName": "异域奇谈,日本卷",
    "author": "桐木著"
  },
  {
    "name": "王守欢",
    "borrowTime": "2023-12-03",
    "bookName": "摸金传人.5,湘西蛊术",
    "author": "罗晓著"
  },
  {
    "name": "王守欢",
    "borrowTime": "2023-12-04",
    "bookName": "天齐大陆",
    "author": "月下泷痕著"
  },
  {
    "name": "王守欢",
    "borrowTime": "2023-12-10",
    "bookName": "古玩笔记,悬疑篇:老年间古玩收藏的禁忌故事",
    "author": "齐州三爷著"
  },
  {
    "name": "王守欢",
    "borrowTime": "2023-12-17",
    "bookName": "摸金玦之鬼门天师",
    "author": "天下霸唱[著]"
  },
  {
    "name": "王宝涵",
    "borrowTime": "2023-10-09",
    "bookName": "细品最美唐诗",
    "author": "西园著"
  },
  {
    "name": "王宝涵",
    "borrowTime": "2023-10-09",
    "bookName": "枕上诗书,遇见最美唐诗",
    "author": "方慧颖著"
  },
  {
    "name": "王宝涵",
    "borrowTime": "2025-04-23",
    "bookName": "电力机车控制",
    "author": "张耀武主编"
  },
  {
    "name": "王富嘉",
    "borrowTime": "2023-11-16",
    "bookName": "89号档案馆",
    "author": "孙铭苑著"
  },
  {
    "name": "王小希",
    "borrowTime": "2023-11-20",
    "bookName": "撒野",
    "author": "巫哲著"
  },
  {
    "name": "王小希",
    "borrowTime": "2023-12-12",
    "bookName": "盗墓笔记:十年",
    "author": "南派三叔著"
  },
  {
    "name": "王小希",
    "borrowTime": "2023-12-12",
    "bookName": "尸案调查科.2,重案捕手",
    "author": "九滴水著"
  },
  {
    "name": "王小希",
    "borrowTime": "2023-12-17",
    "bookName": "尸案调查科.第二季.2,一念深渊",
    "author": "九滴水著"
  },
  {
    "name": "王建乔",
    "borrowTime": "2023-09-20",
    "bookName": "尸案调查科.第二季.2,一念深渊",
    "author": "九滴水著"
  },
  {
    "name": "王彦宇",
    "borrowTime": "2023-10-08",
    "bookName": "薄荷之夏.第2季.1.1",
    "author": "火禾编绘"
  },
  {
    "name": "王彦宇",
    "borrowTime": "2023-10-08",
    "bookName": "薄荷之夏.第2季.1.1",
    "author": "火禾编绘"
  },
  {
    "name": "王思彤",
    "borrowTime": "2023-09-18",
    "bookName": "两不疑.2",
    "author": "绿野千鹤脚本"
  },
  {
    "name": "王思彤",
    "borrowTime": "2023-09-18",
    "bookName": "两不疑.1",
    "author": "绿野千鹤脚本"
  },
  {
    "name": "王思彤",
    "borrowTime": "2023-09-27",
    "bookName": "赘婿.2,心如猛虎",
    "author": "愤怒的香蕉著"
  },
  {
    "name": "王思彤",
    "borrowTime": "2023-11-27",
    "bookName": "绝代双骄.四",
    "author": "古龙,"
  },
  {
    "name": "王恩粸",
    "borrowTime": "2023-11-05",
    "bookName": "因果定律",
    "author": "墨非编著"
  },
  {
    "name": "王新凯",
    "borrowTime": "2023-11-30",
    "bookName": "亡者永生",
    "author": "那多著"
  },
  {
    "name": "王新凯",
    "borrowTime": "2024-11-12",
    "bookName": "怪咖奇异事件簿,游戏匿踪",
    "author": "蔡必贵著"
  },
  {
    "name": "王新凯",
    "borrowTime": "2024-11-12",
    "bookName": "怪咖奇异事件簿,游戏匿踪",
    "author": "蔡必贵著"
  },
  {
    "name": "王新凯",
    "borrowTime": "2024-11-14",
    "bookName": "王者时刻.1",
    "author": "蝴蝶蓝著"
  },
  {
    "name": "王新凯",
    "borrowTime": "2024-11-17",
    "bookName": "惊奇物语.3",
    "author": "王雨辰, 周浩晖等著"
  },
  {
    "name": "王新凯",
    "borrowTime": "2024-11-18",
    "bookName": "尸语者.下",
    "author": "法医秦明著"
  },
  {
    "name": "王昊",
    "borrowTime": "2023-12-02",
    "bookName": "Python基础教程",
    "author": "刘浪主编"
  },
  {
    "name": "王昊驰",
    "borrowTime": "2023-09-20",
    "bookName": "刑警手记,虚拟谋杀",
    "author": "野兵著"
  },
  {
    "name": "王星锐",
    "borrowTime": "2023-09-18",
    "bookName": "89号档案馆",
    "author": "孙铭苑著"
  },
  {
    "name": "王星锐",
    "borrowTime": "2023-10-11",
    "bookName": "哈利·波特与魔法石",
    "author": "(英) J.K.罗琳著"
  },
  {
    "name": "王星锐",
    "borrowTime": "2023-11-14",
    "bookName": "哈利·波特与火焰杯",
    "author": "(英) J.K.罗琳著"
  },
  {
    "name": "王星锐",
    "borrowTime": "2023-12-18",
    "bookName": "哈利·波特与火焰杯",
    "author": "(英) J.K.罗琳著"
  },
  {
    "name": "王星锐",
    "borrowTime": "2024-05-06",
    "bookName": "哈利·波特与火焰杯",
    "author": "(英) J.K.罗琳著"
  },
  {
    "name": "王星锐",
    "borrowTime": "2024-05-06",
    "bookName": "哈利·波特与凤凰社",
    "author": "(英) J.K.罗琳著"
  },
  {
    "name": "王星锐",
    "borrowTime": "2024-05-10",
    "bookName": "克苏鲁神话.I,克苏鲁的呼唤",
    "author": "(美)H.P. 洛夫克拉夫特(H.P. Lovecraft)著"
  },
  {
    "name": "王星锐",
    "borrowTime": "2024-05-10",
    "bookName": "克苏鲁神话.II,黑暗中的低语",
    "author": "(美)H.P. 洛夫克拉夫特(H.P. Lovecraft)著"
  },
  {
    "name": "王星锐",
    "borrowTime": "2024-05-24",
    "bookName": "哈利·波特与凤凰社",
    "author": "(英) J.K.罗琳著"
  },
  {
    "name": "王星锐",
    "borrowTime": "2024-06-16",
    "bookName": "哈利·波特与凤凰社",
    "author": "(英) J.K.罗琳著"
  },
  {
    "name": "王春伍",
    "borrowTime": "2023-09-12",
    "bookName": "这个店有古怪",
    "author": "明月听风著"
  },
  {
    "name": "王春伍",
    "borrowTime": "2023-09-12",
    "bookName": "吞噬星空:典藏版.1",
    "author": "我吃西红柿著"
  },
  {
    "name": "王昭淇",
    "borrowTime": "2023-09-19",
    "bookName": "罪全书.6",
    "author": "蜘蛛著"
  },
  {
    "name": "王昭淇",
    "borrowTime": "2023-10-31",
    "bookName": "夜行实录.1.1",
    "author": "徐浪著"
  },
  {
    "name": "王晟东",
    "borrowTime": "2023-09-14",
    "bookName": "斗破乾坤.1",
    "author": "食堂包子著"
  },
  {
    "name": "王晟东",
    "borrowTime": "2023-09-14",
    "bookName": "斗破乾坤.1",
    "author": "食堂包子著"
  },
  {
    "name": "王林源",
    "borrowTime": "2023-10-19",
    "bookName": "明朝那些事儿.第陆部,帝国，山雨欲来",
    "author": "当年明月著"
  },
  {
    "name": "王楚为",
    "borrowTime": "2025-06-13",
    "bookName": "习近平谈治国理政.第四卷",
    "author": "习近平"
  },
  {
    "name": "王永旭",
    "borrowTime": "2024-09-11",
    "bookName": "牧野诡事",
    "author": "天下霸唱著"
  },
  {
    "name": "王永旭",
    "borrowTime": "2024-09-18",
    "bookName": "南宋异闻录",
    "author": "月关著"
  },
  {
    "name": "王永旭",
    "borrowTime": "2024-09-25",
    "bookName": "南宋异闻录",
    "author": "月关著"
  },
  {
    "name": "王永旭",
    "borrowTime": "2024-09-25",
    "bookName": "南宋异闻录",
    "author": "月关著"
  },
  {
    "name": "王治远",
    "borrowTime": "2023-09-18",
    "bookName": "天才在左 疯子在右:完整版",
    "author": "高铭著"
  },
  {
    "name": "王泓博",
    "borrowTime": "2023-09-04",
    "bookName": "三体.Ⅲ,死神永生.Ⅲ,Dead end",
    "author": "刘慈欣著"
  },
  {
    "name": "王泽",
    "borrowTime": "2023-09-19",
    "bookName": "满世界找诡:散客月下四海奇谭",
    "author": "散客月下著"
  },
  {
    "name": "王泽",
    "borrowTime": "2023-09-19",
    "bookName": "满世界找诡:散客月下四海奇谭",
    "author": "散客月下著"
  },
  {
    "name": "王泽",
    "borrowTime": "2023-09-19",
    "bookName": "灵魂追凶",
    "author": "向林著"
  },
  {
    "name": "王泽城",
    "borrowTime": "2023-10-10",
    "bookName": "你看完不敢睡, 看了还想看的悬疑小说.Ⅰ",
    "author": "白虹主编"
  },
  {
    "name": "王洋",
    "borrowTime": "2023-09-18",
    "bookName": "法医专家",
    "author": "王文杰著"
  },
  {
    "name": "王洋",
    "borrowTime": "2023-10-21",
    "bookName": "撒野",
    "author": "巫哲著"
  },
  {
    "name": "王洋",
    "borrowTime": "2023-11-01",
    "bookName": "偷偷藏不住.上册",
    "author": "竹已著"
  },
  {
    "name": "王洋",
    "borrowTime": "2023-11-12",
    "bookName": "斗罗大陆.第四部,终极斗罗.12",
    "author": "唐家三少著"
  },
  {
    "name": "王洪莹",
    "borrowTime": "2023-11-12",
    "bookName": "民调局异闻录.1,稚国迷窟",
    "author": "耳东水寿著"
  },
  {
    "name": "王浚源",
    "borrowTime": "2023-11-20",
    "bookName": "新诡案组",
    "author": "求无尘著"
  },
  {
    "name": "王浩宇",
    "borrowTime": "2023-09-25",
    "bookName": "天堂旅行团",
    "author": "张嘉佳著"
  },
  {
    "name": "王浩宇",
    "borrowTime": "2025-03-07",
    "bookName": "终钥战纪",
    "author": "灰狐著"
  },
  {
    "name": "王浩宇",
    "borrowTime": "2025-03-07",
    "bookName": "终钥战纪",
    "author": "灰狐著"
  },
  {
    "name": "王海阳",
    "borrowTime": "2023-11-14",
    "bookName": "大谋小计五十年:诸葛亮传",
    "author": "若虚著"
  },
  {
    "name": "王海阳",
    "borrowTime": "2024-06-11",
    "bookName": "死在火星上.上",
    "author": "天瑞说符著"
  },
  {
    "name": "王海阳",
    "borrowTime": "2024-09-02",
    "bookName": "沙丘序曲.Ⅰ,House Atreides,厄崔迪家族",
    "author": "布莱恩·赫伯特，凯文·J. 安德森著"
  },
  {
    "name": "王海阳",
    "borrowTime": "2024-10-08",
    "bookName": "沙丘序曲.Ⅰ,House Atreides,厄崔迪家族",
    "author": "布莱恩·赫伯特，凯文·J. 安德森著"
  },
  {
    "name": "王海鸿",
    "borrowTime": "2023-09-21",
    "bookName": "盗墓玄机:长篇盗墓小说",
    "author": "朱晓翔著"
  },
  {
    "name": "王涵",
    "borrowTime": "2023-10-21",
    "bookName": "魔兽战神.6,众生战场",
    "author": "龙人著"
  },
  {
    "name": "王涵",
    "borrowTime": "2023-11-15",
    "bookName": "余生有你才安好.修订本",
    "author": "叶非夜作品"
  },
  {
    "name": "王涵",
    "borrowTime": "2023-11-15",
    "bookName": "魔兽战神.7,神兽麒麟",
    "author": "龙人著"
  },
  {
    "name": "王涵",
    "borrowTime": "2023-11-15",
    "bookName": "魔兽战神.8,浑天魔神",
    "author": "龙人著"
  },
  {
    "name": "王瀚",
    "borrowTime": "2023-11-28",
    "bookName": "明朝那些事儿.第1部,朱元璋: 从和尚到皇帝.图文精印版",
    "author": "当年明月著"
  },
  {
    "name": "王瀚",
    "borrowTime": "2023-12-08",
    "bookName": "明朝那些事儿.增补版",
    "author": "当年明月著"
  },
  {
    "name": "王炳坤",
    "borrowTime": "2023-09-04",
    "bookName": "杀死一只知更鸟",
    "author": "(美) 哈珀·李著"
  },
  {
    "name": "王炳坤",
    "borrowTime": "2024-06-30",
    "bookName": "1分钟大脑整理法",
    "author": "(日)铃木进介著"
  },
  {
    "name": "王烁涵",
    "borrowTime": "2023-09-18",
    "bookName": "蛙",
    "author": "莫言著"
  },
  {
    "name": "王烁涵",
    "borrowTime": "2023-10-09",
    "bookName": "明朝那些事儿.增补版",
    "author": "当年明月著"
  },
  {
    "name": "王烁涵",
    "borrowTime": "2023-10-09",
    "bookName": "明朝那些事儿.第1部,朱元璋: 从和尚到皇帝.图文精印版",
    "author": "当年明月著"
  },
  {
    "name": "王烁涵",
    "borrowTime": "2023-10-18",
    "bookName": "明朝那些事儿.增补版",
    "author": "当年明月著"
  },
  {
    "name": "王烁涵",
    "borrowTime": "2023-11-22",
    "bookName": "局外人:记忆坊版",
    "author": "(法)阿尔贝·加缪著"
  },
  {
    "name": "王烁涵",
    "borrowTime": "2023-11-22",
    "bookName": "羊脂球:莫泊桑短篇小说选",
    "author": "(法)莫泊桑著"
  },
  {
    "name": "王烁涵",
    "borrowTime": "2024-05-14",
    "bookName": "白银杰克",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "王烁涵",
    "borrowTime": "2024-09-03",
    "bookName": "两晋其实很有趣",
    "author": "子陌著"
  },
  {
    "name": "王烁涵",
    "borrowTime": "2024-09-17",
    "bookName": "武破苍穹.2",
    "author": "雨辰宇著"
  },
  {
    "name": "王烁涵",
    "borrowTime": "2024-09-18",
    "bookName": "尘封的历史:大明王朝二十二块碎片的另一面",
    "author": "李元骏著"
  },
  {
    "name": "王焕",
    "borrowTime": "2023-09-04",
    "bookName": "罪全书.4",
    "author": "蜘蛛著"
  },
  {
    "name": "王熙",
    "borrowTime": "2025-03-26",
    "bookName": "25T型客车电气装置",
    "author": "《25T型客车电气装置》编委会编"
  },
  {
    "name": "王燚",
    "borrowTime": "2024-10-17",
    "bookName": "视唱练耳教学与审美艺术",
    "author": "赵楠著"
  },
  {
    "name": "王燚",
    "borrowTime": "2024-10-17",
    "bookName": "视唱练耳与基本乐理融合教学之探索",
    "author": "王莉敏著"
  },
  {
    "name": "王燚",
    "borrowTime": "2024-10-17",
    "bookName": "思维导图巧学乐理",
    "author": "文武贝编著"
  },
  {
    "name": "王燚",
    "borrowTime": "2024-10-17",
    "bookName": "乐理 视唱 练耳",
    "author": "李志清主编"
  },
  {
    "name": "王燚",
    "borrowTime": "2024-10-17",
    "bookName": "轻松学吉他",
    "author": "韩先富编著"
  },
  {
    "name": "王玉冲",
    "borrowTime": "2023-11-01",
    "bookName": "我等你，很久了",
    "author": "咬春饼著"
  },
  {
    "name": "王琼悦",
    "borrowTime": "2023-11-06",
    "bookName": "喂你一颗糖",
    "author": "西方经济学著"
  },
  {
    "name": "王瑞",
    "borrowTime": "2023-11-16",
    "bookName": "极简摄影",
    "author": "先锋影像编著"
  },
  {
    "name": "王皓",
    "borrowTime": "2023-09-25",
    "bookName": "血刃",
    "author": "尚武著"
  },
  {
    "name": "王皓",
    "borrowTime": "2023-10-11",
    "bookName": "重返地球:后纪元时代",
    "author": "朱琨著"
  },
  {
    "name": "王皓",
    "borrowTime": "2024-05-14",
    "bookName": "失落灵魂之城",
    "author": "(美)卡桑德拉·克莱尔(Cassandra Clare)著"
  },
  {
    "name": "王皓",
    "borrowTime": "2024-05-14",
    "bookName": "绑嫁",
    "author": "三盅著"
  },
  {
    "name": "王相博",
    "borrowTime": "2023-11-29",
    "bookName": "克苏鲁神话合集",
    "author": "(美) 霍华德·菲利普·洛夫克拉夫特著"
  },
  {
    "name": "王相博",
    "borrowTime": "2023-12-11",
    "bookName": "黄金瞳.1.1",
    "author": "打眼著"
  },
  {
    "name": "王福伟",
    "borrowTime": "2023-09-14",
    "bookName": "网游之江湖任务行",
    "author": "蝴蝶蓝著"
  },
  {
    "name": "王章耀",
    "borrowTime": "2023-11-23",
    "bookName": "五道口贴吧故事",
    "author": "贺奕著"
  },
  {
    "name": "王章耀",
    "borrowTime": "2024-09-09",
    "bookName": "白夜追凶",
    "author": "剧本原著指纹"
  },
  {
    "name": "王章耀",
    "borrowTime": "2024-11-11",
    "bookName": "克苏鲁神话合集",
    "author": "(美) 霍华德·菲利普·洛夫克拉夫特著"
  },
  {
    "name": "王童",
    "borrowTime": "2023-09-24",
    "bookName": "福尔摩斯探案集全集:被称为侦探小说的“圣经”",
    "author": "(英) 柯南·道尔著"
  },
  {
    "name": "王童",
    "borrowTime": "2024-05-15",
    "bookName": "富爸爸投资指南",
    "author": "(美) 罗伯特·清崎, 莎伦·莱希特著"
  },
  {
    "name": "王童",
    "borrowTime": "2024-05-19",
    "bookName": "富爸爸投资指南",
    "author": "(美) 罗伯特·清崎, 莎伦·莱希特著"
  },
  {
    "name": "王罗玉富",
    "borrowTime": "2023-09-20",
    "bookName": "谋杀狄更斯.上",
    "author": "(美) 丹·西蒙斯著"
  },
  {
    "name": "王罗玉富",
    "borrowTime": "2023-11-16",
    "bookName": "守夜者.4,天演:大结局",
    "author": "法医秦明著"
  },
  {
    "name": "王翊沣",
    "borrowTime": "2023-10-21",
    "bookName": "心理罪,暗河",
    "author": "雷米作品"
  },
  {
    "name": "王翊沣",
    "borrowTime": "2023-10-21",
    "bookName": "金吾卫之风起金陵",
    "author": "柳三笑著"
  },
  {
    "name": "王翊沣",
    "borrowTime": "2023-11-18",
    "bookName": "民调局异闻录.2,麒麟地宫",
    "author": "耳东水寿著"
  },
  {
    "name": "王诗博",
    "borrowTime": "2024-06-12",
    "bookName": "女法医手记之破译密码",
    "author": "刘真著"
  },
  {
    "name": "王诗博",
    "borrowTime": "2024-09-02",
    "bookName": "十宗罪.5",
    "author": "蜘蛛著"
  },
  {
    "name": "王诗博",
    "borrowTime": "2024-09-02",
    "bookName": "超禁忌秘密.2.2",
    "author": "宁航一著"
  },
  {
    "name": "王诗博",
    "borrowTime": "2024-09-18",
    "bookName": "犯罪心理档案.第四季",
    "author": "刚雪印著"
  },
  {
    "name": "王责宇",
    "borrowTime": "2023-11-03",
    "bookName": "上知天文, 下知你心",
    "author": "谢潸然著"
  },
  {
    "name": "王超",
    "borrowTime": "2024-05-14",
    "bookName": "克苏鲁神话合集",
    "author": "(美) 霍华德·菲利普·洛夫克拉夫特著"
  },
  {
    "name": "王迪",
    "borrowTime": "2023-10-23",
    "bookName": "黄金瞳.8.8",
    "author": "打眼著"
  },
  {
    "name": "王野",
    "borrowTime": "2023-09-24",
    "bookName": "法医专家.2,[昆虫证词]",
    "author": "王文杰著"
  },
  {
    "name": "王野",
    "borrowTime": "2024-10-31",
    "bookName": "三星堆秘密",
    "author": "科影发现编"
  },
  {
    "name": "王野",
    "borrowTime": "2025-03-05",
    "bookName": "极速车魂",
    "author": "重野秀一著"
  },
  {
    "name": "王野",
    "borrowTime": "2025-03-05",
    "bookName": "我破碎的真理子",
    "author": "(日)平库和歌著"
  },
  {
    "name": "王野",
    "borrowTime": "2025-03-06",
    "bookName": "漫画讲透大学中庸",
    "author": "小读客阅读研究社著"
  },
  {
    "name": "王野",
    "borrowTime": "2025-06-10",
    "bookName": "十宗罪.5",
    "author": "蜘蛛著"
  },
  {
    "name": "王野",
    "borrowTime": "2025-06-10",
    "bookName": "镇魂",
    "author": "Priest著"
  },
  {
    "name": "王野",
    "borrowTime": "2025-06-10",
    "bookName": "镇魂:大结局",
    "author": "Priest著"
  },
  {
    "name": "王金博",
    "borrowTime": "2023-09-20",
    "bookName": "喜欢你这件小事",
    "author": "沈熊猫著"
  },
  {
    "name": "王金成",
    "borrowTime": "2023-11-01",
    "bookName": "唐朝的春风大雅",
    "author": "栗子著"
  },
  {
    "name": "王铂淞",
    "borrowTime": "2023-09-26",
    "bookName": "中国怪谈",
    "author": "赵志明著"
  },
  {
    "name": "王铂淞",
    "borrowTime": "2023-11-15",
    "bookName": "偷偷藏不住.上册",
    "author": "竹已著"
  },
  {
    "name": "王阔",
    "borrowTime": "2023-11-16",
    "bookName": "在索河的两次爱恋",
    "author": "谢大立"
  },
  {
    "name": "王雨晗",
    "borrowTime": "2023-11-12",
    "bookName": "绝命追杀:意大利黑手党家族",
    "author": "詹幼鹏著"
  },
  {
    "name": "王雨晗",
    "borrowTime": "2023-11-14",
    "bookName": "盗墓笔记:十年",
    "author": "南派三叔著"
  },
  {
    "name": "王雨晗",
    "borrowTime": "2024-04-29",
    "bookName": "西游记",
    "author": "(明) 吴承恩著"
  },
  {
    "name": "王霄",
    "borrowTime": "2023-11-19",
    "bookName": "克苏鲁神话合集",
    "author": "(美) 霍华德·菲利普·洛夫克拉夫特著"
  },
  {
    "name": "王靖博",
    "borrowTime": "2023-10-12",
    "bookName": "积案调查组",
    "author": "狐狸猫著"
  },
  {
    "name": "王靖博",
    "borrowTime": "2023-10-23",
    "bookName": "怒江之战",
    "author": "南派三叔, 乾坤著"
  },
  {
    "name": "王靖博",
    "borrowTime": "2023-11-14",
    "bookName": "绝代双骄.三",
    "author": "古龙,"
  },
  {
    "name": "王韬宇",
    "borrowTime": "2023-09-18",
    "bookName": "白夜追凶",
    "author": "剧本原著指纹"
  },
  {
    "name": "王韬宇",
    "borrowTime": "2023-10-10",
    "bookName": "宿命.第2版",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "王韬宇",
    "borrowTime": "2023-10-10",
    "bookName": "金田一探案集.02,本阵杀人事件",
    "author": "(日)横沟正史著"
  },
  {
    "name": "王韬宇",
    "borrowTime": "2023-10-10",
    "bookName": "没有凶手的暗夜",
    "author": "(日)东野圭吾著"
  },
  {
    "name": "王韬宇",
    "borrowTime": "2023-11-01",
    "bookName": "黄金瞳.1.1",
    "author": "打眼著"
  },
  {
    "name": "王颖",
    "borrowTime": "2023-10-10",
    "bookName": "病隙碎笔:插图版",
    "author": "史铁生著"
  },
  {
    "name": "王鹏旭",
    "borrowTime": "2023-10-07",
    "bookName": "人间游戏:伤痕",
    "author": "钟宇著"
  },
  {
    "name": "王鹏翔",
    "borrowTime": "2023-09-26",
    "bookName": "偷窥者:死亡不是结束而是另一种开始",
    "author": "秦明著"
  },
  {
    "name": "田博",
    "borrowTime": "2023-11-19",
    "bookName": "沧元图.1",
    "author": "我吃西红柿著"
  },
  {
    "name": "田家旭",
    "borrowTime": "2025-06-16",
    "bookName": "电力机车控制:M+Book版",
    "author": "李联福，于彦良，李辰佑主编"
  },
  {
    "name": "田家旭",
    "borrowTime": "2025-08-25",
    "bookName": "铁路机务系统事故救援",
    "author": "程威主编"
  },
  {
    "name": "田家旭",
    "borrowTime": "2025-08-25",
    "bookName": "内燃机车传动与控制",
    "author": "何林军，白雪主编"
  },
  {
    "name": "田永强",
    "borrowTime": "2023-10-11",
    "bookName": "诡计设计师:完美罪恶",
    "author": "张嘉骏作品"
  },
  {
    "name": "田海蛟",
    "borrowTime": "2023-10-23",
    "bookName": "神医帝妃.第1部.第一卷,同是天涯沦落人",
    "author": "阿彩著"
  },
  {
    "name": "由添宇",
    "borrowTime": "2023-09-19",
    "bookName": "尽管到最后, 你还是成为你自己:与大卫·福斯特·华莱士的公路之旅:a road trip with David Foster wallace",
    "author": "(美) 大卫·利普斯基著"
  },
  {
    "name": "白佳奇",
    "borrowTime": "2023-09-19",
    "bookName": "黄金瞳.1.1",
    "author": "打眼著"
  },
  {
    "name": "白佳奇",
    "borrowTime": "2023-09-19",
    "bookName": "赘婿.1,江宁晨风",
    "author": "愤怒的香蕉著"
  },
  {
    "name": "白松雳",
    "borrowTime": "2024-12-07",
    "bookName": "人像摄影摆姿零基础入门教程",
    "author": "郑志强著"
  },
  {
    "name": "白松雳",
    "borrowTime": "2024-12-07",
    "bookName": "摄影水平跨越性提升的320个致胜技巧",
    "author": "视觉中国500px摄影社区爱摄会iPhoto部落编著"
  },
  {
    "name": "白炳全",
    "borrowTime": "2023-12-14",
    "bookName": "天之炽.1.1,红龙的归来",
    "author": "江南作品"
  },
  {
    "name": "白煜",
    "borrowTime": "2023-11-20",
    "bookName": "十宗罪.5",
    "author": "蜘蛛著"
  },
  {
    "name": "白雁鹏",
    "borrowTime": "2023-10-23",
    "bookName": "反盗墓九组:明王密藏",
    "author": "赖继著"
  },
  {
    "name": "盖阔",
    "borrowTime": "2023-10-21",
    "bookName": "怪诞实录",
    "author": "凤仪著"
  },
  {
    "name": "盖阔",
    "borrowTime": "2023-11-07",
    "bookName": "必须犯规的游戏:大结局",
    "author": "宁航一著"
  },
  {
    "name": "石江博",
    "borrowTime": "2023-10-07",
    "bookName": "世界经典悬疑故事",
    "author": "白虹主编"
  },
  {
    "name": "石浡",
    "borrowTime": "2023-10-08",
    "bookName": "魔兽战神.2,十大战王",
    "author": "龙人著"
  },
  {
    "name": "石浡",
    "borrowTime": "2023-10-08",
    "bookName": "魔兽战神,鲲鹏战场",
    "author": "龙人著"
  },
  {
    "name": "石燚浩",
    "borrowTime": "2023-10-30",
    "bookName": "封魔师.1",
    "author": "陨落星辰著"
  },
  {
    "name": "石琼宇",
    "borrowTime": "2023-09-19",
    "bookName": "地狱变.新版",
    "author": "蔡骏著"
  },
  {
    "name": "石琼宇",
    "borrowTime": "2023-09-19",
    "bookName": "消失的证人",
    "author": "吕旭著"
  },
  {
    "name": "石琼宇",
    "borrowTime": "2023-09-19",
    "bookName": "地狱变.新版",
    "author": "蔡骏著"
  },
  {
    "name": "祝真辉",
    "borrowTime": "2024-05-05",
    "bookName": "明朝那些事儿.增补版",
    "author": "当年明月著"
  },
  {
    "name": "祝真辉",
    "borrowTime": "2024-05-20",
    "bookName": "明朝那些事儿.增补版",
    "author": "当年明月著"
  },
  {
    "name": "禚峻搏",
    "borrowTime": "2023-09-27",
    "bookName": "积案调查组",
    "author": "狐狸猫著"
  },
  {
    "name": "禹皓文",
    "borrowTime": "2023-09-25",
    "bookName": "婚姻是一道门",
    "author": "苏月著"
  },
  {
    "name": "禹皓文",
    "borrowTime": "2023-09-26",
    "bookName": "白鹿原",
    "author": "陈忠实著"
  },
  {
    "name": "程明润",
    "borrowTime": "2023-10-07",
    "bookName": "诡案组外传",
    "author": "求无欲著"
  },
  {
    "name": "程明润",
    "borrowTime": "2023-10-31",
    "bookName": "盗墓玄机:长篇盗墓小说",
    "author": "朱晓翔著"
  },
  {
    "name": "程晓棠",
    "borrowTime": "2023-09-21",
    "bookName": "HXN5型内燃机车",
    "author": "《和谐型交流传动机车技术丛书》编委会编"
  },
  {
    "name": "程晓棠",
    "borrowTime": "2023-09-21",
    "bookName": "韶山4型电力机车.上",
    "author": "张有松  朱龙驹   主编"
  },
  {
    "name": "程晓棠",
    "borrowTime": "2023-09-21",
    "bookName": "内燃机车总体",
    "author": "李晓村主编"
  },
  {
    "name": "程晓棠",
    "borrowTime": "2023-09-21",
    "bookName": "机车总体技术",
    "author": "主编陈友伟, 董亚男"
  },
  {
    "name": "程晟阳",
    "borrowTime": "2024-05-18",
    "bookName": "丰乳肥臀",
    "author": "莫言 [著]"
  },
  {
    "name": "程晟阳",
    "borrowTime": "2025-03-13",
    "bookName": "张资平精品选",
    "author": "张资平著"
  },
  {
    "name": "程晟阳",
    "borrowTime": "2025-03-19",
    "bookName": "庐隐作品集",
    "author": "庐隐著"
  },
  {
    "name": "程毅",
    "borrowTime": "2023-10-19",
    "bookName": "明朝那些事儿.第贰部,朱棣：逆子还是明君",
    "author": "当年明月著"
  },
  {
    "name": "程毅",
    "borrowTime": "2023-10-21",
    "bookName": "明朝那些事儿.第叁部,太监弄乱的王朝",
    "author": "当年明月著"
  },
  {
    "name": "程毅",
    "borrowTime": "2023-12-09",
    "bookName": "剑来.17,一洲皆起剑",
    "author": "烽火戏诸侯著"
  },
  {
    "name": "程毅",
    "borrowTime": "2024-05-10",
    "bookName": "八次危机:中国的真实经验:1949-2009",
    "author": "温铁军等著"
  },
  {
    "name": "程毅",
    "borrowTime": "2024-05-17",
    "bookName": "第七天.3版",
    "author": "余华著"
  },
  {
    "name": "程毅",
    "borrowTime": "2024-05-17",
    "bookName": "白夜行.第3版",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "程毅",
    "borrowTime": "2024-06-06",
    "bookName": "明朝那些事儿.第壹部,朱元璋：从和尚到皇帝",
    "author": "当年明月著"
  },
  {
    "name": "程毅",
    "borrowTime": "2024-09-29",
    "bookName": "八次危机:中国的真实经验:1949-2009",
    "author": "温铁军等著"
  },
  {
    "name": "程毅",
    "borrowTime": "2024-11-02",
    "bookName": "厌女.增订本",
    "author": "(日)上野千鹤子著"
  },
  {
    "name": "程毅",
    "borrowTime": "2025-03-05",
    "bookName": "风雪定陵:明定陵地下玄宫洞开记",
    "author": "岳南，杨仕著"
  },
  {
    "name": "程毅",
    "borrowTime": "2025-03-11",
    "bookName": "道德动物:我们为何如此思考、如此选择？:evolutionary psychology and everyday life",
    "author": "(美)罗伯特·赖特(Robert Wright)著"
  },
  {
    "name": "程毅",
    "borrowTime": "2025-03-19",
    "bookName": "硬汉计划:12周终极燃脂增肌计划:the ultimate 12-week program for burning fat and building muscle",
    "author": "(美)拉里·凯勒(Larry Keller)，美国《男士健康》图书编辑部著"
  },
  {
    "name": "程毅",
    "borrowTime": "2025-03-19",
    "bookName": "10分钟拉伸击退疼痛",
    "author": "(韩)崔在锡著"
  },
  {
    "name": "程毅",
    "borrowTime": "2025-03-26",
    "bookName": "司马迁的记忆之野",
    "author": "刘勃著"
  },
  {
    "name": "程毅",
    "borrowTime": "2025-03-29",
    "bookName": "匏瓜:读《史记·孔子世家》",
    "author": "刘勃著"
  },
  {
    "name": "程毅",
    "borrowTime": "2025-04-02",
    "bookName": "洪武:朱元璋的成与败",
    "author": "张宏杰著"
  },
  {
    "name": "程毅",
    "borrowTime": "2025-04-16",
    "bookName": "乌合之众",
    "author": "(法)古斯塔夫·勒庞(Gustave Le Bon)著"
  },
  {
    "name": "程毅",
    "borrowTime": "2025-04-25",
    "bookName": "饥饿的盛世:乾隆时代的得与失",
    "author": "张宏杰著"
  },
  {
    "name": "程毅",
    "borrowTime": "2025-04-27",
    "bookName": "易学与中医",
    "author": "张其成著"
  },
  {
    "name": "程毅",
    "borrowTime": "2025-05-10",
    "bookName": "红皇后效应:性与人性的演化.2版",
    "author": "(英)马特·里德利(Matt Ridley)著"
  },
  {
    "name": "程毅",
    "borrowTime": "2025-05-25",
    "bookName": "相杀相爱:两性关系的演化:Naturgeschichte des Paarverhaltens im Tierreich",
    "author": "(德)费陀斯·德浩谢尔(Vitus B. Dr?scher)著"
  },
  {
    "name": "程毅",
    "borrowTime": "2025-06-07",
    "bookName": "温暖的巢穴:动物们如何经营家庭:wie Tiere Familienprobleme l?sen",
    "author": "(德)费陀斯·德浩谢尔(Vitus B. Dr?scher)著"
  },
  {
    "name": "程毅",
    "borrowTime": "2025-06-15",
    "bookName": "第二性:纪念版.2",
    "author": "(法)西蒙娜·德·波伏瓦著"
  },
  {
    "name": "程毅",
    "borrowTime": "2026-04-19",
    "bookName": "羊的门",
    "author": "李佩甫著"
  },
  {
    "name": "籍涵",
    "borrowTime": "2023-10-08",
    "bookName": "斗罗大陆.第四部,终极斗罗.14",
    "author": "唐家三少著"
  },
  {
    "name": "缠凯然",
    "borrowTime": "2023-09-20",
    "bookName": "中国怪谈",
    "author": "赵志明著"
  },
  {
    "name": "缠凯然",
    "borrowTime": "2023-11-17",
    "bookName": "白银杰克",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "缠凯然",
    "borrowTime": "2023-11-17",
    "bookName": "欢迎来到实力至上主义的教室.4",
    "author": "(日) 衣笠彰梧著"
  },
  {
    "name": "罗俊福",
    "borrowTime": "2023-09-19",
    "bookName": "米尔伍德的浩劫",
    "author": "(美) 杰夫·惠勒著"
  },
  {
    "name": "罗俊福",
    "borrowTime": "2024-05-05",
    "bookName": "流浪之月",
    "author": "(日)凪良汐著"
  },
  {
    "name": "罗俊福",
    "borrowTime": "2024-05-05",
    "bookName": "流浪之月",
    "author": "(日)凪良汐著"
  },
  {
    "name": "罗俊福",
    "borrowTime": "2024-05-07",
    "bookName": "楢山节考",
    "author": "(日)深泽七郎著"
  },
  {
    "name": "罗俊福",
    "borrowTime": "2024-05-09",
    "bookName": "希望你也在这里",
    "author": "(日)中村航著"
  },
  {
    "name": "罗俊福",
    "borrowTime": "2024-05-12",
    "bookName": "山音",
    "author": "(日)川端康成著"
  },
  {
    "name": "罗俊福",
    "borrowTime": "2024-05-12",
    "bookName": "新哈姆雷特",
    "author": "(日)太宰治(Dazai Osamu)著"
  },
  {
    "name": "罗俊福",
    "borrowTime": "2024-05-24",
    "bookName": "伊豆的舞女",
    "author": "川端康成著"
  },
  {
    "name": "罗俊福",
    "borrowTime": "2024-05-30",
    "bookName": "替身",
    "author": "(日)青山七惠著"
  },
  {
    "name": "罗俊福",
    "borrowTime": "2024-09-18",
    "bookName": "浮世猫态",
    "author": "(日)夏目漱石，宫泽贤治等著"
  },
  {
    "name": "罗振宁",
    "borrowTime": "2024-06-21",
    "bookName": "暗祓",
    "author": "(日)辻村深月著"
  },
  {
    "name": "罗振宁",
    "borrowTime": "2024-08-31",
    "bookName": "光渊,黑曜天空,Obsidian sky",
    "author": "余卓轩著"
  },
  {
    "name": "罗文涛",
    "borrowTime": "2024-05-06",
    "bookName": "我是猫",
    "author": "(日) 夏目漱石著"
  },
  {
    "name": "罗文涛",
    "borrowTime": "2024-11-16",
    "bookName": "濒死之眼",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "罗淇",
    "borrowTime": "2023-10-31",
    "bookName": "中文版Photoshop基础培训教程",
    "author": "数字艺术教育研究室编著"
  },
  {
    "name": "翁宏",
    "borrowTime": "2025-04-23",
    "bookName": "LKJ2000型列车运行监控装置操作手册",
    "author": "郑州铁路局组织编写"
  },
  {
    "name": "翁宏",
    "borrowTime": "2025-04-23",
    "bookName": "LKJ2000型列车运行监控装置操作手册",
    "author": "郑州铁路局组织编写"
  },
  {
    "name": "翟宇航",
    "borrowTime": "2023-10-08",
    "bookName": "御剑天下",
    "author": "辰阳著"
  },
  {
    "name": "翟宇航",
    "borrowTime": "2023-10-08",
    "bookName": "法医档案.03,迟来真相.03,Truth comes late",
    "author": "戴西著"
  },
  {
    "name": "翟宇航",
    "borrowTime": "2023-10-19",
    "bookName": "十宗罪.5",
    "author": "蜘蛛著"
  },
  {
    "name": "翟宇航",
    "borrowTime": "2023-10-19",
    "bookName": "神曲",
    "author": "(意) 但丁著"
  },
  {
    "name": "翟焰灵",
    "borrowTime": "2023-11-01",
    "bookName": "有一点动心",
    "author": "鹿灵著"
  },
  {
    "name": "耿浩然",
    "borrowTime": "2023-11-15",
    "bookName": "重口味心理学:怎样证明你不是神经病?",
    "author": "姚尧著"
  },
  {
    "name": "聂之凯",
    "borrowTime": "2023-10-08",
    "bookName": "从零开始学写作",
    "author": "杨晓菁著"
  },
  {
    "name": "聂玉澄",
    "borrowTime": "2024-04-29",
    "bookName": "九州缥缈录.Ⅰ,蛮荒.修订版",
    "author": "江南著"
  },
  {
    "name": "聂玉澄",
    "borrowTime": "2024-04-29",
    "bookName": "九州缥缈录.Ⅱ.Ⅱ,苍云古齿",
    "author": "江南著"
  },
  {
    "name": "肖俊程",
    "borrowTime": "2023-09-25",
    "bookName": "诡案罪.4",
    "author": "岳勇著"
  },
  {
    "name": "肖俊程",
    "borrowTime": "2023-10-08",
    "bookName": "胰脏物语",
    "author": "(日) 住野夜著"
  },
  {
    "name": "肖俊程",
    "borrowTime": "2023-10-12",
    "bookName": "云之彼端, 约定的地方",
    "author": "(日) 新海诚原作"
  },
  {
    "name": "肖宗霖",
    "borrowTime": "2023-10-15",
    "bookName": "摸金传人.1,明陵疑冢",
    "author": "罗晓著"
  },
  {
    "name": "肖鹏",
    "borrowTime": "2023-10-10",
    "bookName": "查理日记.1,厄运古堡的百年诅咒.1,The centurial curse of the doomed castle",
    "author": "西西弗斯"
  },
  {
    "name": "胡仁杰",
    "borrowTime": "2023-10-07",
    "bookName": "剑来",
    "author": "烽火戏诸侯著"
  },
  {
    "name": "胡南",
    "borrowTime": "2023-11-12",
    "bookName": "悲鸣之剑",
    "author": "刘靖宇著"
  },
  {
    "name": "胡南",
    "borrowTime": "2023-12-03",
    "bookName": "白夜追凶",
    "author": "剧本原著指纹"
  },
  {
    "name": "胡智源",
    "borrowTime": "2023-09-16",
    "bookName": "青铜时代",
    "author": "王小波著"
  },
  {
    "name": "胡智源",
    "borrowTime": "2023-09-18",
    "bookName": "羊脂球",
    "author": "(法) 莫泊桑著"
  },
  {
    "name": "胡智源",
    "borrowTime": "2023-09-22",
    "bookName": "天谴者",
    "author": "法医秦明著"
  },
  {
    "name": "胡智源",
    "borrowTime": "2024-05-27",
    "bookName": "学霸记忆法:如何成为记忆高手",
    "author": "袁文魁，胡小玲著"
  },
  {
    "name": "胡智源",
    "borrowTime": "2024-09-11",
    "bookName": "《共产党宣言》细读",
    "author": "黄伟力著"
  },
  {
    "name": "胡智源",
    "borrowTime": "2024-09-28",
    "bookName": "活着.2版",
    "author": "余华著"
  },
  {
    "name": "胡智源",
    "borrowTime": "2026-03-04",
    "bookName": "时光煮酒 流年生香",
    "author": "张阳蕊著"
  },
  {
    "name": "胡海洋",
    "borrowTime": "2023-10-10",
    "bookName": "湄公河行动",
    "author": "冯锐著"
  },
  {
    "name": "胡淇",
    "borrowTime": "2023-09-19",
    "bookName": "无限系统树.1,无限之初.1",
    "author": "(日) 海道左近著"
  },
  {
    "name": "胡航菲",
    "borrowTime": "2023-09-20",
    "bookName": "法医档案.03,迟来真相.03,Truth comes late",
    "author": "戴西著"
  },
  {
    "name": "胡航菲",
    "borrowTime": "2023-09-20",
    "bookName": "猎凶者.1",
    "author": "范亮著"
  },
  {
    "name": "舒文",
    "borrowTime": "2023-10-21",
    "bookName": "长宁帝军",
    "author": "肖惊鸿主编"
  },
  {
    "name": "舒文",
    "borrowTime": "2024-05-06",
    "bookName": "长宁帝军",
    "author": "肖惊鸿主编"
  },
  {
    "name": "舒磊",
    "borrowTime": "2023-10-10",
    "bookName": "怪诞实录",
    "author": "凤仪著"
  },
  {
    "name": "苏宏旭",
    "borrowTime": "2023-09-04",
    "bookName": "罪全书.4",
    "author": "蜘蛛著"
  },
  {
    "name": "苏宏旭",
    "borrowTime": "2023-09-04",
    "bookName": "末日解剖",
    "author": "谢宗玉著"
  },
  {
    "name": "苏浩然",
    "borrowTime": "2023-09-18",
    "bookName": "克苏鲁神话合集",
    "author": "(美) 霍华德·菲利普·洛夫克拉夫特著"
  },
  {
    "name": "苏浩然",
    "borrowTime": "2023-10-21",
    "bookName": "死前七天",
    "author": "(瑞典) 卡瑞纳·伯格费尔特著"
  },
  {
    "name": "苏浩然",
    "borrowTime": "2023-10-29",
    "bookName": "飘",
    "author": "(美) 玛格丽特·米切尔著"
  },
  {
    "name": "苏浩然",
    "borrowTime": "2023-10-29",
    "bookName": "飘",
    "author": "(美) 玛格丽特·米切尔著"
  },
  {
    "name": "苏浩然",
    "borrowTime": "2023-10-31",
    "bookName": "编剧课堂:著名编剧、导演、制片人倾囊相授编剧的秘密",
    "author": "中国广播电影电视社会组织联合会电视剧编剧工作委员会编"
  },
  {
    "name": "苏浩然",
    "borrowTime": "2023-11-07",
    "bookName": "绝对零度.1,飞天",
    "author": "樊落著"
  },
  {
    "name": "苏浩然",
    "borrowTime": "2023-11-07",
    "bookName": "黄金瞳.5.5",
    "author": "打眼著"
  },
  {
    "name": "苏浩然",
    "borrowTime": "2023-11-26",
    "bookName": "远方旅人",
    "author": "唐洬著"
  },
  {
    "name": "苏浩然",
    "borrowTime": "2024-06-05",
    "bookName": "零基础学C语言程序设计",
    "author": "宋娟编著"
  },
  {
    "name": "苏浩然",
    "borrowTime": "2024-06-05",
    "bookName": "零基础学C语言程序设计",
    "author": "宋娟编著"
  },
  {
    "name": "苏浩然",
    "borrowTime": "2024-09-02",
    "bookName": "Premiere Pro从入门到精通",
    "author": "H.D.百科联盟编著"
  },
  {
    "name": "苏浩然",
    "borrowTime": "2024-09-11",
    "bookName": "爱，死亡和机器人.2&3",
    "author": "(英)J.G.巴拉德(J.G.Ballard)等著"
  },
  {
    "name": "苏浩然",
    "borrowTime": "2024-09-13",
    "bookName": "拉普拉斯的魔女",
    "author": "(日)东野圭吾著"
  },
  {
    "name": "苏浩然",
    "borrowTime": "2024-09-25",
    "bookName": "After Effects 2022从新手到高手",
    "author": "刘红梅编著"
  },
  {
    "name": "苏浩然",
    "borrowTime": "2024-10-13",
    "bookName": "After Effects 2022完全自学教程",
    "author": "宿瑞平编著"
  },
  {
    "name": "苏琳",
    "borrowTime": "2023-10-29",
    "bookName": "希腊神话中的怪物",
    "author": "(法)拉斐尔·马丁，(法)让-克里斯托弗·皮耶特著"
  },
  {
    "name": "苑鹏博",
    "borrowTime": "2023-10-08",
    "bookName": "消失的证人",
    "author": "吕旭著"
  },
  {
    "name": "苑鹏博",
    "borrowTime": "2023-10-19",
    "bookName": "朱威讲诡异案之诡异日记",
    "author": "朱威著"
  },
  {
    "name": "苑鹏博",
    "borrowTime": "2024-09-11",
    "bookName": "特案科:刑警手记.上",
    "author": "风雨如书著"
  },
  {
    "name": "苑鹏博",
    "borrowTime": "2024-09-24",
    "bookName": "诡案罪.4",
    "author": "岳勇著"
  },
  {
    "name": "苑鹏博",
    "borrowTime": "2024-09-26",
    "bookName": "罪全书.4",
    "author": "蜘蛛著"
  },
  {
    "name": "范佳城",
    "borrowTime": "2025-09-17",
    "bookName": "人民的名义:纪念版",
    "author": "周梅森著"
  },
  {
    "name": "范勇宁",
    "borrowTime": "2023-09-05",
    "bookName": "佛头遗案.第2版",
    "author": "楮实子著"
  },
  {
    "name": "荣成举",
    "borrowTime": "2023-10-17",
    "bookName": "四世同堂",
    "author": "老舍著"
  },
  {
    "name": "董之鸿",
    "borrowTime": "2023-09-12",
    "bookName": "你看完不敢睡, 看了还想看的悬疑小说.Ⅰ",
    "author": "白虹主编"
  },
  {
    "name": "董之鸿",
    "borrowTime": "2023-09-18",
    "bookName": "满世界找诡:散客月下四海奇谭",
    "author": "散客月下著"
  },
  {
    "name": "董佳鑫",
    "borrowTime": "2023-10-10",
    "bookName": "法眼",
    "author": "木森著"
  },
  {
    "name": "董佳鑫",
    "borrowTime": "2023-10-20",
    "bookName": "诡案组.2.Season two.第2季",
    "author": "求无欲著"
  },
  {
    "name": "董宣炜",
    "borrowTime": "2023-09-19",
    "bookName": "诡秘之主.1,绯红之月",
    "author": "爱潜水的乌贼著"
  },
  {
    "name": "董宣炜",
    "borrowTime": "2023-10-07",
    "bookName": "诡秘之主.1,绯红之月",
    "author": "爱潜水的乌贼著"
  },
  {
    "name": "董宣炜",
    "borrowTime": "2023-10-07",
    "bookName": "元尊.6,逆流而上",
    "author": "天蚕土豆著"
  },
  {
    "name": "董志昊",
    "borrowTime": "2024-05-16",
    "bookName": "雪中悍刀行.2,白马出凉州",
    "author": "烽火戏诸侯著"
  },
  {
    "name": "董志昊",
    "borrowTime": "2024-11-10",
    "bookName": "微反应心理学:瞬间洞悉每一个行为背后的玄机",
    "author": "赵飞编著"
  },
  {
    "name": "董芫序",
    "borrowTime": "2023-09-25",
    "bookName": "极简摄影",
    "author": "先锋影像编著"
  },
  {
    "name": "董雨轩",
    "borrowTime": "2023-09-19",
    "bookName": "原罪.1,迷案追踪",
    "author": "一曲东风著"
  },
  {
    "name": "董雨轩",
    "borrowTime": "2023-09-19",
    "bookName": "原罪.1,迷案追踪",
    "author": "一曲东风著"
  },
  {
    "name": "蒋东辰",
    "borrowTime": "2023-10-07",
    "bookName": "重回犯罪现场.3",
    "author": "风雨如书著"
  },
  {
    "name": "蒋东辰",
    "borrowTime": "2023-10-31",
    "bookName": "罪全书.6",
    "author": "蜘蛛著"
  },
  {
    "name": "蒋博伦",
    "borrowTime": "2023-10-17",
    "bookName": "悖论13.3版",
    "author": "(日)东野圭吾著"
  },
  {
    "name": "蒋淯晟",
    "borrowTime": "2023-09-05",
    "bookName": "犯罪心理学",
    "author": "(美) Curt R. Bartol, Anne M. Bartol著"
  },
  {
    "name": "蒋淯晟",
    "borrowTime": "2023-11-01",
    "bookName": "故事新编",
    "author": "鲁迅著"
  },
  {
    "name": "蒋逸飞",
    "borrowTime": "2023-09-18",
    "bookName": "天气之子",
    "author": "(日) 新海诚著"
  },
  {
    "name": "蒯家祥",
    "borrowTime": "2025-04-09",
    "bookName": "公主失踪了:名著双语读物·中文导读+英文原版",
    "author": "(美)鲍姆著"
  },
  {
    "name": "蒯家祥",
    "borrowTime": "2025-04-09",
    "bookName": "英语零起点入门一学就会",
    "author": "张波编著"
  },
  {
    "name": "蔡一铭",
    "borrowTime": "2023-10-15",
    "bookName": "无证之罪.第2版",
    "author": "紫金陈著"
  },
  {
    "name": "蔡一铭",
    "borrowTime": "2023-11-06",
    "bookName": "斗罗大陆.第四部,终极斗罗.12",
    "author": "唐家三少著"
  },
  {
    "name": "蔡一铭",
    "borrowTime": "2023-11-11",
    "bookName": "做局高手:一个商界大佬的巨大阴谋与超级圈套",
    "author": "柯云路著"
  },
  {
    "name": "蔡一铭",
    "borrowTime": "2023-11-11",
    "bookName": "剑来",
    "author": "烽火戏诸侯著"
  },
  {
    "name": "蔡一铭",
    "borrowTime": "2023-11-11",
    "bookName": "啊2.0.增补版",
    "author": "大冰作品"
  },
  {
    "name": "蔡一铭",
    "borrowTime": "2023-12-08",
    "bookName": "九重禁.第3季",
    "author": "茶又清著"
  },
  {
    "name": "蔡一铭",
    "borrowTime": "2023-12-08",
    "bookName": "剑来.18,我与我周旋",
    "author": "烽火戏诸侯著"
  },
  {
    "name": "蔡俊",
    "borrowTime": "2024-10-16",
    "bookName": "我与地坛",
    "author": "史铁生著"
  },
  {
    "name": "薛劲达",
    "borrowTime": "2023-10-17",
    "bookName": "教化场",
    "author": "雷米著"
  },
  {
    "name": "薛皓文",
    "borrowTime": "2025-06-02",
    "bookName": "Proteus实战攻略:从简单电路到单片机电路的仿真",
    "author": "刘波[等]编著"
  },
  {
    "name": "薛皓文",
    "borrowTime": "2025-06-02",
    "bookName": "Proteus实战攻略:从简单电路到单片机电路的仿真",
    "author": "刘波[等]编著"
  },
  {
    "name": "衣健",
    "borrowTime": "2023-09-12",
    "bookName": "刑警手记,虚拟谋杀",
    "author": "野兵著"
  },
  {
    "name": "衣海楠",
    "borrowTime": "2023-09-19",
    "bookName": "黄金瞳.3.3",
    "author": "打眼著"
  },
  {
    "name": "衣海楠",
    "borrowTime": "2023-10-19",
    "bookName": "平凡的世界",
    "author": "路遥著"
  },
  {
    "name": "衣海楠",
    "borrowTime": "2023-10-21",
    "bookName": "平凡的世界",
    "author": "路遥著"
  },
  {
    "name": "衣海楠",
    "borrowTime": "2023-10-27",
    "bookName": "那片星空, 那片海",
    "author": "桐华作品"
  },
  {
    "name": "衣海楠",
    "borrowTime": "2023-11-19",
    "bookName": "黄金瞳.2.2",
    "author": "打眼著"
  },
  {
    "name": "衣海楠",
    "borrowTime": "2023-12-13",
    "bookName": "黄金瞳.6.6",
    "author": "打眼著"
  },
  {
    "name": "衣海楠",
    "borrowTime": "2025-03-06",
    "bookName": "电力机车检修",
    "author": "莫坚主编"
  },
  {
    "name": "袁镕鹏",
    "borrowTime": "2023-09-26",
    "bookName": "封魔师.1",
    "author": "陨落星辰著"
  },
  {
    "name": "袁镕鹏",
    "borrowTime": "2023-10-07",
    "bookName": "封魔师.2",
    "author": "陨落星辰著"
  },
  {
    "name": "袁镕鹏",
    "borrowTime": "2023-10-10",
    "bookName": "魔兽战神.2,十大战王",
    "author": "龙人著"
  },
  {
    "name": "袁镕鹏",
    "borrowTime": "2023-11-20",
    "bookName": "半小时漫画唐诗",
    "author": "陈磊 半小时漫画团队著"
  },
  {
    "name": "袁镕鹏",
    "borrowTime": "2023-11-20",
    "bookName": "半小时漫画唐诗",
    "author": "陈磊·半小时漫画团队著"
  },
  {
    "name": "袁镕鹏",
    "borrowTime": "2024-09-03",
    "bookName": "惊变二十三天",
    "author": "赤蝶飞飞著"
  },
  {
    "name": "袁镕鹏",
    "borrowTime": "2024-09-03",
    "bookName": "牧野诡事",
    "author": "天下霸唱著"
  },
  {
    "name": "褚茂吉",
    "borrowTime": "2023-11-20",
    "bookName": "原罪",
    "author": "吕铮著"
  },
  {
    "name": "褚茂吉",
    "borrowTime": "2023-11-20",
    "bookName": "痕迹",
    "author": "毕蔷著"
  },
  {
    "name": "詹鸿宾",
    "borrowTime": "2023-10-15",
    "bookName": "漫画半小时中华上下五千年",
    "author": "胖乐胖乐编绘"
  },
  {
    "name": "许志强",
    "borrowTime": "2023-10-27",
    "bookName": "惩罚者:大结局,完美谎言",
    "author": "韦一同著"
  },
  {
    "name": "谢佳明",
    "borrowTime": "2023-09-28",
    "bookName": "明朝那些事儿.增补版",
    "author": "当年明月著"
  },
  {
    "name": "谢佳明",
    "borrowTime": "2023-10-22",
    "bookName": "明朝那些事儿.增补版",
    "author": "当年明月著"
  },
  {
    "name": "谢佳明",
    "borrowTime": "2023-11-29",
    "bookName": "明朝那些事儿.增补版",
    "author": "当年明月著"
  },
  {
    "name": "谢佳明",
    "borrowTime": "2025-09-08",
    "bookName": "大明疑案.2",
    "author": "傅小凡著"
  },
  {
    "name": "谢文炜",
    "borrowTime": "2023-09-22",
    "bookName": "只想做你的小狐狸",
    "author": "矢厘著"
  },
  {
    "name": "谢文炜",
    "borrowTime": "2023-10-06",
    "bookName": "天气之子",
    "author": "(日) 新海诚著"
  },
  {
    "name": "谢文炜",
    "borrowTime": "2023-11-20",
    "bookName": "赘婿.2,心如猛虎",
    "author": "愤怒的香蕉著"
  },
  {
    "name": "谢文炜",
    "borrowTime": "2023-11-21",
    "bookName": "傲世君少.3",
    "author": "风凌天下著"
  },
  {
    "name": "谢昀庭",
    "borrowTime": "2023-10-07",
    "bookName": "教父前传",
    "author": "(美国) 马里奥·普佐, 埃德·法尔科著"
  },
  {
    "name": "谢明洋",
    "borrowTime": "2023-11-28",
    "bookName": "末世浩劫",
    "author": "刘慈欣等著"
  },
  {
    "name": "谢明洋",
    "borrowTime": "2023-11-28",
    "bookName": "触不到的你",
    "author": "宅小花著"
  },
  {
    "name": "谢明洋",
    "borrowTime": "2024-05-29",
    "bookName": "新哈姆雷特",
    "author": "(日)太宰治(Dazai Osamu)著"
  },
  {
    "name": "谢明洋",
    "borrowTime": "2024-05-29",
    "bookName": "我是寻找夏目的猫",
    "author": "(日)白野猫咪著"
  },
  {
    "name": "谢明洋",
    "borrowTime": "2024-05-29",
    "bookName": "替身",
    "author": "(日)青山七惠著"
  },
  {
    "name": "谷珈旭",
    "borrowTime": "2026-03-02",
    "bookName": "长城简史",
    "author": "徐永清著"
  },
  {
    "name": "费禹翔",
    "borrowTime": "2025-05-24",
    "bookName": "铁路行车安全管理",
    "author": "韩买良主编"
  },
  {
    "name": "费禹翔",
    "borrowTime": "2025-05-24",
    "bookName": "铁路行车安全管理实务",
    "author": "曾毅, 李嵘主编"
  },
  {
    "name": "贺海辉",
    "borrowTime": "2024-05-15",
    "bookName": "国家记忆:《共产党宣言》中文首译本传奇.修订版",
    "author": "铁流，徐锦庚著"
  },
  {
    "name": "贾博壹",
    "borrowTime": "2023-11-03",
    "bookName": "哈利·波特与魔法石",
    "author": "(英) J.K.罗琳著"
  },
  {
    "name": "贾博壹",
    "borrowTime": "2023-11-14",
    "bookName": "罪无赦:迷失的森林",
    "author": "王措著"
  },
  {
    "name": "贾博壹",
    "borrowTime": "2023-11-27",
    "bookName": "心理罪,第七个读者",
    "author": "雷米作品"
  },
  {
    "name": "贾博壹",
    "borrowTime": "2023-11-27",
    "bookName": "连环罪:心理有诡",
    "author": "墨绿青苔著"
  },
  {
    "name": "贾博壹",
    "borrowTime": "2024-05-06",
    "bookName": "高等数学 题型归类·方法点拨·考研辅导.第3版",
    "author": "主编马菊侠"
  },
  {
    "name": "贾博壹",
    "borrowTime": "2024-05-06",
    "bookName": "哈佛高效学习法",
    "author": "王艺宁著"
  },
  {
    "name": "贾同鑫",
    "borrowTime": "2023-10-09",
    "bookName": "克苏鲁神话合集",
    "author": "(美) 霍华德·菲利普·洛夫克拉夫特著"
  },
  {
    "name": "贾同鑫",
    "borrowTime": "2023-10-12",
    "bookName": "中国奇异档案记录.第四季",
    "author": "宋歌编著"
  },
  {
    "name": "贾同鑫",
    "borrowTime": "2024-06-04",
    "bookName": "这不可能是真的!",
    "author": "陈超译"
  },
  {
    "name": "贾小龙",
    "borrowTime": "2024-09-04",
    "bookName": "不是风动,是心动",
    "author": "森木岛屿著"
  },
  {
    "name": "贾贤达",
    "borrowTime": "2023-12-13",
    "bookName": "舌尖寻香:大连美食",
    "author": "王希君著"
  },
  {
    "name": "贾贤达",
    "borrowTime": "2024-10-16",
    "bookName": "未开放的故宫",
    "author": "陈连营, 张楠编著"
  },
  {
    "name": "贾贤达",
    "borrowTime": "2025-04-01",
    "bookName": "中华流失文物迷踪.1",
    "author": "牛宪锋著"
  },
  {
    "name": "贾贤达",
    "borrowTime": "2025-04-01",
    "bookName": "荒野上的大师:中国考古百年纪",
    "author": "张泉著"
  },
  {
    "name": "贾贤达",
    "borrowTime": "2025-05-25",
    "bookName": "传感器与测试技术",
    "author": "周传德主编"
  },
  {
    "name": "贾静宇",
    "borrowTime": "2023-09-25",
    "bookName": "黄金瞳.1.1",
    "author": "打眼著"
  },
  {
    "name": "贾静宇",
    "borrowTime": "2023-09-30",
    "bookName": "黄金瞳.3.3",
    "author": "打眼著"
  },
  {
    "name": "贾静宇",
    "borrowTime": "2023-10-04",
    "bookName": "黄金瞳.8.8",
    "author": "打眼著"
  },
  {
    "name": "贾静宇",
    "borrowTime": "2023-10-26",
    "bookName": "赘婿.5,龙蛇起陆",
    "author": "愤怒的香蕉著"
  },
  {
    "name": "贾静宇",
    "borrowTime": "2023-12-05",
    "bookName": "择天记.第一卷,恰同学少年",
    "author": "猫腻著"
  },
  {
    "name": "贾静宇",
    "borrowTime": "2023-12-08",
    "bookName": "择天记.第三卷,莫道君行早",
    "author": "猫腻著"
  },
  {
    "name": "贾静宇",
    "borrowTime": "2023-12-08",
    "bookName": "择天记.第四卷,起风雷",
    "author": "猫腻著"
  },
  {
    "name": "赫彦淇",
    "borrowTime": "2025-05-18",
    "bookName": "穷查理箴言:查理·芒格写给年轻人",
    "author": "张笑恒编著"
  },
  {
    "name": "赫彦淇",
    "borrowTime": "2025-05-25",
    "bookName": "原则",
    "author": "(美) 瑞·达利欧著"
  },
  {
    "name": "赫彦淇",
    "borrowTime": "2025-06-06",
    "bookName": "和陌生人说话:搭讪圣经",
    "author": "郑匡宇著"
  },
  {
    "name": "赫彦淇",
    "borrowTime": "2025-06-10",
    "bookName": "玩转副业:多一份收入过更好的生活",
    "author": "王光伟编著"
  },
  {
    "name": "赫彦淇",
    "borrowTime": "2025-06-11",
    "bookName": "快速阅读.修订版",
    "author": "(英)东尼·博赞(Tony Buzan)著"
  },
  {
    "name": "赫彦淇",
    "borrowTime": "2025-06-12",
    "bookName": "影响力",
    "author": "(美) 罗伯特·西奥迪尼著"
  },
  {
    "name": "赫彦淇",
    "borrowTime": "2025-06-17",
    "bookName": "短视频内容创作、账号运营与11个盈利途径",
    "author": "雷波编著"
  },
  {
    "name": "赫彦淇",
    "borrowTime": "2025-06-22",
    "bookName": "早起的奇迹,有钱人早晨8点前都在干什么?",
    "author": "(美)哈尔·埃尔罗德(Hal Elrod), (美)大卫·奥斯本(David Osborn), (美)霍诺丽·科德(Honoree Corder)著"
  },
  {
    "name": "赫彦淇",
    "borrowTime": "2025-06-22",
    "bookName": "早起的奇迹,有钱人早晨8点前都在干什么?",
    "author": "(美)哈尔·埃尔罗德(Hal Elrod), (美)大卫·奥斯本(David Osborn), (美)霍诺丽·科德(Honoree Corder)著"
  },
  {
    "name": "赫彦淇",
    "borrowTime": "2025-06-26",
    "bookName": "了不起的精力管理:打败疲惫、焦虑和压力",
    "author": "唐希媛著"
  },
  {
    "name": "赫彦淇",
    "borrowTime": "2025-08-26",
    "bookName": "认知觉醒:开启自我改变的原动力",
    "author": "周岭著"
  },
  {
    "name": "赵伟",
    "borrowTime": "2023-09-14",
    "bookName": "我吃西红柿与《吞噬星空》",
    "author": "夏烈著"
  },
  {
    "name": "赵伟",
    "borrowTime": "2023-09-15",
    "bookName": "吞噬星空:典藏版.1",
    "author": "我吃西红柿著"
  },
  {
    "name": "赵伟",
    "borrowTime": "2023-09-19",
    "bookName": "新大话西游.2,沧海问剑",
    "author": "天蚕土豆, 管平潮作品"
  },
  {
    "name": "赵伟",
    "borrowTime": "2023-09-19",
    "bookName": "气冲星河.1,少年无双",
    "author": "犁天著"
  },
  {
    "name": "赵伟",
    "borrowTime": "2023-10-23",
    "bookName": "气冲星河.9,太古之谜",
    "author": "犁天著"
  },
  {
    "name": "赵伟",
    "borrowTime": "2023-10-23",
    "bookName": "气冲星河.9,太古之谜",
    "author": "犁天著"
  },
  {
    "name": "赵俊杰",
    "borrowTime": "2023-09-12",
    "bookName": "地狱公寓.3",
    "author": "董协著"
  },
  {
    "name": "赵俊杰",
    "borrowTime": "2023-10-15",
    "bookName": "世界怪奇实话",
    "author": "(日) 牧逸马著"
  },
  {
    "name": "赵俸楷",
    "borrowTime": "2023-10-10",
    "bookName": "摸金传人.2,摄魂奇珠",
    "author": "罗晓著"
  },
  {
    "name": "赵俸楷",
    "borrowTime": "2023-10-11",
    "bookName": "超禁忌游戏.1",
    "author": "宁航一著"
  },
  {
    "name": "赵哲",
    "borrowTime": "2023-09-12",
    "bookName": "东宫缺个太子妃",
    "author": "麦果著"
  },
  {
    "name": "赵哲",
    "borrowTime": "2023-09-12",
    "bookName": "一套书读懂逻辑,思维导图",
    "author": "弘丰编著"
  },
  {
    "name": "赵哲",
    "borrowTime": "2023-09-12",
    "bookName": "情商高就是说话办事让人舒服",
    "author": "改编刘刚"
  },
  {
    "name": "赵哲",
    "borrowTime": "2023-09-12",
    "bookName": "九型人格:职场指南:mastering the art of people in the 21st century workplace",
    "author": "(美) 比特丽丝·切斯纳特著"
  },
  {
    "name": "赵哲",
    "borrowTime": "2023-09-12",
    "bookName": "说话心理学",
    "author": "胡元斌编著"
  },
  {
    "name": "赵子熠",
    "borrowTime": "2024-05-10",
    "bookName": "暮天归思",
    "author": "余秋雨著"
  },
  {
    "name": "赵子熠",
    "borrowTime": "2024-05-16",
    "bookName": "史记",
    "author": "(西汉) 司马迁著"
  },
  {
    "name": "赵宇",
    "borrowTime": "2023-10-20",
    "bookName": "你看完不敢睡, 看了还想看的悬疑小说.Ⅰ",
    "author": "白虹主编"
  },
  {
    "name": "赵宇",
    "borrowTime": "2023-11-06",
    "bookName": "亡者永生",
    "author": "那多著"
  },
  {
    "name": "赵宇",
    "borrowTime": "2024-04-28",
    "bookName": "这个店有古怪",
    "author": "明月听风著"
  },
  {
    "name": "赵宇",
    "borrowTime": "2024-05-10",
    "bookName": "地狱变.新版",
    "author": "蔡骏著"
  },
  {
    "name": "赵宇",
    "borrowTime": "2024-05-12",
    "bookName": "天齐大陆",
    "author": "月下泷痕著"
  },
  {
    "name": "赵宏伟",
    "borrowTime": "2023-10-15",
    "bookName": "绑嫁",
    "author": "三盅著"
  },
  {
    "name": "赵宏伟",
    "borrowTime": "2023-11-12",
    "bookName": "教化场",
    "author": "雷米著"
  },
  {
    "name": "赵宏伟",
    "borrowTime": "2023-11-12",
    "bookName": "心理罪,暗河",
    "author": "雷米作品"
  },
  {
    "name": "赵宏伟",
    "borrowTime": "2023-11-24",
    "bookName": "沙海.第二卷,沙蟒蛇巢",
    "author": "南派三叔著"
  },
  {
    "name": "赵宏伟",
    "borrowTime": "2023-11-24",
    "bookName": "盗墓笔记:十年",
    "author": "南派三叔著"
  },
  {
    "name": "赵宏伟",
    "borrowTime": "2023-11-30",
    "bookName": "黄金瞳.1.1",
    "author": "打眼著"
  },
  {
    "name": "赵宏伟",
    "borrowTime": "2023-11-30",
    "bookName": "黄金瞳.2.2",
    "author": "打眼著"
  },
  {
    "name": "赵宏伟",
    "borrowTime": "2024-05-06",
    "bookName": "惩罚者:大结局,完美谎言",
    "author": "韦一同著"
  },
  {
    "name": "赵宏伟",
    "borrowTime": "2024-05-06",
    "bookName": "狼图腾.修订版",
    "author": "姜戎著"
  },
  {
    "name": "赵家成",
    "borrowTime": "2026-03-03",
    "bookName": "70t级铁路货车及新型零部件",
    "author": "陈雷,张志建主编"
  },
  {
    "name": "赵小岳",
    "borrowTime": "2023-10-31",
    "bookName": "祈祷落幕时",
    "author": "(日)东野圭吾著"
  },
  {
    "name": "赵小岳",
    "borrowTime": "2023-12-10",
    "bookName": "人间失格",
    "author": "(日) 太宰治著"
  },
  {
    "name": "赵小岳",
    "borrowTime": "2023-12-10",
    "bookName": "摸金玦之鬼门天师",
    "author": "天下霸唱[著]"
  },
  {
    "name": "赵成斌",
    "borrowTime": "2023-10-17",
    "bookName": "天才在左 疯子在右:完整版",
    "author": "高铭著"
  },
  {
    "name": "赵昕怡",
    "borrowTime": "2024-09-08",
    "bookName": "第二性:纪念版.1",
    "author": "(法)西蒙娜·德·波伏瓦著"
  },
  {
    "name": "赵昕怡",
    "borrowTime": "2024-09-08",
    "bookName": "想象的全球化",
    "author": "(阿根廷)内斯托尔·加西亚·坎克里尼(Néstor García Canclini)著"
  },
  {
    "name": "赵晨曦",
    "borrowTime": "2023-10-28",
    "bookName": "活着",
    "author": "余华著"
  },
  {
    "name": "赵晨曦",
    "borrowTime": "2023-11-16",
    "bookName": "赘婿.1,江宁晨风",
    "author": "愤怒的香蕉著"
  },
  {
    "name": "赵智昊",
    "borrowTime": "2023-10-16",
    "bookName": "大地之灯",
    "author": "七堇年作品"
  },
  {
    "name": "赵柏涵",
    "borrowTime": "2023-09-12",
    "bookName": "重案追击:罪恶的心理画像",
    "author": "琉天玺著"
  },
  {
    "name": "赵欣茹",
    "borrowTime": "2023-10-23",
    "bookName": "小泉八云精怪故事集",
    "author": "(日) 小泉八云著"
  },
  {
    "name": "赵欣茹",
    "borrowTime": "2023-11-05",
    "bookName": "路过风景路过你",
    "author": "沈嘉柯著"
  },
  {
    "name": "赵欣茹",
    "borrowTime": "2023-12-13",
    "bookName": "你看完不敢睡, 看了还想看的悬疑小说.Ⅰ",
    "author": "白虹主编"
  },
  {
    "name": "赵欣茹",
    "borrowTime": "2024-05-15",
    "bookName": "莽荒纪.12,剑噬星辰",
    "author": "我吃西红柿著"
  },
  {
    "name": "赵洺健",
    "borrowTime": "2023-09-20",
    "bookName": "推理世界,七宗案",
    "author": "王念知著"
  },
  {
    "name": "赵烔",
    "borrowTime": "2023-09-24",
    "bookName": "原罪.2,暗夜使徒",
    "author": "一曲东风著"
  },
  {
    "name": "赵烔",
    "borrowTime": "2023-10-09",
    "bookName": "黄金瞳.1.1",
    "author": "打眼著"
  },
  {
    "name": "赵烔",
    "borrowTime": "2023-10-22",
    "bookName": "黄金瞳.5.5",
    "author": "打眼著"
  },
  {
    "name": "赵超",
    "borrowTime": "2023-10-08",
    "bookName": "黄金瞳.2.2",
    "author": "打眼著"
  },
  {
    "name": "赵超",
    "borrowTime": "2023-10-31",
    "bookName": "女法医:温柔的解剖",
    "author": "明菲著"
  },
  {
    "name": "赵雨轩",
    "borrowTime": "2023-11-16",
    "bookName": "默读",
    "author": "Priest著"
  },
  {
    "name": "路志鹏",
    "borrowTime": "2024-05-15",
    "bookName": "十宗罪.5",
    "author": "蜘蛛著"
  },
  {
    "name": "路皓然",
    "borrowTime": "2023-10-06",
    "bookName": "民调局异闻录.1,稚国迷窟",
    "author": "耳东水寿著"
  },
  {
    "name": "路皓然",
    "borrowTime": "2023-10-06",
    "bookName": "撒野",
    "author": "木小瓷作品"
  },
  {
    "name": "辛海泉",
    "borrowTime": "2023-09-20",
    "bookName": "死亡解剖台",
    "author": "(美) 斐德列克·萨吉伯著"
  },
  {
    "name": "邓皓",
    "borrowTime": "2023-10-29",
    "bookName": "龙族.Ⅰ,火之晨曦",
    "author": "江南著"
  },
  {
    "name": "邢珈绪",
    "borrowTime": "2023-12-20",
    "bookName": "活着",
    "author": "余华著"
  },
  {
    "name": "邱高阳",
    "borrowTime": "2023-10-09",
    "bookName": "嫌疑人X的献身.第2版",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "邱高阳",
    "borrowTime": "2024-05-06",
    "bookName": "世界经典侦探小说",
    "author": "王春祥主编"
  },
  {
    "name": "邵琪哲",
    "borrowTime": "2023-09-19",
    "bookName": "吞噬星空:典藏版.1",
    "author": "我吃西红柿著"
  },
  {
    "name": "邸泓博",
    "borrowTime": "2023-10-07",
    "bookName": "盗墓迷城之皇陵宝藏",
    "author": "迦南行者著"
  },
  {
    "name": "邸泓博",
    "borrowTime": "2023-11-05",
    "bookName": "印度异闻录",
    "author": "羊行屮著"
  },
  {
    "name": "邸泓博",
    "borrowTime": "2023-11-19",
    "bookName": "尸案调查科.2,重案捕手",
    "author": "九滴水著"
  },
  {
    "name": "邹嘉宾",
    "borrowTime": "2023-09-26",
    "bookName": "痕迹",
    "author": "毕蔷著"
  },
  {
    "name": "郑家旭",
    "borrowTime": "2023-10-30",
    "bookName": "元尊.13,九域论战",
    "author": "天蚕土豆著"
  },
  {
    "name": "郑家旭",
    "borrowTime": "2023-11-14",
    "bookName": "黄金瞳.3.3",
    "author": "打眼著"
  },
  {
    "name": "郑恒涛",
    "borrowTime": "2023-10-11",
    "bookName": "牧野诡事",
    "author": "天下霸唱著"
  },
  {
    "name": "郑明哲",
    "borrowTime": "2024-06-01",
    "bookName": "富爸爸女人一定要有钱",
    "author": "(美) 金·清崎著"
  },
  {
    "name": "郑明哲",
    "borrowTime": "2024-10-24",
    "bookName": "是什么缔造了汉江奇迹",
    "author": "(韩)俞正镐著"
  },
  {
    "name": "郑明哲",
    "borrowTime": "2024-11-19",
    "bookName": "第一次做生意",
    "author": "丹牛著"
  },
  {
    "name": "郑明哲",
    "borrowTime": "2025-09-16",
    "bookName": "英语语法二十五页",
    "author": "靳行凡编"
  },
  {
    "name": "郑明哲",
    "borrowTime": "2025-09-16",
    "bookName": "你是那99%，还是那1%？:像经济学家一样思考:get to grips with money and markets",
    "author": "(英)安妮·鲁尼(Anne Rooney)著"
  },
  {
    "name": "郑明哲",
    "borrowTime": "2025-10-14",
    "bookName": "拆掉思维里看不见的墙",
    "author": "(日)筱原信著"
  },
  {
    "name": "郑霖轩",
    "borrowTime": "2023-10-08",
    "bookName": "午夜别候车",
    "author": "韩学龙著"
  },
  {
    "name": "郑霖轩",
    "borrowTime": "2023-10-08",
    "bookName": "陆家古宅",
    "author": "孙磊著"
  },
  {
    "name": "郝勇涵",
    "borrowTime": "2023-09-10",
    "bookName": "牧野诡事",
    "author": "天下霸唱著"
  },
  {
    "name": "郝勇涵",
    "borrowTime": "2023-09-12",
    "bookName": "罪全书.6",
    "author": "蜘蛛著"
  },
  {
    "name": "郝勇涵",
    "borrowTime": "2023-11-17",
    "bookName": "清道夫",
    "author": "秦明著"
  },
  {
    "name": "郝勇涵",
    "borrowTime": "2023-11-26",
    "bookName": "摸金传人.2,摄魂奇珠",
    "author": "罗晓著"
  },
  {
    "name": "郝勇涵",
    "borrowTime": "2023-11-26",
    "bookName": "摸金传人.1,明陵疑冢",
    "author": "罗晓著"
  },
  {
    "name": "郝秋实",
    "borrowTime": "2024-05-12",
    "bookName": "消失的证人",
    "author": "吕旭著"
  },
  {
    "name": "郦科臣",
    "borrowTime": "2023-12-14",
    "bookName": "都挺好,完结篇",
    "author": "阿耐著"
  },
  {
    "name": "郦科臣",
    "borrowTime": "2023-12-14",
    "bookName": "斗罗大陆.第三部,龙王传说.8",
    "author": "唐家三少著"
  },
  {
    "name": "郭中原",
    "borrowTime": "2023-09-25",
    "bookName": "新诡案组",
    "author": "求无尘著"
  },
  {
    "name": "郭中原",
    "borrowTime": "2023-10-17",
    "bookName": "兽血大陆.5",
    "author": "灵隐狐著"
  },
  {
    "name": "郭中原",
    "borrowTime": "2023-10-17",
    "bookName": "兽血大陆.3",
    "author": "灵隐狐著"
  },
  {
    "name": "郭中原",
    "borrowTime": "2023-10-17",
    "bookName": "兽血大陆.4",
    "author": "灵隐狐著"
  },
  {
    "name": "郭中原",
    "borrowTime": "2023-10-17",
    "bookName": "兽血大陆.2",
    "author": "灵隐狐著"
  },
  {
    "name": "郭千永",
    "borrowTime": "2023-11-01",
    "bookName": "遇见你, 微风起",
    "author": "稚初著"
  },
  {
    "name": "郭嘉鑫",
    "borrowTime": "2024-12-03",
    "bookName": "必须犯规的游戏:大结局",
    "author": "宁航一著"
  },
  {
    "name": "郭嘉鑫",
    "borrowTime": "2024-12-03",
    "bookName": "你不知道的刑侦内幕:一线警察讲段子.1",
    "author": "何斌著"
  },
  {
    "name": "郭嘉鑫",
    "borrowTime": "2024-12-03",
    "bookName": "房产大鳄",
    "author": "栀子著"
  },
  {
    "name": "郭奕成",
    "borrowTime": "2023-09-19",
    "bookName": "救赎之路",
    "author": "(美) 约翰·哈特著"
  },
  {
    "name": "郭子轩",
    "borrowTime": "2024-04-27",
    "bookName": "铁路线路工",
    "author": "王春江主编"
  },
  {
    "name": "郭子轩",
    "borrowTime": "2024-09-13",
    "bookName": "摸金传人.5,湘西蛊术",
    "author": "罗晓著"
  },
  {
    "name": "郭子轩",
    "borrowTime": "2024-09-22",
    "bookName": "万历大时代",
    "author": "刘起瑞著"
  },
  {
    "name": "郭子轩",
    "borrowTime": "2024-10-10",
    "bookName": "曾国藩.中.修订版",
    "author": "唐浩明著"
  },
  {
    "name": "郭子轩",
    "borrowTime": "2024-10-10",
    "bookName": "曾国藩.上.修订版",
    "author": "唐浩明著"
  },
  {
    "name": "郭子轩",
    "borrowTime": "2025-05-13",
    "bookName": "曾国藩.下.修订版",
    "author": "唐浩明著"
  },
  {
    "name": "郭旭",
    "borrowTime": "2023-10-16",
    "bookName": "山海经全鉴",
    "author": "(汉) 刘向, 刘歆编"
  },
  {
    "name": "郭曜玮",
    "borrowTime": "2025-03-06",
    "bookName": "电力机车检修",
    "author": "莫坚主编"
  },
  {
    "name": "郭曜诚",
    "borrowTime": "2024-04-26",
    "bookName": "铁路线路工",
    "author": "铁路职工岗位培训教材编审委员会编"
  },
  {
    "name": "郭曜诚",
    "borrowTime": "2024-04-26",
    "bookName": "铁路线路工",
    "author": "铁路职工岗位培训教材编审委员会编"
  },
  {
    "name": "郭永俊",
    "borrowTime": "2023-10-23",
    "bookName": "武破苍穹.1",
    "author": "雨辰宇著"
  },
  {
    "name": "郭永俊",
    "borrowTime": "2023-10-23",
    "bookName": "武破苍穹.1",
    "author": "雨辰宇著"
  },
  {
    "name": "郭津实",
    "borrowTime": "2023-09-19",
    "bookName": "喂食者协会",
    "author": "那多著"
  },
  {
    "name": "郭津实",
    "borrowTime": "2023-11-06",
    "bookName": "末日解剖",
    "author": "谢宗玉著"
  },
  {
    "name": "郭鑫宇",
    "borrowTime": "2023-11-07",
    "bookName": "谜案组",
    "author": "秦园著"
  },
  {
    "name": "郭鑫鑫",
    "borrowTime": "2023-09-20",
    "bookName": "人间失格",
    "author": "(日) 太宰治著"
  },
  {
    "name": "金明松",
    "borrowTime": "2023-10-31",
    "bookName": "心理罪,暗河",
    "author": "雷米作品"
  },
  {
    "name": "金明松",
    "borrowTime": "2023-10-31",
    "bookName": "心理罪,暗河",
    "author": "雷米作品"
  },
  {
    "name": "金畅",
    "borrowTime": "2023-10-08",
    "bookName": "平凡的世界",
    "author": "路遥著"
  },
  {
    "name": "金畅",
    "borrowTime": "2023-11-27",
    "bookName": "爱情是什么东西",
    "author": "刘海生著"
  },
  {
    "name": "金禹臣",
    "borrowTime": "2023-09-20",
    "bookName": "择偶",
    "author": "吕笔活著"
  },
  {
    "name": "金禹臣",
    "borrowTime": "2023-09-24",
    "bookName": "琉璃女人",
    "author": "孙彦良著"
  },
  {
    "name": "金站能",
    "borrowTime": "2023-10-08",
    "bookName": "蜀中盗志",
    "author": "李浩著"
  },
  {
    "name": "钟兴龙",
    "borrowTime": "2023-10-08",
    "bookName": "解忧杂货店",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "钟兴龙",
    "borrowTime": "2023-10-30",
    "bookName": "失落的大陆",
    "author": "陈钟强著"
  },
  {
    "name": "钟兴龙",
    "borrowTime": "2023-11-27",
    "bookName": "人类灭绝",
    "author": "高野和明"
  },
  {
    "name": "钟兴龙",
    "borrowTime": "2024-05-07",
    "bookName": "边城",
    "author": "沈从文[著]"
  },
  {
    "name": "钟兴龙",
    "borrowTime": "2024-05-24",
    "bookName": "上锁的房间",
    "author": "三岛由纪夫[著]"
  },
  {
    "name": "钦帅力",
    "borrowTime": "2023-09-18",
    "bookName": "Python基础教程",
    "author": "刘浪主编"
  },
  {
    "name": "钦帅力",
    "borrowTime": "2023-11-07",
    "bookName": "拜占庭帝国史:从拜占庭建城到君士坦丁堡陷落:公元前667年－公元1453年",
    "author": "(英) 查尔斯·欧曼著"
  },
  {
    "name": "钦帅力",
    "borrowTime": "2024-05-05",
    "bookName": "白银杰克",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "钦帅力",
    "borrowTime": "2024-05-10",
    "bookName": "微信小程序开发:从入门到项目实战:微课版",
    "author": "熊海东著"
  },
  {
    "name": "钦帅力",
    "borrowTime": "2024-09-12",
    "bookName": "审判",
    "author": "(奥)卡夫卡著"
  },
  {
    "name": "闫子轩",
    "borrowTime": "2025-05-15",
    "bookName": "偶然的创造",
    "author": "(意)埃莱娜·费兰特(Elena Ferrante)著"
  },
  {
    "name": "闫子轩",
    "borrowTime": "2025-06-03",
    "bookName": "偶然的创造",
    "author": "(意)埃莱娜·费兰特(Elena Ferrante)著"
  },
  {
    "name": "闫子轩",
    "borrowTime": "2025-07-02",
    "bookName": "偶然的创造",
    "author": "(意)埃莱娜·费兰特(Elena Ferrante)著"
  },
  {
    "name": "闫子轩",
    "borrowTime": "2025-12-23",
    "bookName": "忍不住想打扰你",
    "author": "bibi园长著"
  },
  {
    "name": "闫子轩",
    "borrowTime": "2025-12-23",
    "bookName": "世界十大古典喜剧故事",
    "author": "金金编著"
  },
  {
    "name": "闫子轩",
    "borrowTime": "2025-12-23",
    "bookName": "落日:日本帝国的灭亡",
    "author": "(美) 安德鲁·威斯特, 格里高里·莫特逊著"
  },
  {
    "name": "闫子轩",
    "borrowTime": "2026-03-19",
    "bookName": "时光电影院",
    "author": "幾米"
  },
  {
    "name": "闫子轩",
    "borrowTime": "2026-03-19",
    "bookName": "幾米经典绘本,地下铁:Q版",
    "author": "幾米"
  },
  {
    "name": "闫子轩",
    "borrowTime": "2026-03-21",
    "bookName": "趣谈:108个人们普遍忽略的问题",
    "author": "周沁编著"
  },
  {
    "name": "闫子轩",
    "borrowTime": "2026-03-25",
    "bookName": "小医生日记:药不能停啊",
    "author": "曾小兰著"
  },
  {
    "name": "闫子轩",
    "borrowTime": "2026-03-25",
    "bookName": "星空",
    "author": "几米"
  },
  {
    "name": "闫子轩",
    "borrowTime": "2026-03-25",
    "bookName": "走向春天的下午",
    "author": "几米"
  },
  {
    "name": "闫子轩",
    "borrowTime": "2026-03-31",
    "bookName": "那些古怪又让人忧心的问题",
    "author": "(美) 兰道尔·门罗著"
  },
  {
    "name": "闫虹羽",
    "borrowTime": "2023-10-19",
    "bookName": "工作细胞血小板.1",
    "author": "(日)柿原优子[著]"
  },
  {
    "name": "闫虹羽",
    "borrowTime": "2023-10-19",
    "bookName": "工作细胞血小板.2",
    "author": "(日)柿原优子[著]"
  },
  {
    "name": "陆伟",
    "borrowTime": "2024-09-03",
    "bookName": "黑案私探社",
    "author": "中雨作品"
  },
  {
    "name": "陆伟",
    "borrowTime": "2024-09-03",
    "bookName": "呼兰河传",
    "author": "萧红著"
  },
  {
    "name": "陆承龙",
    "borrowTime": "2023-09-05",
    "bookName": "平凡的世界",
    "author": "路遥著"
  },
  {
    "name": "陆方正",
    "borrowTime": "2023-11-16",
    "bookName": "聊斋志异",
    "author": "(清) 蒲松龄著"
  },
  {
    "name": "陈一凡",
    "borrowTime": "2024-05-08",
    "bookName": "法医档案.02,堕落天使.02,The fallen angels",
    "author": "戴西著"
  },
  {
    "name": "陈一凡",
    "borrowTime": "2024-05-08",
    "bookName": "D坂杀人事件",
    "author": "(日)江户川乱步著"
  },
  {
    "name": "陈付伟",
    "borrowTime": "2024-04-29",
    "bookName": "鬼吹灯",
    "author": "天下霸唱著"
  },
  {
    "name": "陈华卓",
    "borrowTime": "2023-12-04",
    "bookName": "毕业十年.下",
    "author": "徐翀著"
  },
  {
    "name": "陈华卓",
    "borrowTime": "2023-12-04",
    "bookName": "草莓:少女时代的我们",
    "author": "一草作品"
  },
  {
    "name": "陈华卓",
    "borrowTime": "2023-12-13",
    "bookName": "糟糕, 是心动的感觉",
    "author": "梓榆著"
  },
  {
    "name": "陈华卓",
    "borrowTime": "2023-12-13",
    "bookName": "糟糕, 是心动的感觉",
    "author": "梓榆著"
  },
  {
    "name": "陈华卓",
    "borrowTime": "2024-06-16",
    "bookName": "救赎.下",
    "author": "陆沉著"
  },
  {
    "name": "陈华卓",
    "borrowTime": "2024-06-16",
    "bookName": "救赎.上",
    "author": "陆沉著"
  },
  {
    "name": "陈华卓",
    "borrowTime": "2024-09-02",
    "bookName": "山海经,赤影传说.上",
    "author": "原创故事豆丁, 易小草, 耀之"
  },
  {
    "name": "陈华卓",
    "borrowTime": "2024-11-06",
    "bookName": "回不去的故乡",
    "author": "岳紫燕著"
  },
  {
    "name": "陈华卓",
    "borrowTime": "2024-11-06",
    "bookName": "情在何处",
    "author": "吴新财著"
  },
  {
    "name": "陈华卓",
    "borrowTime": "2024-11-06",
    "bookName": "情在何处",
    "author": "吴新财著"
  },
  {
    "name": "陈卓含",
    "borrowTime": "2023-09-19",
    "bookName": "白夜行.第2版",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "陈卓含",
    "borrowTime": "2023-09-19",
    "bookName": "虚无的十字架",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "陈子聪",
    "borrowTime": "2023-10-07",
    "bookName": "谋杀狄更斯.上",
    "author": "(美) 丹·西蒙斯著"
  },
  {
    "name": "陈子聪",
    "borrowTime": "2023-11-09",
    "bookName": "克苏鲁神话合集",
    "author": "(美) 霍华德·菲利普·洛夫克拉夫特著"
  },
  {
    "name": "陈宁",
    "borrowTime": "2024-11-26",
    "bookName": "简·爱",
    "author": "(英)夏洛特·勃朗特[著]"
  },
  {
    "name": "陈宇俊",
    "borrowTime": "2023-10-31",
    "bookName": "侯大利刑侦笔记.4,滴血破案",
    "author": "小桥老树著"
  },
  {
    "name": "陈家宇",
    "borrowTime": "2023-09-18",
    "bookName": "拉普拉斯的魔女",
    "author": "(日)东野圭吾著"
  },
  {
    "name": "陈尧",
    "borrowTime": "2023-10-17",
    "bookName": "连环罪:心理有诡",
    "author": "墨绿青苔著"
  },
  {
    "name": "陈尧",
    "borrowTime": "2023-11-24",
    "bookName": "原罪.3,拔云见日",
    "author": "一曲东风著"
  },
  {
    "name": "陈帅",
    "borrowTime": "2023-09-27",
    "bookName": "这个历史很有趣",
    "author": "于春梅著"
  },
  {
    "name": "陈思文",
    "borrowTime": "2023-09-20",
    "bookName": "幸存者",
    "author": "秦明著"
  },
  {
    "name": "陈斐",
    "borrowTime": "2024-09-09",
    "bookName": "丰乳肥臀",
    "author": "莫言 [著]"
  },
  {
    "name": "陈斐",
    "borrowTime": "2024-09-09",
    "bookName": "黄金瞳.2.2",
    "author": "打眼著"
  },
  {
    "name": "陈明",
    "borrowTime": "2023-10-08",
    "bookName": "天齐大陆",
    "author": "月下泷痕著"
  },
  {
    "name": "陈明",
    "borrowTime": "2023-10-08",
    "bookName": "斗罗大陆.第四部,终极斗罗.12",
    "author": "唐家三少著"
  },
  {
    "name": "陈柏潼",
    "borrowTime": "2023-11-27",
    "bookName": "撒野",
    "author": "巫哲著"
  },
  {
    "name": "陈欣雨",
    "borrowTime": "2023-09-13",
    "bookName": "黄金瞳.1.1",
    "author": "打眼著"
  },
  {
    "name": "陈欣雨",
    "borrowTime": "2023-09-16",
    "bookName": "撒野",
    "author": "巫哲著"
  },
  {
    "name": "陈欣雨",
    "borrowTime": "2023-10-07",
    "bookName": "轻狂",
    "author": "巫哲著"
  },
  {
    "name": "陈泊文",
    "borrowTime": "2023-11-28",
    "bookName": "九州缥缈录.Ⅲ.Ⅲ,天下名将",
    "author": "江南著"
  },
  {
    "name": "陈泊文",
    "borrowTime": "2023-11-28",
    "bookName": "九州缥缈录.Ⅳ.Ⅳ,辰月之征",
    "author": "江南著"
  },
  {
    "name": "陈泊文",
    "borrowTime": "2023-12-10",
    "bookName": "九州缥缈录.Ⅵ.Ⅵ,豹魂",
    "author": "江南著"
  },
  {
    "name": "陈泊文",
    "borrowTime": "2023-12-10",
    "bookName": "九州缥缈录.Ⅴ.Ⅴ,一生之盟",
    "author": "江南著"
  },
  {
    "name": "陈泊文",
    "borrowTime": "2024-09-06",
    "bookName": "天齐大陆",
    "author": "月下泷痕著"
  },
  {
    "name": "陈泊文",
    "borrowTime": "2024-11-06",
    "bookName": "山海经传说.1,异兽记",
    "author": "刀螂著"
  },
  {
    "name": "陈炳丞",
    "borrowTime": "2023-09-10",
    "bookName": "特案科:刑警手记.上",
    "author": "风雨如书著"
  },
  {
    "name": "陈玉明",
    "borrowTime": "2023-12-07",
    "bookName": "佛头遗案.第2版",
    "author": "楮实子著"
  },
  {
    "name": "陈禹鑫",
    "borrowTime": "2023-09-07",
    "bookName": "诡域迷局:神鹰王冠",
    "author": "诸葛宇聪作品"
  },
  {
    "name": "陈禹鑫",
    "borrowTime": "2023-09-07",
    "bookName": "狼牙.修订版",
    "author": "刘猛著"
  },
  {
    "name": "陈禹鑫",
    "borrowTime": "2023-09-16",
    "bookName": "痕迹",
    "author": "毕蔷著"
  },
  {
    "name": "陈禹鑫",
    "borrowTime": "2023-09-16",
    "bookName": "诡域迷局:神鹰王冠",
    "author": "诸葛宇聪作品"
  },
  {
    "name": "陈禹鑫",
    "borrowTime": "2023-09-22",
    "bookName": "第一信号",
    "author": "彭海燕著"
  },
  {
    "name": "陈禹鑫",
    "borrowTime": "2023-10-08",
    "bookName": "犯罪心理档案.第四季",
    "author": "刚雪印著"
  },
  {
    "name": "陈禹鑫",
    "borrowTime": "2023-10-08",
    "bookName": "诡域迷局:神鹰王冠",
    "author": "诸葛宇聪作品"
  },
  {
    "name": "陈禹鑫",
    "borrowTime": "2024-05-16",
    "bookName": "法医档案.04,终结之语.04,The language of the end",
    "author": "戴西著"
  },
  {
    "name": "陈禹鑫",
    "borrowTime": "2024-05-16",
    "bookName": "法医档案.03,迟来真相.03,Truth comes late",
    "author": "戴西著"
  },
  {
    "name": "陈禹鑫",
    "borrowTime": "2024-11-30",
    "bookName": "三体.Ⅱ,黑暗森林",
    "author": "刘慈欣著"
  },
  {
    "name": "陈禹鑫",
    "borrowTime": "2025-03-24",
    "bookName": "富爸爸成功创业的10堂必修课",
    "author": "(美)罗伯特·清崎著"
  },
  {
    "name": "陈禹铭",
    "borrowTime": "2024-05-14",
    "bookName": "言叶之庭:官方分镜画集:storyboard by Makoto Shinkai",
    "author": "(日)新海诚著"
  },
  {
    "name": "陈肖诺",
    "borrowTime": "2025-03-17",
    "bookName": "美国反对美国",
    "author": "王泸宁著"
  },
  {
    "name": "陈艳来",
    "borrowTime": "2023-10-15",
    "bookName": "恶魔之地:洛夫克拉夫特乡",
    "author": "(美) 马特·拉夫著"
  },
  {
    "name": "陈艳飞",
    "borrowTime": "2023-11-02",
    "bookName": "守夜者",
    "author": "法医秦明著"
  },
  {
    "name": "陈霖阳",
    "borrowTime": "2023-09-24",
    "bookName": "三国志",
    "author": "(晋)陈寿著"
  },
  {
    "name": "陈靖玮",
    "borrowTime": "2023-09-20",
    "bookName": "天气之子",
    "author": "(日) 新海诚著"
  },
  {
    "name": "陈鹏旭",
    "borrowTime": "2023-10-18",
    "bookName": "吞噬星空:典藏版.1",
    "author": "我吃西红柿著"
  },
  {
    "name": "陈鹏旭",
    "borrowTime": "2025-05-21",
    "bookName": "接触网事故案例",
    "author": "赵良田编"
  },
  {
    "name": "陈鹏旭",
    "borrowTime": "2025-06-11",
    "bookName": "接触网事故案例",
    "author": "赵良田编"
  },
  {
    "name": "陈麒",
    "borrowTime": "2025-04-17",
    "bookName": "LKJ操作使用手册",
    "author": "《LKJ操作使用手册》编委会编"
  },
  {
    "name": "陶怀秀",
    "borrowTime": "2023-12-06",
    "bookName": "契约魔鞋.1",
    "author": "CHRY编绘"
  },
  {
    "name": "陶怀秀",
    "borrowTime": "2024-09-04",
    "bookName": "Photoshop CS5平面广告设计与印前技术",
    "author": "新知互动编著"
  },
  {
    "name": "霍广博",
    "borrowTime": "2023-11-03",
    "bookName": "世界简史",
    "author": "何炳松著"
  },
  {
    "name": "霍广博",
    "borrowTime": "2023-11-05",
    "bookName": "气冲星河.1,少年无双",
    "author": "犁天著"
  },
  {
    "name": "靳旗胜",
    "borrowTime": "2024-11-14",
    "bookName": "尸变图鉴:自然环境下的尸体变化",
    "author": "陈禄仕主编"
  },
  {
    "name": "靳旗胜",
    "borrowTime": "2025-03-12",
    "bookName": "余罪:我的刑侦笔记.4:一个传奇警察和毒贩、悍匪、黑道大佬的交锋实录",
    "author": "常书欣著"
  },
  {
    "name": "靳旗胜",
    "borrowTime": "2025-03-16",
    "bookName": "焊工自学·考证·上岗一本通",
    "author": "邱言龙，雷振国，聂正斌编著"
  },
  {
    "name": "靳旗胜",
    "borrowTime": "2025-10-05",
    "bookName": "世界上最神奇的24堂课",
    "author": "(美)查尔斯·哈奈尔著"
  },
  {
    "name": "鞠源",
    "borrowTime": "2023-10-18",
    "bookName": "牧野诡事",
    "author": "天下霸唱著"
  },
  {
    "name": "鞠源",
    "borrowTime": "2023-10-19",
    "bookName": "谜小说.2010年第3辑,秘密",
    "author": "蔡骏主编"
  },
  {
    "name": "鞠源",
    "borrowTime": "2023-10-19",
    "bookName": "隐形罪恶",
    "author": "库玉祥著"
  },
  {
    "name": "鞠源",
    "borrowTime": "2023-10-30",
    "bookName": "水浒传.插图版",
    "author": "(明) 施耐庵著"
  },
  {
    "name": "鞠源",
    "borrowTime": "2023-10-30",
    "bookName": "水浒传.插图版",
    "author": "(明) 施耐庵著"
  },
  {
    "name": "鞠源",
    "borrowTime": "2023-11-12",
    "bookName": "酒吧长谈",
    "author": "(秘)马里奥·巴尔加斯·略萨著"
  },
  {
    "name": "韦代海",
    "borrowTime": "2023-10-07",
    "bookName": "祝福",
    "author": "鲁迅著"
  },
  {
    "name": "韦代海",
    "borrowTime": "2024-05-29",
    "bookName": "蛙",
    "author": "莫言[著]"
  },
  {
    "name": "韩一诺",
    "borrowTime": "2023-09-18",
    "bookName": "守夜者.4,天演:大结局",
    "author": "法医秦明著"
  },
  {
    "name": "韩东燃",
    "borrowTime": "2023-09-18",
    "bookName": "中国怪谈",
    "author": "赵志明著"
  },
  {
    "name": "韩亿",
    "borrowTime": "2023-10-15",
    "bookName": "活着",
    "author": "余华著"
  },
  {
    "name": "韩佳良",
    "borrowTime": "2023-11-17",
    "bookName": "诡案组.2.Season two.第2季",
    "author": "求无欲著"
  },
  {
    "name": "韩佳良",
    "borrowTime": "2024-09-02",
    "bookName": "张作霖全传",
    "author": "李洪文著"
  },
  {
    "name": "韩佳良",
    "borrowTime": "2024-10-13",
    "bookName": "尸案调查科",
    "author": "九滴水著"
  },
  {
    "name": "韩佳良",
    "borrowTime": "2024-11-21",
    "bookName": "黑铁时代",
    "author": "王小波著"
  },
  {
    "name": "韩博名",
    "borrowTime": "2023-09-19",
    "bookName": "气冲星河.1,少年无双",
    "author": "犁天著"
  },
  {
    "name": "韩卫齐",
    "borrowTime": "2023-10-07",
    "bookName": "亡者永生",
    "author": "那多著"
  },
  {
    "name": "韩尚达",
    "borrowTime": "2023-10-11",
    "bookName": "人间草木",
    "author": "汪曾祺著"
  },
  {
    "name": "韩尚达",
    "borrowTime": "2024-09-12",
    "bookName": "心理罪,暗河",
    "author": "雷米作品"
  },
  {
    "name": "韩心语",
    "borrowTime": "2023-09-06",
    "bookName": "科幻机甲动漫人物角色设定技法:机械浪漫",
    "author": "绘月工坊主编"
  },
  {
    "name": "韩心语",
    "borrowTime": "2024-04-28",
    "bookName": "三体.Ⅱ,黑暗森林",
    "author": "刘慈欣著"
  },
  {
    "name": "韩心语",
    "borrowTime": "2024-04-28",
    "bookName": "罪全书.6",
    "author": "蜘蛛著"
  },
  {
    "name": "韩斯丞",
    "borrowTime": "2023-10-08",
    "bookName": "幸存者",
    "author": "法医秦明著"
  },
  {
    "name": "韩斯丞",
    "borrowTime": "2023-10-08",
    "bookName": "守夜者",
    "author": "法医秦明著"
  },
  {
    "name": "韩斯丞",
    "borrowTime": "2023-10-30",
    "bookName": "黄金瞳.3.3",
    "author": "打眼著"
  },
  {
    "name": "韩斯丞",
    "borrowTime": "2023-10-30",
    "bookName": "黄金瞳.2.2",
    "author": "打眼著"
  },
  {
    "name": "韩斯丞",
    "borrowTime": "2023-10-30",
    "bookName": "黄金瞳.1.1",
    "author": "打眼著"
  },
  {
    "name": "韩斯丞",
    "borrowTime": "2023-11-16",
    "bookName": "最前线:中国共产党抗战图像志:the communist party of China during the war of resistance against Japanese aggression",
    "author": "主编高初, 晋永权"
  },
  {
    "name": "韩晓宁",
    "borrowTime": "2025-09-29",
    "bookName": "六级词汇词根+联想记忆法:乱序版",
    "author": "俞敏洪编著"
  },
  {
    "name": "韩有帅",
    "borrowTime": "2023-10-10",
    "bookName": "明朝那些事儿.第陆部,帝国，山雨欲来",
    "author": "当年明月著"
  },
  {
    "name": "韩浩伟",
    "borrowTime": "2023-11-09",
    "bookName": "世界经典悬疑故事.超值彩图版",
    "author": "白虹主编"
  },
  {
    "name": "韩浩伟",
    "borrowTime": "2024-04-28",
    "bookName": "民调局异闻录最终篇章.第一卷.1,广元明鉴",
    "author": "耳东水寿著"
  },
  {
    "name": "韩浩伟",
    "borrowTime": "2024-11-04",
    "bookName": "盗墓笔记.2,秦岭神树",
    "author": "南派三叔著"
  },
  {
    "name": "韩浩伟",
    "borrowTime": "2024-11-04",
    "bookName": "黄金瞳.2.2",
    "author": "打眼著"
  },
  {
    "name": "韩浩伟",
    "borrowTime": "2024-11-04",
    "bookName": "黄金瞳.3.3",
    "author": "打眼著"
  },
  {
    "name": "韩浩伟",
    "borrowTime": "2024-11-13",
    "bookName": "黄金瞳.1.1",
    "author": "打眼著"
  },
  {
    "name": "韩淇",
    "borrowTime": "2023-09-26",
    "bookName": "女法医:温柔的解剖",
    "author": "明菲著"
  },
  {
    "name": "韩羽飞",
    "borrowTime": "2023-09-20",
    "bookName": "诡案组外传",
    "author": "求无欲著"
  },
  {
    "name": "韩羽飞",
    "borrowTime": "2023-10-16",
    "bookName": "诡案组,蛇指影魔",
    "author": "求无欲著"
  },
  {
    "name": "韩翔宇",
    "borrowTime": "2023-11-09",
    "bookName": "丰乳肥臀",
    "author": "莫言 [著]"
  },
  {
    "name": "韩翔宇",
    "borrowTime": "2024-05-07",
    "bookName": "蛙",
    "author": "莫言[著]"
  },
  {
    "name": "韩翔宇",
    "borrowTime": "2024-05-07",
    "bookName": "心理大师",
    "author": "钟宇作品"
  },
  {
    "name": "韩翔宇",
    "borrowTime": "2024-05-25",
    "bookName": "子夜.3版",
    "author": "茅盾著"
  },
  {
    "name": "韩翔宇",
    "borrowTime": "2024-06-16",
    "bookName": "郁达夫小说全集",
    "author": "郁达夫著"
  },
  {
    "name": "韩翔宇",
    "borrowTime": "2024-06-16",
    "bookName": "郁达夫小说全集",
    "author": "郁达夫著"
  },
  {
    "name": "韩翔宇",
    "borrowTime": "2024-09-12",
    "bookName": "尸案调查科",
    "author": "九滴水著"
  },
  {
    "name": "韩翔宇",
    "borrowTime": "2024-09-12",
    "bookName": "尸案调查科.第二季.2,一念深渊",
    "author": "九滴水著"
  },
  {
    "name": "韩翔宇",
    "borrowTime": "2024-09-12",
    "bookName": "尸案调查科.第二季.1,罪恶根源",
    "author": "九滴水著"
  },
  {
    "name": "韩金龙",
    "borrowTime": "2023-11-10",
    "bookName": "你看完不敢睡, 看了还想看的悬疑小说.Ⅰ",
    "author": "白虹主编"
  },
  {
    "name": "韩金龙",
    "borrowTime": "2023-11-10",
    "bookName": "女法医手记之破译密码",
    "author": "刘真著"
  },
  {
    "name": "韩青辰",
    "borrowTime": "2023-10-07",
    "bookName": "首席医官.3",
    "author": "谢荣鹏著"
  },
  {
    "name": "韩青辰",
    "borrowTime": "2023-10-09",
    "bookName": "原罪.2,暗夜使徒",
    "author": "一曲东风著"
  },
  {
    "name": "韩青辰",
    "borrowTime": "2023-10-16",
    "bookName": "诡案组.第2季.4,六臂罗刹:大结局",
    "author": "求无欲著"
  },
  {
    "name": "韩青辰",
    "borrowTime": "2023-10-16",
    "bookName": "地狱公寓.3",
    "author": "董协著"
  },
  {
    "name": "韩青辰",
    "borrowTime": "2023-10-17",
    "bookName": "诡计设计师:完美罪恶",
    "author": "张嘉骏作品"
  },
  {
    "name": "韩青辰",
    "borrowTime": "2023-10-23",
    "bookName": "刑侦一科.上",
    "author": "黑羽时晴著"
  },
  {
    "name": "韩青辰",
    "borrowTime": "2023-10-30",
    "bookName": "女法医手记之破译密码",
    "author": "刘真著"
  },
  {
    "name": "韩青辰",
    "borrowTime": "2023-11-14",
    "bookName": "灵魂追凶",
    "author": "向林著"
  },
  {
    "name": "顾可毅",
    "borrowTime": "2023-09-25",
    "bookName": "山海经,赤影传说.上",
    "author": "原创故事豆丁, 易小草, 耀之"
  },
  {
    "name": "顾可毅",
    "borrowTime": "2023-09-25",
    "bookName": "山海经,赤影传说.下",
    "author": "原创故事豆丁, 易小草, 耀之"
  },
  {
    "name": "顾可毅",
    "borrowTime": "2023-10-06",
    "bookName": "超新星纪元",
    "author": "刘慈欣著"
  },
  {
    "name": "马一方",
    "borrowTime": "2023-11-21",
    "bookName": "九州缥缈录.Ⅰ,蛮荒.修订版",
    "author": "江南著"
  },
  {
    "name": "马一方",
    "borrowTime": "2023-11-21",
    "bookName": "九州缥缈录.Ⅱ.Ⅱ,苍云古齿",
    "author": "江南著"
  },
  {
    "name": "马一方",
    "borrowTime": "2023-12-11",
    "bookName": "龙族.Ⅳ,奥丁之渊",
    "author": "江南著"
  },
  {
    "name": "马一方",
    "borrowTime": "2023-12-11",
    "bookName": "九州缥缈录.Ⅲ.Ⅲ,天下名将",
    "author": "江南著"
  },
  {
    "name": "马一方",
    "borrowTime": "2024-05-09",
    "bookName": "九州缥缈录.Ⅲ.Ⅲ,天下名将",
    "author": "江南著"
  },
  {
    "name": "马一方",
    "borrowTime": "2024-09-24",
    "bookName": "九州缥缈录.Ⅴ.Ⅴ,一生之盟",
    "author": "江南著"
  },
  {
    "name": "马一方",
    "borrowTime": "2024-09-24",
    "bookName": "九州缥缈录.Ⅳ.Ⅳ,辰月之征",
    "author": "江南著"
  },
  {
    "name": "马佳鑫",
    "borrowTime": "2023-11-13",
    "bookName": "新诡案组",
    "author": "求无尘著"
  },
  {
    "name": "马佳鑫",
    "borrowTime": "2023-11-13",
    "bookName": "撒野",
    "author": "巫哲著"
  },
  {
    "name": "马佳鑫",
    "borrowTime": "2024-05-25",
    "bookName": "四世同堂.上",
    "author": "老舍著"
  },
  {
    "name": "马佳鑫",
    "borrowTime": "2024-05-25",
    "bookName": "四世同堂.下",
    "author": "老舍著"
  },
  {
    "name": "马佳鑫",
    "borrowTime": "2024-06-16",
    "bookName": "路过风景路过你",
    "author": "沈嘉柯著"
  },
  {
    "name": "马佳鑫",
    "borrowTime": "2024-09-12",
    "bookName": "字证其罪.上",
    "author": "陈悦蔚著"
  },
  {
    "name": "马佳鑫",
    "borrowTime": "2024-09-12",
    "bookName": "星坟:望古神话",
    "author": "天使奥斯卡著"
  },
  {
    "name": "马佳鑫",
    "borrowTime": "2024-11-04",
    "bookName": "痕迹",
    "author": "毕蔷著"
  },
  {
    "name": "马俊杰",
    "borrowTime": "2023-10-29",
    "bookName": "赘婿.2,心如猛虎",
    "author": "愤怒的香蕉著"
  },
  {
    "name": "马发帅",
    "borrowTime": "2025-12-02",
    "bookName": "铁道概论",
    "author": "中国国家铁路集团有限公司运输部主编"
  },
  {
    "name": "马天赐",
    "borrowTime": "2023-11-07",
    "bookName": "消失的证人",
    "author": "吕旭著"
  },
  {
    "name": "马天赐",
    "borrowTime": "2024-04-28",
    "bookName": "盗墓笔记.5,谜海归巢",
    "author": "南派三叔著"
  },
  {
    "name": "马天赐",
    "borrowTime": "2024-05-09",
    "bookName": "受戒",
    "author": "汪曾祺著"
  },
  {
    "name": "马志宇",
    "borrowTime": "2023-09-18",
    "bookName": "天之炽.1.1,红龙的归来",
    "author": "江南作品"
  },
  {
    "name": "马志宇",
    "borrowTime": "2023-09-18",
    "bookName": "超能力侦探事务所",
    "author": "陆烨华著"
  },
  {
    "name": "马志宇",
    "borrowTime": "2023-09-18",
    "bookName": "黑客横行",
    "author": "刘慈欣等著"
  },
  {
    "name": "马志宇",
    "borrowTime": "2023-09-27",
    "bookName": "科幻机甲动漫人物角色设定技法:机械浪漫",
    "author": "绘月工坊主编"
  },
  {
    "name": "马志宇",
    "borrowTime": "2023-10-20",
    "bookName": "轻狂",
    "author": "巫哲著"
  },
  {
    "name": "马方恒",
    "borrowTime": "2025-03-11",
    "bookName": "红岩.3版",
    "author": "罗广斌，杨益言著"
  },
  {
    "name": "马方恒",
    "borrowTime": "2025-10-10",
    "bookName": "偷窥者",
    "author": "法医秦明著"
  },
  {
    "name": "马梓豪",
    "borrowTime": "2023-09-20",
    "bookName": "11字谜案",
    "author": "(日) 东野圭吾著"
  },
  {
    "name": "马梓豪",
    "borrowTime": "2023-10-21",
    "bookName": "怪诞实录.第二季",
    "author": "凤仪著"
  },
  {
    "name": "马梓豪",
    "borrowTime": "2023-11-07",
    "bookName": "怪诞实录.第二季",
    "author": "凤仪著"
  },
  {
    "name": "马洪滨",
    "borrowTime": "2023-09-27",
    "bookName": "守夜者.3,生死盲点",
    "author": "法医秦明著"
  },
  {
    "name": "马洪滨",
    "borrowTime": "2023-11-15",
    "bookName": "克苏鲁神话合集",
    "author": "(美) 霍华德·菲利普·洛夫克拉夫特著"
  },
  {
    "name": "马洪滨",
    "borrowTime": "2023-11-16",
    "bookName": "诡秘之主.1,绯红之月",
    "author": "爱潜水的乌贼著"
  },
  {
    "name": "马洪滨",
    "borrowTime": "2024-06-13",
    "bookName": "云边有个小卖部",
    "author": "张嘉佳著"
  },
  {
    "name": "马英茗",
    "borrowTime": "2023-11-05",
    "bookName": "武破苍穹.1",
    "author": "雨辰宇著"
  },
  {
    "name": "马英茗",
    "borrowTime": "2023-11-05",
    "bookName": "武破苍穹.2",
    "author": "雨辰宇著"
  },
  {
    "name": "马英茗",
    "borrowTime": "2023-11-05",
    "bookName": "御剑天下",
    "author": "辰阳著"
  },
  {
    "name": "马赫遥",
    "borrowTime": "2024-05-12",
    "bookName": "尸案调查科.第二季.2,一念深渊",
    "author": "九滴水著"
  },
  {
    "name": "马赫阳",
    "borrowTime": "2023-09-12",
    "bookName": "希区柯克悬念故事集",
    "author": "(美) 阿尔弗雷德·希区柯克著"
  },
  {
    "name": "马赫阳",
    "borrowTime": "2023-10-11",
    "bookName": "元尊.13,九域论战",
    "author": "天蚕土豆著"
  },
  {
    "name": "马赫阳",
    "borrowTime": "2024-04-28",
    "bookName": "斗罗大陆.第四部,终极斗罗.16",
    "author": "唐家三少著"
  },
  {
    "name": "马赫阳",
    "borrowTime": "2024-05-06",
    "bookName": "斗罗大陆.第二部,绝世唐门.23",
    "author": "唐家三少著"
  },
  {
    "name": "马赫阳",
    "borrowTime": "2024-05-06",
    "bookName": "斗罗大陆.第二部,绝世唐门.24",
    "author": "唐家三少著"
  },
  {
    "name": "马赫阳",
    "borrowTime": "2024-05-10",
    "bookName": "怪物同学会",
    "author": "全球华语科幻星云奖组委会编"
  },
  {
    "name": "马赫阳",
    "borrowTime": "2024-05-10",
    "bookName": "绝色大陆.上",
    "author": "林家成作品"
  },
  {
    "name": "马赫阳",
    "borrowTime": "2024-05-12",
    "bookName": "绝色大陆.下",
    "author": "林家成作品"
  },
  {
    "name": "马赫阳",
    "borrowTime": "2024-05-12",
    "bookName": "绝色大陆.中",
    "author": "林家成作品"
  },
  {
    "name": "马赫阳",
    "borrowTime": "2024-06-16",
    "bookName": "诡秘之主.1,绯红之月",
    "author": "爱潜水的乌贼著"
  },
  {
    "name": "马铭俊",
    "borrowTime": "2024-05-07",
    "bookName": "读心诡探",
    "author": "风雨如书著"
  },
  {
    "name": "马铭晨",
    "borrowTime": "2023-10-15",
    "bookName": "天气之子",
    "author": "(日) 新海诚著"
  },
  {
    "name": "马驰",
    "borrowTime": "2023-10-17",
    "bookName": "古罗马神话故事",
    "author": "马兰主编"
  },
  {
    "name": "马驰",
    "borrowTime": "2024-06-04",
    "bookName": "哈利·波特与火焰杯",
    "author": "(英) J.K.罗琳著"
  },
  {
    "name": "马麟函",
    "borrowTime": "2023-09-10",
    "bookName": "朱威讲诡异案之诡异日记",
    "author": "朱威著"
  },
  {
    "name": "马麟函",
    "borrowTime": "2023-10-31",
    "bookName": "我家有个猫仆大人.[1]",
    "author": "卷啕啕"
  },
  {
    "name": "高佳东",
    "borrowTime": "2023-11-27",
    "bookName": "深度撞击",
    "author": "刘慈欣等著"
  },
  {
    "name": "高佳东",
    "borrowTime": "2023-11-27",
    "bookName": "末世浩劫",
    "author": "刘慈欣等著"
  },
  {
    "name": "高佳东",
    "borrowTime": "2023-11-27",
    "bookName": "星际移民",
    "author": "刘慈欣等著"
  },
  {
    "name": "高子墨",
    "borrowTime": "2023-09-18",
    "bookName": "失落的文明",
    "author": "马兰主编"
  },
  {
    "name": "高子墨",
    "borrowTime": "2023-11-30",
    "bookName": "意大利古建筑散记",
    "author": "陈志华著"
  },
  {
    "name": "高子墨",
    "borrowTime": "2024-06-30",
    "bookName": "文学回忆录:1989-1944.上",
    "author": "木心讲述"
  },
  {
    "name": "高子墨",
    "borrowTime": "2024-11-18",
    "bookName": "文学回忆录:1989-1944.下",
    "author": "木心讲述"
  },
  {
    "name": "高子墨",
    "borrowTime": "2024-11-18",
    "bookName": "哲学简史",
    "author": "(英)伯特兰·罗素(Bertrand Russell)著"
  },
  {
    "name": "高子墨",
    "borrowTime": "2024-11-18",
    "bookName": "中国哲学简史:彩图本",
    "author": "冯友兰著"
  },
  {
    "name": "高子墨",
    "borrowTime": "2024-11-23",
    "bookName": "人生的意义",
    "author": "(英)特里·伊格尔顿著"
  },
  {
    "name": "高子墨",
    "borrowTime": "2025-03-27",
    "bookName": "一个或所有问题:一份哲学草稿.修订本",
    "author": "赵汀阳著"
  },
  {
    "name": "高子墨",
    "borrowTime": "2025-03-27",
    "bookName": "纯粹理性批判",
    "author": "(德)康德(Immanuel Kant)著"
  },
  {
    "name": "高子墨",
    "borrowTime": "2025-03-27",
    "bookName": "休谟",
    "author": "(英)A. J.艾耶尔著"
  },
  {
    "name": "高子墨",
    "borrowTime": "2025-05-26",
    "bookName": "纯粹理性批判",
    "author": "(德)康德(Immanuel Kant)著"
  },
  {
    "name": "高安强",
    "borrowTime": "2023-11-13",
    "bookName": "十指相扣",
    "author": "林丛著"
  },
  {
    "name": "高峰",
    "borrowTime": "2023-10-22",
    "bookName": "文化未解之谜",
    "author": "马兰主编"
  },
  {
    "name": "高峰",
    "borrowTime": "2024-06-06",
    "bookName": "龙族.Ⅰ,火之晨曦",
    "author": "江南著"
  },
  {
    "name": "高悦",
    "borrowTime": "2024-05-25",
    "bookName": "老骥伏枥",
    "author": "杨小春著"
  },
  {
    "name": "高悦",
    "borrowTime": "2024-05-25",
    "bookName": "艾芜全集.第十卷,中篇小说",
    "author": "艾芜"
  },
  {
    "name": "高悦",
    "borrowTime": "2025-04-10",
    "bookName": "明朝那些事儿.第1部,朱元璋：从和尚到皇帝.[增补版]",
    "author": "当年明月著"
  },
  {
    "name": "高悦",
    "borrowTime": "2025-04-15",
    "bookName": "自我与本我:精装典藏版",
    "author": "(奥)西格蒙德·弗洛伊德著"
  },
  {
    "name": "高悦",
    "borrowTime": "2025-05-14",
    "bookName": "自我与本我:精装典藏版",
    "author": "(奥)西格蒙德·弗洛伊德著"
  },
  {
    "name": "高悦",
    "borrowTime": "2025-05-14",
    "bookName": "明朝那些事儿.第1部,朱元璋：从和尚到皇帝.[增补版]",
    "author": "当年明月著"
  },
  {
    "name": "高悦",
    "borrowTime": "2025-10-12",
    "bookName": "我、脑子和粉红色的咨询师:33篇心理咨询漫画，教你停止和脑子的内在“战争”",
    "author": "毛毛毛著"
  },
  {
    "name": "高悦",
    "borrowTime": "2025-12-03",
    "bookName": "感恩的力量",
    "author": "(美)A. J. 雅各布斯(A. J. Jacobs)著"
  },
  {
    "name": "高文浩",
    "borrowTime": "2023-11-18",
    "bookName": "白色橄榄树",
    "author": "玖月晞著"
  },
  {
    "name": "高文浩",
    "borrowTime": "2023-12-11",
    "bookName": "匆匆那年.上",
    "author": "九夜茴著"
  },
  {
    "name": "高文浩",
    "borrowTime": "2023-12-11",
    "bookName": "匆匆那年.下",
    "author": "九夜茴著"
  },
  {
    "name": "高明全",
    "borrowTime": "2025-03-23",
    "bookName": "决定上限的是你的格局和情商",
    "author": "连山著"
  },
  {
    "name": "高明全",
    "borrowTime": "2025-05-06",
    "bookName": "电力机车检修",
    "author": "莫坚主编"
  },
  {
    "name": "高明全",
    "borrowTime": "2026-03-14",
    "bookName": "底线思维",
    "author": "俞兰著"
  },
  {
    "name": "高明全",
    "borrowTime": "2026-03-14",
    "bookName": "羊皮卷",
    "author": "(美) 拿破仑·希尔等编著"
  },
  {
    "name": "高明全",
    "borrowTime": "2026-03-14",
    "bookName": "受益一生的鬼谷子智慧.插图升级版",
    "author": "宋犀堃编著"
  },
  {
    "name": "高明全",
    "borrowTime": "2026-03-14",
    "bookName": "我们要赢的, 是自己",
    "author": "思小妞著"
  },
  {
    "name": "高明全",
    "borrowTime": "2026-03-14",
    "bookName": "格局:大胆识 大格局 大胸怀",
    "author": "张晗正编著"
  },
  {
    "name": "高梓洋",
    "borrowTime": "2023-10-07",
    "bookName": "沧元图.1",
    "author": "我吃西红柿著"
  },
  {
    "name": "高梓洋",
    "borrowTime": "2023-10-10",
    "bookName": "盘龙.Ⅱ,龙血之怒",
    "author": "我吃西红柿作品"
  },
  {
    "name": "高梓洋",
    "borrowTime": "2023-10-23",
    "bookName": "斗罗大陆.第二部,绝世唐门.24",
    "author": "唐家三少著"
  },
  {
    "name": "高梓洋",
    "borrowTime": "2023-10-23",
    "bookName": "雪中悍刀行.2,白马出凉州",
    "author": "烽火戏诸侯著"
  },
  {
    "name": "高梓洋",
    "borrowTime": "2023-10-23",
    "bookName": "九州缥缈录.Ⅰ,蛮荒.修订版",
    "author": "江南著"
  },
  {
    "name": "高爽",
    "borrowTime": "2023-09-13",
    "bookName": "清朝绝对很有趣",
    "author": "东篱子编著"
  },
  {
    "name": "高爽",
    "borrowTime": "2023-11-14",
    "bookName": "盗墓笔记,秦岭神树",
    "author": "南派三叔著"
  },
  {
    "name": "高爽",
    "borrowTime": "2024-05-13",
    "bookName": "摸金传人.5,湘西蛊术",
    "author": "罗晓著"
  },
  {
    "name": "高英铭",
    "borrowTime": "2023-10-12",
    "bookName": "斗罗大陆.第二部,绝世唐门.24",
    "author": "唐家三少著"
  },
  {
    "name": "高英铭",
    "borrowTime": "2023-10-12",
    "bookName": "斗罗大陆.第二部,绝世唐门.23",
    "author": "唐家三少著"
  },
  {
    "name": "高英铭",
    "borrowTime": "2023-10-30",
    "bookName": "元尊.13,九域论战",
    "author": "天蚕土豆著"
  },
  {
    "name": "高英铭",
    "borrowTime": "2023-11-01",
    "bookName": "斗罗大陆.第四部,终极斗罗.14",
    "author": "唐家三少著"
  },
  {
    "name": "高英铭",
    "borrowTime": "2023-11-05",
    "bookName": "斗罗大陆.第四部,终极斗罗.12",
    "author": "唐家三少著"
  },
  {
    "name": "高诚远",
    "borrowTime": "2023-09-19",
    "bookName": "沧元图.1",
    "author": "我吃西红柿著"
  },
  {
    "name": "高责与",
    "borrowTime": "2023-11-21",
    "bookName": "仙灵图谱.1,仙踪影",
    "author": "云芨著"
  },
  {
    "name": "高飞飞",
    "borrowTime": "2025-05-24",
    "bookName": "电力机车控制.第2版",
    "author": "付娟主编"
  },
  {
    "name": "高飞飞",
    "borrowTime": "2025-05-26",
    "bookName": "电力机车控制:M+Book版",
    "author": "李联福，于彦良，李辰佑主编"
  },
  {
    "name": "魏欣芮",
    "borrowTime": "2024-05-14",
    "bookName": "尸体会说话:日本首席法医的法医学手记",
    "author": "(日)上野正彦著"
  },
  {
    "name": "魏欣芮",
    "borrowTime": "2024-05-14",
    "bookName": "告诉我你是怎么死的:女法医勘验实录",
    "author": "(美)朱迪·梅勒涅克，(美)托马斯·J. 米切尔著"
  },
  {
    "name": "魏欣芮",
    "borrowTime": "2024-05-14",
    "bookName": "犯罪心理学",
    "author": "(美) Curt R. Bartol, Anne M. Bartol著"
  },
  {
    "name": "魏煜航",
    "borrowTime": "2023-09-26",
    "bookName": "秦墟·望古神话",
    "author": "月关著"
  },
  {
    "name": "魏煜航",
    "borrowTime": "2023-10-20",
    "bookName": "异域奇谈,泰国卷",
    "author": "古潼著"
  },
  {
    "name": "魏煜航",
    "borrowTime": "2023-10-20",
    "bookName": "舌尖上的私房菜",
    "author": "石磊著"
  },
  {
    "name": "魏煜航",
    "borrowTime": "2023-10-20",
    "bookName": "刺客",
    "author": "刘猛作品"
  },
  {
    "name": "鲍春旭",
    "borrowTime": "2024-09-21",
    "bookName": "日本民间故事.第三季",
    "author": "(日) 田中贡太郎等著"
  },
  {
    "name": "麻炳轩",
    "borrowTime": "2023-11-10",
    "bookName": "哑舍.壹",
    "author": "玄色著"
  },
  {
    "name": "黄唯恩",
    "borrowTime": "2023-12-21",
    "bookName": "幸存者",
    "author": "法医秦明著"
  },
  {
    "name": "黄心蕊",
    "borrowTime": "2023-10-08",
    "bookName": "撒野",
    "author": "巫哲著"
  },
  {
    "name": "黄心蕊",
    "borrowTime": "2023-10-20",
    "bookName": "女法医手记之破译密码",
    "author": "刘真著"
  },
  {
    "name": "黄志涛",
    "borrowTime": "2023-10-07",
    "bookName": "怪诞实录.第二季",
    "author": "凤仪著"
  },
  {
    "name": "黄志涛",
    "borrowTime": "2023-10-21",
    "bookName": "风声",
    "author": "麦家"
  },
  {
    "name": "黄志涛",
    "borrowTime": "2024-05-24",
    "bookName": "诡秘之主.1,绯红之月",
    "author": "爱潜水的乌贼著"
  },
  {
    "name": "黄志涛",
    "borrowTime": "2024-10-15",
    "bookName": "心理大师",
    "author": "钟宇作品"
  },
  {
    "name": "黄志涛",
    "borrowTime": "2024-10-29",
    "bookName": "救赎.下",
    "author": "陆沉著"
  },
  {
    "name": "黄志涛",
    "borrowTime": "2024-11-20",
    "bookName": "刑侦一科.上",
    "author": "黑羽时晴著"
  },
  {
    "name": "黄琨善",
    "borrowTime": "2024-05-09",
    "bookName": "三国演义",
    "author": "(明)罗贯中著"
  },
  {
    "name": "黄琨善",
    "borrowTime": "2024-05-24",
    "bookName": "三国演义",
    "author": "(明)罗贯中著"
  },
  {
    "name": "黄登一",
    "borrowTime": "2023-09-14",
    "bookName": "四级词汇词根+联想记忆法",
    "author": "俞敏洪编著"
  },
  {
    "name": "齐婧涵",
    "borrowTime": "2023-09-25",
    "bookName": "拥抱分你一半",
    "author": "不止是颗菜著"
  },
  {
    "name": "齐婧涵",
    "borrowTime": "2023-09-26",
    "bookName": "招摇.下卷",
    "author": "九鹭非香[著]"
  },
  {
    "name": "齐文崧",
    "borrowTime": "2023-10-10",
    "bookName": "半身侦探.4",
    "author": "暗布烧著"
  },
  {
    "name": "齐文崧",
    "borrowTime": "2023-10-10",
    "bookName": "野士岭之白毛子大雾",
    "author": "蔡九歌著"
  },
  {
    "name": "齐淏喆",
    "borrowTime": "2023-11-21",
    "bookName": "明朝那些事儿.第1部,朱元璋: 从和尚到皇帝.图文精印版",
    "author": "当年明月著"
  },
  {
    "name": "齐珅玙",
    "borrowTime": "2023-10-12",
    "bookName": "饶雪漫的青春疼痛:左耳",
    "author": "饶雪漫"
  },
  {
    "name": "齐珅玙",
    "borrowTime": "2023-12-13",
    "bookName": "元尊.6,逆流而上",
    "author": "天蚕土豆著"
  },
  {
    "name": "龙小波",
    "borrowTime": "2023-10-07",
    "bookName": "赛雷三分钟漫画三国演义:全彩漫画作品",
    "author": "赛雷[著]"
  },
  {
    "name": "龙小波",
    "borrowTime": "2023-10-07",
    "bookName": "赛雷三分钟漫画三国演义:全彩漫画作品.3",
    "author": "赛雷[著]"
  },
  {
    "name": "龙小波",
    "borrowTime": "2023-10-18",
    "bookName": "十宗罪.5",
    "author": "蜘蛛著"
  },
  {
    "name": "龙小波",
    "borrowTime": "2023-10-18",
    "bookName": "痕迹",
    "author": "毕蔷著"
  },
  {
    "name": "龙小波",
    "borrowTime": "2023-10-30",
    "bookName": "积案调查组",
    "author": "狐狸猫著"
  },
  {
    "name": "龙小波",
    "borrowTime": "2024-05-12",
    "bookName": "异域奇谈,日本卷",
    "author": "桐木著"
  },
  {
    "name": "龚誉哲",
    "borrowTime": "2024-05-18",
    "bookName": "在心灵牧场上放逐",
    "author": "柳迦柔著"
  },
  {
    "name": "龚誉哲",
    "borrowTime": "2024-05-18",
    "bookName": "世间没有白走的路",
    "author": "刘心武著"
  },
  {
    "name": "龚誉哲",
    "borrowTime": "2024-05-25",
    "bookName": "最好的侦探小说:超值金版",
    "author": "东野主编"
  },
  {
    "name": "龚誉哲",
    "borrowTime": "2025-03-16",
    "bookName": "兄弟.2版",
    "author": "余华著"
  }
];
